# Code for the manuscript

"A data-driven framework for monthly delivered-quantity forecasting and inventory cost management in supply chains"

This folder contains only the code that produces the results, tables and figures reported in the manuscript.

## Setup
1. Python 3.13: `python3 -m venv .venv && .venv/bin/pip install -r requirements.txt`
2. Download the USAID *Supply Chain Shipment Pricing Data* (SCMS Delivery History Dataset, 29 September 2015 release) and save it unmodified as `proj/data/scms_raw.csv`
   (SHA-256 `e2499b3fd929cd27499f4625474869b9accbe0c24594eeedf4e97cef17890273`).
3. Paths resolve from each file's location. To run from another directory, set `HYBRID_ANN_ROOT` to this folder.

## Run order
Run each script from its own folder. Each step reads the outputs of the steps above it.

| Step | Script(s) | Manuscript output |
|---|---|---|
| 1 | `research_comparison/track_B_fair_benchmark/rolling_origin_evaluation.py` | Monthly series, rolling origins, statistical benchmarks |
| 2 | `technical_revision/ann_improvement/run_stage1.py val singles` and `test singles` | ANN forecasts used for the forecast-error CV of the inventory model |
| 3 | `technical_revision/reviewer_tests/forecast_benchmark/bench.py` | Machine-learning benchmarks |
| 4 | `technical_revision/avla_ann/members.py`, then `weighting.py` | Ensemble members; AVLA weights and exact-optimum check |
| 5 | `technical_revision/orderbook_avla_20261113/run_ob.py`, then `analyze.py` | Proposed AVLA–ANN + order book; Figure 4 data and projection |
| 6 | `technical_revision/forecast_freeze_E1E2_20261116/e1_e2.py` | Accuracy of all 23 methods (Table 3, Supplementary Table S5) |
| 7 | `technical_revision/dm_main_comparators_20261117/dm_tests.py`; `audit/orderbook_gain_by_period.py`; `audit/orderbook_lookahead_check.py` | Diebold–Mariano tests, ablation (Supplementary Table S6), order-book results |
| 8 | `technical_revision/experiments_v2_20261108T0543Z/r1.py 2` and `r1.py 3` | Policy costs with bootstrap intervals (Table 4); 32 sensitivity cases (Figure 5) |
| 9 | `technical_revision/experiments_v2_20261108T0543Z/r2.py` | Forecaster-to-cost inputs |
| 10 | `technical_revision/audit_followups_20261116/scripts/e1_queue.sh`, then `e1_check.py` and `e1_summarise.py` | 22 PSO-planned runs and independent checks (Table 5); about 10 hours on two cores |
| 11 | `technical_revision/audit_followups_20261116/scripts/e2_leadtime_only.py`, `e4_concentration.py` | Lead-time-only safety stock; country concentration |
| 12 | `technical_revision/freight_ann_avla_20261108/scripts/run_primary.py`, then `run_downstream.py` | Alternative machine-learning freight model |
| 13 | `technical_revision/forecast_value_own_costing_20261116/run.py`; `technical_revision/pso_consistency_scenario_20261116/run.py` | Forecast accuracy and inventory cost (own and common costing) |
| 14 | `technical_revision/incoterm_feasibility_20261116/analysis.py` | INCOTERM comparison (Supplementary Table S3) |
| 15 | `technical_revision/manuscript_tables/make_manuscript_tables.py` | All manuscript tables, figure data and Figure 5 |
| 16 | `technical_revision/manuscript_figures/make_pseudocode.py`, `make_fig4.py`, `make_composite_fig4.py` | Figures 2–4 (Figure 1 is `Figure1_ANN_structure.png`) |

## Main modules
- Forecasting: `research_comparison/track_B_fair_benchmark/` (preprocessing, models), `technical_revision/avla_ann/` (members, AVLA, exact weights), `technical_revision/orderbook_avla_20261113/run_ob.py` (order-book feature and final model).
- Inventory cost and PSO: `technical_revision/pso_stage/cost3.py` (cost model and freight surrogate), `technical_revision/consolidation/` and `technical_revision/consolidation_v2/` (planning engine, bundle partition, independent cost check), `technical_revision/experiments_v2_20261108T0543Z/xlib.py` (experiment library).
