"""Unified reviewer forecasting benchmark (SPEC_FROZEN.md). Usage: python3 bench.py"""
import os as _os_root
_HA_ROOT = _os_root.environ.get("HYBRID_ANN_ROOT") or _os_root.path.abspath(_os_root.path.join(_os_root.path.dirname(_os_root.path.abspath(__file__)), "..", "..", ".."))  # portable root (build_repo.py)
import os, sys, json, time, hashlib, warnings, itertools, numpy as np, pandas as pd
from joblib import Parallel, delayed
from scipy import stats
warnings.filterwarnings("ignore")
HERE = os.path.dirname(os.path.abspath(__file__)); TR = f"{_HA_ROOT}/technical_revision"; TB = f"{_HA_ROOT}/research_comparison/track_B_fair_benchmark"
sys.path.insert(0, TB); sys.path.insert(0, f"{TR}/avla_ann")
from preprocessing import monthly_series
from forecasting_models import classical
import members as MB, weighting as WG
from sklearn.preprocessing import MinMaxScaler, StandardScaler
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.svm import SVR
from sklearn.compose import TransformedTargetRegressor
from sklearn.neural_network import MLPRegressor
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from xgboost import XGBRegressor
from arch.bootstrap import MCS

y = monthly_series(); L = np.log1p(y); IDX = list(y.index); pos = lambda d: IDX.index(pd.Timestamp(d))
VAL = list(range(pos("2011-09-01"), pos("2013-09-01"))); TEST = list(range(pos("2013-09-01"), len(y))); ALL = VAL + TEST
MEMB = list(range(pos("2010-09-01"), len(y)))
SEEDS = [42, 1, 2, 3, 4, 5]; OUT = f"{HERE}/outputs"; LOG = {}

# ---------------- leakage self-test on the manuscript features ----------------
def leak_test():
    F = MB.features(y)
    for t in range(4, len(y)):
        yp = y.iloc[:t + 1].copy(); yp.iloc[-1] = 1e9; Fp = MB.features(yp)
        if not np.allclose(F.iloc[t].values, Fp.iloc[t].values, equal_nan=True): return False, str(y.index[t])
    return True, None

# ---------------- ML forecaster with the ANN's inputs ----------------
def make(name, cfg, seed):
    if name == "OLS": return LinearRegression()
    if name == "Ridge": return Ridge(alpha=cfg["alpha"])
    if name == "SVR": return TransformedTargetRegressor(regressor=SVR(kernel="rbf", **cfg), transformer=StandardScaler())
    if name == "RF": return RandomForestRegressor(random_state=seed, n_jobs=1, **cfg)
    if name == "GBR": return GradientBoostingRegressor(random_state=seed, **cfg)
    if name == "XGB": return XGBRegressor(random_state=seed, n_jobs=1, colsample_bytree=1.0, reg_lambda=1.0, verbosity=0, **cfg)
    if name == "ANN": return MLPRegressor(random_state=seed, **cfg)
    raise ValueError(name)

def ml_forecast(name, cfg, seed, t):
    yp = y.iloc[:t + 1].copy(); yp.iloc[-1] = np.nan; F = MB.features(yp); X, yy = F.iloc[3:t].values, yp.iloc[3:t].values; xt = F.iloc[[t]].values
    sc = MinMaxScaler().fit(X); m = make(name, cfg, seed).fit(sc.transform(X), yy); return float(m.predict(sc.transform(xt))[0])

STOCH = {"RF", "GBR", "XGB", "ANN"}
GRIDS = {"OLS": [{}], "Ridge": [{"alpha": a} for a in (0.01, 0.1, 1, 10, 100)],
         "SVR": [{"C": c, "epsilon": e, "gamma": g} for c in (0.1, 1, 10, 100) for e in (0.01, 0.1, 0.5) for g in ("scale", 0.1, 1)],
         "RF": [{"n_estimators": 300, "max_depth": d, "min_samples_leaf": l, "max_features": f} for d in (None, 3, 6) for l in (1, 5, 10) for f in (1.0, "sqrt")],
         "GBR": [{"n_estimators": n, "learning_rate": r, "max_depth": d, "subsample": s} for n in (100, 300) for r in (0.03, 0.1) for d in (2, 3) for s in (0.8, 1.0)],
         "XGB": [{"n_estimators": n, "learning_rate": r, "max_depth": d, "subsample": s} for n in (100, 300) for r in (0.03, 0.1) for d in (2, 4) for s in (0.8, 1.0)]}
FIXED = {"ANN": {"hidden_layer_sizes": (128, 64), "max_iter": 800}, "RF (manuscript cfg)": ("RF", {"n_estimators": 200}), "GBR (manuscript cfg)": ("GBR", {"n_estimators": 200, "learning_rate": 0.1})}
LABEL = {"OLS": "Linear regression (OLS)", "Ridge": "Ridge regression", "SVR": "SVR (RBF)", "RF": "Random Forest (tuned)", "GBR": "Gradient Boosting (tuned)", "XGB": "XGBoost (tuned)"}
CLASSICAL = ["Naive", "Seasonal naive", "SES", "Holt (linear)", "Holt (damped)", "Holt-Winters (damped, additive)", "ARIMA(0,1,2)", "SARIMA(0,1,1)(1,0,0)12"]

def classical_forecast(name, t):
    if name == "Naive": return float(y.iloc[t - 1])
    if name == "Seasonal naive": return float(y.iloc[t - 12])
    if name.startswith("ARIMA"): f, _ = classical("ARIMA", L.iloc[:t], ((0, 1, 2), (0, 0, 0, 0)))
    elif name.startswith("SARIMA"): f, _ = classical("SARIMA", L.iloc[:t], ((0, 1, 1), (1, 0, 0, 12)))
    else: f, _ = classical(name, L.iloc[:t])
    return float(np.expm1(f))

# ---------------- metrics and tests ----------------
def metrics(a, p, naive, scale):
    e = a - p; mse = float(np.mean(e ** 2))
    return {"RMSE": np.sqrt(mse), "MSE": mse, "MAD (=MAE)": float(np.mean(np.abs(e))), "MAPE %": float(100 * np.mean(np.abs(e / a))), "MASE": float(np.mean(np.abs(e)) / scale),
            "Bias (mean e)": float(e.mean()), "Skill vs naive": float(1 - np.sqrt(mse) / np.sqrt(np.mean((a - naive) ** 2))), "R2 (oos)": float(1 - np.sum(e ** 2) / np.sum((a - a.mean()) ** 2))}

def dm(e1, e2, loss="sq"):
    d = (e1 ** 2 - e2 ** 2) if loss == "sq" else (np.abs(e1) - np.abs(e2)); T = len(d)
    if np.allclose(d, 0): return 0.0, 1.0
    s = d.mean() / np.sqrt(d.var(ddof=0) / T) * np.sqrt((T - 1) / T); return float(s), float(2 * stats.t.sf(abs(s), T - 1))

def holm(p):
    p = np.asarray(p); o = np.argsort(p); k = len(p); adj = np.empty(k); run = 0
    for r, i in enumerate(o): run = max(run, min(1, (k - r) * p[i])); adj[i] = run
    return adj

def block_boot(a, p1, p2, B=5000, b=3, seed=7):
    rng = np.random.default_rng(seed); T = len(a); nb = int(np.ceil(T / b)); out = []
    for _ in range(B):
        idx = np.concatenate([np.arange(s, s + b) for s in rng.integers(0, T - b + 1, nb)])[:T]
        out.append(np.sqrt(np.mean((a[idx] - p1[idx]) ** 2)) - np.sqrt(np.mean((a[idx] - p2[idx]) ** 2)))
    return [float(np.percentile(out, 2.5)), float(np.percentile(out, 97.5))]

if __name__ == "__main__":
    t0 = time.time(); LOG["spec_sha256"] = hashlib.sha256(open(f"{HERE}/SPEC_FROZEN.md", "rb").read()).hexdigest()
    ok, where = leak_test(); LOG["leakage_selftest_pass"] = ok; assert ok, where
    # ---- tuning on validation only ----
    LOG["tuning"] = {}; SEL = {}
    for name, grid in GRIDS.items():
        seeds = SEEDS if name in STOCH else [42]
        jobs = [(g, s, t) for g in range(len(grid)) for s in seeds for t in VAL]
        res = Parallel(n_jobs=2)(delayed(ml_forecast)(name, grid[g], s, t) for g, s, t in jobs)
        P = pd.DataFrame([{"g": g, "seed": s, "t": t, "p": r} for (g, s, t), r in zip(jobs, res)]); P["e2"] = (P.p - y.values[P.t]) ** 2
        sc = P.groupby(["g", "seed"]).e2.mean().apply(np.sqrt).groupby("g").mean(); SEL[name] = grid[int(sc.idxmin())]
        LOG["tuning"][name] = {"grid_size": len(grid), "val_RMSE_by_config": {str(grid[g]): float(v) for g, v in sc.items()}, "selected": str(SEL[name]), "selected_val_RMSE": float(sc.min())}
        print("tuned", name, SEL[name], round(sc.min(), 1), f"{time.time()-t0:.0f}s", flush=True)
    # ---- forecasts on validation + test ----
    rows = []
    for name in CLASSICAL:
        ps = Parallel(n_jobs=2)(delayed(classical_forecast)(name, t) for t in ALL)
        rows += [{"model": name, "seed": 42, "t": t, "pred": p} for t, p in zip(ALL, ps)]
    for name in GRIDS:
        seeds = SEEDS if name in STOCH else [42]; jobs = [(s, t) for s in seeds for t in ALL]
        ps = Parallel(n_jobs=2)(delayed(ml_forecast)(name, SEL[name], s, t) for s, t in jobs)
        rows += [{"model": LABEL[name], "seed": s, "t": t, "pred": p} for (s, t), p in zip(jobs, ps)]
    # manuscript members (ANN = selected model; RF/GBR manuscript cfg) from Sep-2010 for AVLA warm-up
    mem = {}
    for lab, (nm, cfg) in {"ANN": ("ANN", FIXED["ANN"]), "RF (manuscript cfg)": FIXED["RF (manuscript cfg)"], "GBR (manuscript cfg)": FIXED["GBR (manuscript cfg)"]}.items():
        jobs = [(s, t) for s in SEEDS for t in MEMB]; ps = Parallel(n_jobs=2)(delayed(ml_forecast)(nm, cfg, s, t) for s, t in jobs)
        mem[lab] = pd.DataFrame([{"seed": s, "t": t, "pred": p} for (s, t), p in zip(jobs, ps)])
        rows += [{"model": lab, "seed": s, "t": t, "pred": p} for (s, t), p in zip(jobs, ps) if t in ALL]
    M = mem["ANN"].rename(columns={"pred": "ANN"}).merge(mem["RF (manuscript cfg)"].rename(columns={"pred": "RF"})).merge(mem["GBR (manuscript cfg)"].rename(columns={"pred": "GB"}))
    M["config"] = "manuscript"; M["month"] = [IDX[t] for t in M.t]; M["actual"] = y.values[M.t]
    av = Parallel(n_jobs=2)(delayed(WG.one)("manuscript", s, M, s) for s in SEEDS)
    A = pd.DataFrame([r for rs in av for r in rs]); A["t"] = [pos(m) for m in A.month]
    rows += [{"model": "AVLA-ANN (paper ensemble)", "seed": s, "t": t, "pred": p} for s, t, p in zip(A.seed, A.t, A["AVLA-ANN"]) if t in ALL]
    F = pd.DataFrame(rows); F["month"] = [IDX[t] for t in F.t]; F["actual"] = y.values[F.t]; F["window"] = np.where(F.t.isin(TEST), "test", "validation")
    F.to_csv(f"{OUT}/forecasts_all.csv", index=False); A.to_csv(f"{OUT}/avla_weights_and_predictions.csv", index=False)
    # ---- reproduction checks ----
    rc = {}
    B0 = pd.concat([pd.read_csv(f"{TR}/ann_improvement/outputs/forecasts_{p}_singles.csv") for p in ("val", "test")]); B0 = B0[B0.candidate == "B0"]
    mine = F[F.model == "ANN"].merge(B0[["seed", "t", "pred"]], on=["seed", "t"], suffixes=("", "_ref")); rc["ANN_vs_ann_improvement_B0_max_abs"] = float((mine.pred - mine.pred_ref).abs().max()); rc["ANN_rows_matched"] = len(mine)
    EXP = f"{TR}/avla_ann_sensitivity/outputs/members_manuscript_ext.csv"  # optional cross-check
    if os.path.exists(EXP):
        EX = pd.read_csv(EXP); mm = M.merge(EX, on=["seed", "t"], suffixes=("", "_ref")); rc["members_vs_saved_max_abs"] = {k: float((mm[k] - mm[f"{k}_ref"]).abs().max()) for k in ("ANN", "RF", "GB")}; rc["members_rows_matched"] = len(mm)
    a42 = F[(F.model == "AVLA-ANN (paper ensemble)") & (F.seed == 42) & (F.window == "test")]; rc["AVLA_test_RMSE_s42"] = float(np.sqrt(np.mean((a42.actual - a42.pred) ** 2))); rc["AVLA_ref_RMSE"] = 1081.885516
    TBp = pd.read_csv(f"{TB}/predictions/per_origin_predictions_all.csv", index_col=0, parse_dates=True); TBp = TBp[TBp.window == "test"]
    cmap = {"Naive": "Naive", "Seasonal naive": "Seasonal naive", "SES": "SES", "Holt (linear)": "Holt (linear)", "Holt (damped)": "Holt (damped)",
            "Holt-Winters (damped, additive)": "Holt-Winters (damped, additive)", "ARIMA(0,1,2)": "ARIMA(0, 1, 2)", "SARIMA(0,1,1)(1,0,0)12": "SARIMA(0, 1, 1)(1, 0, 0)12"}
    rc["classical_vs_TrackB_max_rel"] = {k: float(np.max(np.abs(F[(F.model == k) & (F.window == "test")].sort_values("t").pred.values / TBp[v].values - 1))) for k, v in cmap.items()}
    LOG["reproduction"] = rc; print(json.dumps(rc, indent=1), flush=True)
    # ---- metrics ----
    naive_all = {t: float(y.iloc[t - 1]) for t in ALL}; ins = y.iloc[:pos("2013-09-01")]; scale = float(np.mean(np.abs(np.diff(ins.values))))
    mt = []
    for (m, s, w), g in F.groupby(["model", "seed", "window"]):
        g = g.sort_values("t"); mt.append({"model": m, "seed": s, "window": w, **metrics(g.actual.values, g.pred.values, np.array([naive_all[t] for t in g.t]), scale)})
    MT = pd.DataFrame(mt); MT.to_csv(f"{OUT}/metrics_per_seed.csv", index=False)
    ann_seed = MT[(MT.model == "ANN")].set_index(["seed", "window"]).RMSE
    summ = []
    for (m, w), g in MT.groupby(["model", "window"]):
        r42 = g[g.seed == 42].iloc[0]; d = {"model": m, "window": w, **{k: r42[k] for k in ["RMSE", "MSE", "MAD (=MAE)", "MAPE %", "MASE", "Bias (mean e)", "Skill vs naive", "R2 (oos)"]}}
        if len(g) > 1:
            d.update({"RMSE mean (6 seeds)": g.RMSE.mean(), "RMSE SD (6 seeds)": g.RMSE.std(ddof=1), "MAD mean (6 seeds)": g["MAD (=MAE)"].mean(),
                      "seeds better than ANN (RMSE)": int(sum(g.set_index("seed").RMSE.loc[s] < ann_seed.loc[(s, w)] for s in SEEDS)) if m != "ANN" else None})
        summ.append(d)
    S = pd.DataFrame(summ).sort_values(["window", "RMSE"]); S.to_csv(f"{OUT}/metrics_summary.csv", index=False)
    # ---- tests (seed 42, test) ----
    T42 = F[(F.seed == 42) & (F.window == "test")].pivot(index="t", columns="model", values="pred"); a = y.values[T42.index]
    for m in T42.columns:   # deterministic models have only seed 42 already
        pass
    eA = a - T42["ANN"].values; eV = a - T42["AVLA-ANN (paper ensemble)"].values; others = [m for m in T42.columns if m != "ANN"]
    rows = []
    for m in others:
        e = a - T42[m].values; s1, p1 = dm(e, eA, "sq"); s2, p2 = dm(e, eA, "abs")
        rows.append({"model": m, "RMSE": float(np.sqrt(np.mean(e ** 2))), "dRMSE_vs_ANN": float(np.sqrt(np.mean(e ** 2)) - np.sqrt(np.mean(eA ** 2))), "DM_sq": s1, "p_sq": p1, "DM_abs": s2, "p_abs": p2,
                     "boot95_dRMSE_vs_ANN": block_boot(a, T42[m].values, T42["ANN"].values)})
    D = pd.DataFrame(rows); D["p_sq_holm"] = holm(D.p_sq); D["p_abs_holm"] = holm(D.p_abs)
    rv = [dict(model=m, **dict(zip(("DM_sq_vs_AVLA", "p_vs_AVLA"), dm(a - T42[m].values, eV)))) for m in T42.columns if m != "AVLA-ANN (paper ensemble)"]
    RV = pd.DataFrame(rv); RV["p_vs_AVLA_holm"] = holm(RV.p_vs_AVLA); D = D.merge(RV, on="model", how="outer").sort_values("RMSE"); D.to_csv(f"{OUT}/tests_vs_ANN_and_AVLA.csv", index=False)
    loss = pd.DataFrame({m: (a - T42[m].values) ** 2 for m in T42.columns})
    mcs = MCS(loss, size=0.10, reps=10000, block_size=3, bootstrap="mbb", seed=7); mcs.compute()
    LOG["MCS_90_included"] = sorted(mcs.included); LOG["MCS_pvalues"] = {k: float(v) for k, v in mcs.pvalues.iloc[:, 0].items()}
    # ---- folds ----
    F42 = F[F.seed == 42].copy(); F42["fold"] = pd.cut(F42.t, [VAL[0] - 1, VAL[11], VAL[-1], TEST[11], TEST[-1]], labels=["V1 Sep11-Aug12", "V2 Sep12-Aug13", "T1 Sep13-Aug14", "T2 Sep14-Aug15"])
    FR = F42.groupby(["fold", "model"]).apply(lambda g: np.sqrt(np.mean((g.actual - g.pred) ** 2))).unstack(0); FR.to_csv(f"{OUT}/rmse_by_fold.csv")
    rk = FR.rank(axis=0); rk.to_csv(f"{OUT}/rank_by_fold.csv"); fr = stats.friedmanchisquare(*[FR.loc[m].values for m in FR.index])
    LOG["friedman_over_4_folds"] = {"stat": float(fr.statistic), "p": float(fr.pvalue), "n_models": len(FR)}; LOG["ANN_rank_by_fold"] = rk.loc["ANN"].to_dict(); LOG["AVLA_rank_by_fold"] = rk.loc["AVLA-ANN (paper ensemble)"].to_dict()
    LOG["runtime_s"] = time.time() - t0; json.dump(LOG, open(f"{HERE}/logs/bench_log.json", "w"), indent=1, default=str)
    print(S[S.window == "test"][["model", "RMSE", "MSE", "MAD (=MAE)", "MAPE %", "Skill vs naive", "RMSE mean (6 seeds)", "RMSE SD (6 seeds)", "seeds better than ANN (RMSE)"]].round(3).to_string(index=False))
    print(D[["model", "dRMSE_vs_ANN", "DM_sq", "p_sq", "p_sq_holm", "p_abs_holm", "boot95_dRMSE_vs_ANN", "p_vs_AVLA_holm"]].round(3).to_string(index=False))
    print("MCS 90%:", LOG["MCS_90_included"]); print("Friedman:", LOG["friedman_over_4_folds"]); print("ANN ranks:", LOG["ANN_rank_by_fold"])
