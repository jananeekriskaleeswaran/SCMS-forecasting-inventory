"""Exact simplex-constrained least squares (copied verbatim from weight_optimisation/weight_optimisation.py)."""
import numpy as np
def opt_simplex(P, y, verify=True):
    """Exact minimiser of ||y - P w||^2 s.t. w >= 0, sum(w) = 1 for 3 members: enumerate supports S,
    solve the equality-constrained least squares on S in closed form (KKT), keep feasible solutions, take the best."""
    f = lambda w: np.mean((y - P @ w) ** 2); best = None
    sc = y.std(); Pn, yn = P / sc, y / sc                     # rescale for numerical conditioning (weights unchanged)
    for S in [(0,), (1,), (2,), (0, 1), (0, 2), (1, 2), (0, 1, 2)]:
        Ps = Pn[:, S]; k = len(S); G = Ps.T @ Ps; b = Ps.T @ yn
        Kkt = np.zeros((k + 1, k + 1)); Kkt[:k, :k] = 2 * G; Kkt[:k, k] = 1; Kkt[k, :k] = 1
        sol = np.linalg.solve(Kkt, np.r_[2 * b, 1.0])[:k]
        if (sol < -1e-12).any(): continue
        w = np.zeros(3); w[list(S)] = np.clip(sol, 0, None); w /= w.sum()
        if best is None or f(w) < f(best): best = w
    if verify:
        g = np.arange(0, 1.0001, 0.005); gw = min(((a, b_, 1 - a - b_) for a in g for b_ in g if a + b_ <= 1 + 1e-9), key=lambda w_: f(np.array(w_)))
        assert f(best) <= f(np.array(gw)) * (1 + 1e-12), "exact solution worse than grid"
    return best
