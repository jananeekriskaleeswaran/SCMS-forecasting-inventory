"""Stage 2: AVLA ensemble weights (Option A) at each test origin from the 12 most recent past errors; comparators;
gates 2 (AVLA vs exact) and 3 (leakage); metrics and tests."""
import os as _os_root
_HA_ROOT = _os_root.environ.get("HYBRID_ANN_ROOT") or _os_root.path.abspath(_os_root.path.join(_os_root.path.dirname(_os_root.path.abspath(__file__)), "..", ".."))  # portable root (build_repo.py)
import os, sys, json, numpy as np, pandas as pd
from joblib import Parallel, delayed
from scipy import stats
from avla import AVLA
from exact import opt_simplex
HERE = os.path.dirname(os.path.abspath(__file__)); O = os.path.join(HERE, "outputs")
M = ["ANN", "RF", "GB"]; W = 12

def to_w(x):
    s = x.sum(); return x / s if s > 1e-12 else np.ones(3) / 3

def avla_weights(P, y, seed):
    obj = lambda x: np.sqrt(np.mean((y - P @ to_w(x)) ** 2))
    x, f = AVLA(obj, [0] * 3, [1] * 3, seed=seed).run(); return to_w(x), f

def one(cfg, seed, df, avla_seed):
    d = df[(df.config == cfg) & (df.seed == seed)].sort_values("t").reset_index(drop=True); rows = []
    for i in range(W, len(d)):
        past = d.iloc[i - W:i]; P, y = past[M].values, past.actual.values; p = d.loc[i, M].values.astype(float)
        wa, fa = avla_weights(P, y, avla_seed); we = opt_simplex(P, y, verify=False)
        fe = np.sqrt(np.mean((y - P @ we) ** 2))
        r = np.sqrt(((y[:, None] - P) ** 2).mean(0)); wi = (1 / r) / (1 / r).sum()
        rows.append({"config": cfg, "seed": seed, "avla_seed": avla_seed, "month": d.loc[i, "month"], "actual": d.loc[i, "actual"],
                     **{m: p[j] for j, m in enumerate(M)},
                     "AVLA-ANN": p @ wa, "Inverse-RMSE": p @ wi, "Equal weights": p.mean(), "Exact optimum": p @ we,
                     "wA_ANN": wa[0], "wA_RF": wa[1], "wA_GB": wa[2], "wI_ANN": wi[0], "wI_RF": wi[1], "wI_GB": wi[2],
                     "obj_avla": fa, "obj_exact": fe, "gap_rel": (fa - fe) / fe})
    return rows

def metrics(y, p, naive):
    e = y - p; rm = np.sqrt(np.mean(e ** 2))
    return {"RMSE": rm, "MAE": np.mean(np.abs(e)), "MAPE (%)": 100 * np.mean(np.abs(e / y)),
            "R2": 1 - np.sum(e ** 2) / np.sum((y - y.mean()) ** 2), "Skill vs naive": 1 - rm / np.sqrt(np.mean((y - naive) ** 2))}

def dm(e1, e2):
    d = e1 ** 2 - e2 ** 2; T = len(d); s = d.mean() / np.sqrt(d.var(ddof=0) / T); s *= np.sqrt((T - 1) / T)   # HLN, h=1
    return s, 2 * stats.t.sf(abs(s), T - 1)

if __name__ == "__main__":
    df = pd.read_csv(os.path.join(O, "member_forecasts.csv"), parse_dates=["month"])
    jobs = [(c, s, s) for c in ("manuscript", "tuned") for s in [42, 1, 2, 3, 4, 5]] + [("manuscript", 42, a) for a in (1, 2, 3, 4, 5)]
    out = Parallel(n_jobs=2)(delayed(one)(c, s, df, a) for c, s, a in jobs)
    R = pd.DataFrame([r for rs in out for r in rs]); R.to_csv(os.path.join(O, "ensemble_predictions_all.csv"), index=False)
    # Gate 2
    g = R.groupby(["config", "seed", "avla_seed"]).gap_rel.agg(["max", "mean"]); g.to_csv(os.path.join(O, "gate2_avla_vs_exact.csv"))
    prim = R[(R.config == "manuscript") & (R.seed == 42) & (R.avla_seed == 42)].reset_index(drop=True)
    gate2 = bool(prim.gap_rel.max() <= 1e-6)
    # classical baselines (Track B, identical series and months)
    TB = pd.read_csv(f"{_HA_ROOT}/research_comparison/track_B_fair_benchmark/predictions/per_origin_predictions_all.csv", index_col=0, parse_dates=True)
    TB = TB[TB.window == "test"]; assert np.allclose(TB.Actual.values, prim.actual.values, rtol=1e-9)
    naive = TB["Naive"].values; y = prim.actual.values
    CL = {"Naive": "Naive", "SES": "SES", "Holt (damped)": "Holt (damped)", "SARIMA": "SARIMA(0, 1, 1)(1, 0, 0)12"}
    meth = ["AVLA-ANN", "Inverse-RMSE", "Equal weights", "Exact optimum", "ANN", "RF", "GB"]
    tab = {}
    for c in ("manuscript", "tuned"):
        S = R[(R.config == c) & (R.avla_seed == R.seed)]
        for m in meth:
            per = [metrics(y, S[S.seed == s][m].values, naive) for s in [42, 1, 2, 3, 4, 5]]
            tab[(c, m)] = {**{k: per[0][k] for k in per[0]}, "RMSE mean (6 seeds)": np.mean([q["RMSE"] for q in per]),
                           "RMSE SD (6 seeds)": np.std([q["RMSE"] for q in per], ddof=1)}
    for k, col in CL.items(): tab[("classical", k)] = metrics(y, TB[col].values, naive)
    T = pd.DataFrame(tab).T; T.index.names = ["members", "method"]; T.to_csv(os.path.join(O, "metrics_test24.csv"))
    # DM tests: AVLA-ANN (manuscript cfg, seed 42) vs comparators, Holm
    eA = y - prim["AVLA-ANN"].values; tests = []
    for name, p in [("Inverse-RMSE", prim["Inverse-RMSE"]), ("Equal weights", prim["Equal weights"]), ("ANN alone", prim["ANN"]),
                    ("Naive", TB["Naive"]), ("Holt (damped)", TB["Holt (damped)"]), ("SARIMA", TB[CL["SARIMA"]])]:
        s, pv = dm(eA, y - np.asarray(p, float)); tests.append({"vs": name, "DM_HLN": s, "p": pv})
    Dt = pd.DataFrame(tests).sort_values("p").reset_index(drop=True); k = len(Dt)
    Dt["p_holm"] = np.minimum(1, np.maximum.accumulate([(k - i) * p for i, p in enumerate(Dt.p)]))
    Dt.to_csv(os.path.join(O, "dm_tests.csv"), index=False)
    # AVLA seed variability on primary members
    V = R[(R.config == "manuscript") & (R.seed == 42)].groupby("avla_seed").apply(lambda d: np.sqrt(np.mean((d.actual - d["AVLA-ANN"]) ** 2)))
    json.dump({"gate2_pass": gate2, "gate2_max_rel_gap_primary": float(prim.gap_rel.max()),
               "gate2_max_rel_gap_all": float(R.gap_rel.max()), "avla_seed_rmse": V.round(4).to_dict()},
              open(os.path.join(HERE, "logs", "weighting_log.json"), "w"), indent=1)
    print(T.round(3).to_string()); print(Dt.round(4).to_string()); print("gate2", gate2, prim.gap_rel.max(), R.gap_rel.max()); print(V)
