"""Stage 1: leakage-free rolling-origin forecasts of the three AVLA members (ANN, RF, GBR), manuscript features,
Min-Max fitted on each origin's training rows only. Saves per-origin, per-seed member forecasts."""
import os as _os_root
_HA_ROOT = _os_root.environ.get("HYBRID_ANN_ROOT") or _os_root.path.abspath(_os_root.path.join(_os_root.path.dirname(_os_root.path.abspath(__file__)), "..", ".."))  # portable root (build_repo.py)
import os, sys, json, warnings, numpy as np, pandas as pd
from joblib import Parallel, delayed
from sklearn.preprocessing import MinMaxScaler
from sklearn.neural_network import MLPRegressor
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
HERE = os.path.dirname(os.path.abspath(__file__)); TB = f"{_HA_ROOT}/research_comparison/track_B_fair_benchmark"
sys.path.insert(0, TB); from preprocessing import monthly_series

CFGS = {"manuscript": {"ANN": dict(hidden_layer_sizes=(128, 64), max_iter=800), "RF": dict(n_estimators=200),
                       "GB": dict(n_estimators=200, learning_rate=0.1)},
        "tuned": {"ANN": dict(hidden_layer_sizes=(16, 8), alpha=10.0, max_iter=3000), "RF": dict(n_estimators=300, min_samples_leaf=10),
                  "GB": dict(n_estimators=50, max_depth=2, learning_rate=0.05, subsample=0.8)}}
SEEDS = [42, 1, 2, 3, 4, 5]
FEATS = ["Month_Index", "S1", "S2", "Lag1", "Lag2", "RM3"]

def features(L):
    f = pd.DataFrame(index=L.index)
    f["Month_Index"] = np.arange(len(L)); f["S1"] = np.sin(2 * np.pi * L.index.month / 12); f["S2"] = np.cos(2 * np.pi * L.index.month / 12)
    f["Lag1"] = L.shift(1); f["Lag2"] = L.shift(2); f["RM3"] = L.shift(1).rolling(3).mean()   # Eq. (2), past-only
    return f

def forecast(L, t, cfg, seed):
    """One-step forecast for month t using only L[:t]."""
    Lp = L.iloc[:t + 1].copy(); Lp.iloc[-1] = np.nan                  # y_t hidden
    F = features(Lp); X, y = F.iloc[3:t].values, Lp.iloc[3:t].values; xt = F.iloc[[t]].values
    sc = MinMaxScaler().fit(X); X, xt = sc.transform(X), sc.transform(xt)
    out = {}
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        out["ANN"] = MLPRegressor(random_state=seed, **CFGS[cfg]["ANN"]).fit(X, y).predict(xt)[0]
        out["RF"] = RandomForestRegressor(random_state=seed, n_jobs=1, **CFGS[cfg]["RF"]).fit(X, y).predict(xt)[0]
        out["GB"] = GradientBoostingRegressor(random_state=seed, **CFGS[cfg]["GB"]).fit(X, y).predict(xt)[0]
    return out

def origins(L):
    t0 = list(L.index).index(pd.Timestamp("2013-09-01")); return list(range(t0 - 12, len(L)))

if __name__ == "__main__":
    L = monthly_series(); O = origins(L)
    jobs = [(c, s, t) for c in CFGS for s in SEEDS for t in O]
    res = Parallel(n_jobs=2, verbose=0)(delayed(forecast)(L, t, c, s) for c, s, t in jobs)
    rows = [{"config": c, "seed": s, "month": L.index[t], "t": t, "actual": L.iloc[t], "window": "warm" if i < 12 else "test", **r}
            for (c, s, t), r, i in zip(jobs, res, [O.index(t) for _, _, t in jobs])]
    pd.DataFrame(rows).to_csv(os.path.join(HERE, "outputs", "member_forecasts.csv"), index=False)
    print("saved", len(rows))
