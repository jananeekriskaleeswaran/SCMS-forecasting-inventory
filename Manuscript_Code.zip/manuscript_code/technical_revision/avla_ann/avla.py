"""AVLA: Adaptive and Various Learning-based Algorithm (He, arXiv 2504.11499), minimisation over a box.
Implements Eqs. 13-32 as specified in SPECIFICATION.md (interpretations for garbled equations documented there)."""
import numpy as np


class AVLA:
    def __init__(self, f, lb, ub, N=50, max_iter=2000, H=50, r_R=100, gamma=6.0, seed=0, record=False):
        self.f, self.lb, self.ub = f, np.asarray(lb, float), np.asarray(ub, float)
        self.N, self.T, self.H, self.rR, self.g = N, max_iter, H, r_R, gamma
        self.rng = np.random.default_rng(seed); self.record = record; self.nfev = 0

    def _eval(self, x):
        self.nfev += 1; return float(self.f(x))

    def _LE(self, t):  return 1.0 / (1.0 + np.exp(2 * self.g * (0.5 - t / self.T)))
    def _rE(self, t):  return int(round(3 + (t / self.T) * (0.2 * self.N - 3)))

    def _sample(self, MCR, MF):
        r = self.rng.integers(self.H)
        cr = float(np.clip(self.rng.normal(MCR[r], 0.1), 0, 1))
        while True:
            F = MF[r] + 0.1 * self.rng.standard_cauchy()
            if F > 0: break
        return cr, min(F, 1.0)

    def _cross(self, m, v, cr):
        D = len(m); jr = self.rng.integers(D)
        mask = (self.rng.random(D) <= cr); mask[jr] = True
        return np.clip(np.where(mask, v, m), self.lb, self.ub)

    def run(self):
        N, D, rng = self.N, len(self.lb), self.rng
        P = self.lb + rng.random((N, D)) * (self.ub - self.lb); fv = np.array([self._eval(x) for x in P])
        o = np.argsort(fv); P, fv = P[o], fv[o]
        MCR, MF = np.full(self.H, 0.5), np.full(self.H, 0.5); k = 0
        best, stall, hist = fv[0], 0, []
        for t in range(self.T):
            rE = max(2, min(self._rE(t), N - 2)); LE = self._LE(t)
            SCR, SF, dF = [], [], []
            for i in range(N):
                cr, F = self._sample(MCR, MF); m = P[i]
                if i < rE:                                            # elite learning (Eqs. 14-16)
                    e1, e2 = rng.choice([j for j in range(rE) if j != i], 2, replace=False)
                    s1 = 1 if fv[i] > fv[e1] else -1; s2 = 1 if fv[i] > fv[e2] else -1
                    v = m + s1 * F * (P[e1] - m) + s2 * F * (P[e2] - m)
                else:                                                 # common learning (Eqs. 17-19)
                    commons = [j for j in range(rE, N) if j != i]
                    i1, i2 = rng.choice(commons, 2, replace=False)
                    s2 = 1 if fv[i] > fv[i2] else -1
                    if rng.random() > LE:
                        s1 = 1 if fv[i] > fv[i1] else -1
                        v = m + s1 * F * (P[i1] - m) + s2 * F * (P[i2] - m)
                    else:
                        e = rng.integers(rE); v = m + F * (P[e] - m) + s2 * F * (P[i2] - m)
                u = self._cross(m, v, cr); fu = self._eval(u)
                if fu < fv[i]:
                    SCR.append(cr); SF.append(F); dF.append(abs(fv[i] - fu)); P[i], fv[i] = u, fu
            o = np.argsort(fv); P, fv = P[o], fv[o]
            if SCR:                                                   # memory update (Eqs. 26-31)
                w = np.array(dF) / np.sum(dF); s_cr, s_f = np.array(SCR), np.array(SF)
                MCR[k] = np.sum(w * s_cr ** 2) / np.sum(w * s_cr) if np.sum(w * s_cr) > 0 else MCR[k]
                MF[k] = np.sum(w * s_f ** 2) / np.sum(w * s_f); k = (k + 1) % self.H
            if fv[0] < best - 1e-15: best, stall = fv[0], 0
            else: stall += 1
            if stall >= self.rR:                                      # group reflection (Eq. 23)
                stall = 0
                for i in range(N):
                    R = self.lb + self.ub - P[i]; fR = self._eval(R)
                    if i >= N - rE or fR < fv[i]: P[i], fv[i] = R, fR
            else:                                                     # tail reflection (Eq. 22)
                for i in range(N - rE, N):
                    R = self.lb + self.ub - P[i]; fR = self._eval(R)
                    if fR < fv[i]: P[i], fv[i] = R, fR
                    else:
                        P[i] = self.lb + rng.random(D) * (self.ub - self.lb); fv[i] = self._eval(P[i])
            o = np.argsort(fv); P, fv = P[o], fv[o]
            if fv[0] < best: best = fv[0]
            if self.record: hist.append(fv[0])
        self.history = hist
        return P[0].copy(), float(fv[0])
