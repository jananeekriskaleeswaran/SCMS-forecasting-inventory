"""Figure 4 for the revised manuscript: same data and style as paper_assets Fig2, neutral legend labels, no title."""
import os as _os_root
_HA_ROOT = _os_root.environ.get("HYBRID_ANN_ROOT") or _os_root.path.abspath(_os_root.path.join(_os_root.path.dirname(_os_root.path.abspath(__file__)), "..", ".."))  # portable root
import pandas as pd, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
INK, MUTED, BLUE, ORANGE = "#1f2328", "#57606a", "#2f6fd6", "#d0663a"
plt.rcParams.update({"font.size": 9, "axes.edgecolor": MUTED, "axes.labelcolor": INK, "xtick.color": MUTED, "ytick.color": MUTED})
ef = pd.read_csv(_HA_ROOT + "/technical_revision/orderbook_avla_20261113/outputs/ensemble_forecasts.csv", parse_dates=["month"])
fin = ef[ef.ob & (ef.config == "tuned") & (ef.seed == 42) & (ef.month >= "2013-09-01")].sort_values("month")
bas = ef[(~ef.ob) & (ef.config == "manuscript") & (ef.seed == 42) & (ef.month >= "2013-09-01")].sort_values("month")
fig, ax = plt.subplots(figsize=(7.2, 3.2))
ax.plot(fin.month, fin.actual, color=INK, lw=2, marker="o", ms=3, label="Delivered quantity")
ax.plot(fin.month, fin["AVLA-ANN"], color=BLUE, lw=2, label="AVLA–ANN + order book (proposed)")
ax.plot(bas.month, bas["AVLA-ANN"], color=ORANGE, lw=2, ls="--", label="AVLA–ANN, base members, no order book")
ax.set_ylabel("Thousand packs per month")
for s in ("top", "right"): ax.spines[s].set_visible(False)
ax.grid(axis="y", color="#e5e7eb", lw=0.6)
ax.legend(frameon=False, fontsize=8, ncol=3, loc="upper center", bbox_to_anchor=(0.5, -0.12))
fig.tight_layout(); fig.savefig("Fig4_test_forecasts_v2.png", dpi=300); print(len(fin), len(bas))
