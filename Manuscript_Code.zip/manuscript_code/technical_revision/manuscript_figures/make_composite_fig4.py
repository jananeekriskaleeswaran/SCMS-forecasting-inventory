"""Combine the test-forecast and projection plots into the two-panel Figure 4 of the manuscript."""
import os, sys
from PIL import Image, ImageDraw, ImageFont
HERE = os.path.dirname(os.path.abspath(__file__))
def stack(panels, W, out, gap=50, labpad=80):
    font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', 64)
    ims = []
    for f, w in panels:
        im = Image.open(f).convert('RGB'); s = w / im.width
        ims.append(im.resize((int(im.width * s), int(im.height * s)), Image.LANCZOS))
    H = sum(i.height for i in ims) + gap * (len(ims) - 1) + labpad * len(ims)
    C = Image.new('RGB', (W, H), 'white'); d = ImageDraw.Draw(C); y = 0
    for k, im in enumerate(ims):
        d.text((10, y + 5), 'abc'[k], font=font, fill='black'); y += labpad
        C.paste(im, ((W - im.width) // 2, y)); y += im.height + gap
    C.save(out, dpi=(300, 300))
if __name__ == '__main__':
    # usage: python make_composite_fig4.py test_forecasts.png forward_projection.png Figure4_forecasts.png
    a, b, out = sys.argv[1:4]
    stack([(a, 2160), (b, 2160)], 2160, out)
