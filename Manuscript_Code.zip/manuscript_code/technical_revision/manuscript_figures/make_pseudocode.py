"""Pseudocode figures (Figures 2 and 3) for the revised manuscript. Text only; no data."""
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
def draw(lines, title, out):
    h = 0.32 * len(lines) + 0.7
    fig = plt.figure(figsize=(7.2, h), dpi=300); ax = fig.add_axes([0, 0, 1, 1]); ax.axis('off')
    ax.add_patch(plt.Rectangle((0.01, 0.01), 0.98, 0.98, fill=False, lw=0.8, transform=ax.transAxes))
    ax.text(0.03, 1 - 0.32 / h, title, fontsize=9.5, fontweight='bold', family='DejaVu Sans', va='center', transform=ax.transAxes)
    ax.plot([0.03, 0.97], [1 - 0.55 / h] * 2, color='black', lw=0.6, transform=ax.transAxes)
    for k, ln in enumerate(lines):
        ax.text(0.03, 1 - (0.85 + 0.32 * k) / h, ln, fontsize=7.9, family='DejaVu Sans Mono', va='center', transform=ax.transAxes)
    fig.savefig(out, dpi=300); plt.close(fig)
draw(["Input:  monthly series y(1..N); forecast origins t0..N; members k in {ANN, RF, GBR}",
      "for each origin t = t0, ..., N do",
      "  1  build the inputs of Eqs. (1)-(3) for months < t, and for month t from data before t",
      "  2  fit Min-Max scaling on the training rows; scale all inputs",
      "  3  train each member k on months < t; issue forecast yhat(k,t)",
      "  4  solve Eq. (7) by AVLA on the 12 most recent out-of-sample member forecasts -> w(t)",
      "  5  ensemble forecast yhat(t) = sum_k w(k,t) * yhat(k,t)",
      "  6  record the error once y(t) is observed; advance the origin by one month",
      "end for",
      "Output: forecasts and errors for the validation and test origins"],
     "Algorithm 1. AVLA-ANN rolling-origin forecasting", "Fig2_pseudocode_AVLA_ANN.png")
draw(["Input:  bundle S; feasible options O_S with cycle bounds [T_lo(o), T_hi(o)] from Eq. (6); seed",
      "initialise 20 particles x = (u, log T) uniformly in [0,1) x [log min T_lo, log max T_hi]; v = 0",
      "for iteration = 1, ..., 50 do",
      "  for each particle:",
      "    o = O_S[ floor(u * |O_S|) ];   T = clip(exp(log T), T_lo(o), T_hi(o))",
      "    fitness = C(S, o, T) from Eq. (4), with the ANN freight surrogate F_o",
      "  update personal bests and the global best",
      "  v = omega*v + c1*r1*(p_best - x) + c2*r2*(g_best - x), clamped to +/-0.5 x range",
      "  x = clip(x + v, search box);   omega decreases linearly from 0.9 to 0.4",
      "end for",
      "Output: decoded global best (o*, T*) and C(S, o*, T*)   [1,020 evaluations]",
      "Each planning quarter: bundle costs from PSO enter the dynamic program that partitions lanes"],
     "Algorithm 2. PSO search for one consolidated bundle", "Fig3_pseudocode_PSO.png")
print('done')
