"""Shared inference/combination utilities for the freight experiment (frozen with the spec)."""
import os as _os_root
_HA_ROOT = _os_root.environ.get("HYBRID_ANN_ROOT") or _os_root.path.abspath(_os_root.path.join(_os_root.path.dirname(_os_root.path.abspath(__file__)), "..", "..", ".."))  # portable root (build_repo.py)
import sys, numpy as np, pandas as pd
sys.path.insert(0, f"{_HA_ROOT}/technical_revision/avla_ann"); from avla import AVLA; from exact import opt_simplex

def to_w(x):
    s = x.sum(); return x / s if s > 1e-12 else np.ones(len(x)) / len(x)

def avla_weights(P, y, seed):
    """He's AVLA (unchanged defaults N=50, max_iter=2000) minimising RMSE of P @ w over the simplex (w = x / sum x)."""
    obj = lambda x: float(np.sqrt(np.mean((y - P @ to_w(x)) ** 2)))
    x, f = AVLA(obj, [0] * P.shape[1], [1] * P.shape[1], seed=seed).run(); return to_w(x), f

def exact_weights(P, y): return opt_simplex(P, y, verify=False)

def holm(p):
    p = np.asarray(p, float); o = np.argsort(p); m = len(p); adj = np.empty(m); run = 0.0
    for k, i in enumerate(o): run = max(run, min(1.0, (m - k) * p[i])); adj[i] = run
    return adj

def cluster_bootstrap_rmse_diff(e_a, e_b, clusters, B=5000, seed=7):
    """Paired cluster bootstrap of RMSE(a) - RMSE(b) on log errors. Resamples whole clusters (country x month) with replacement;
    within a resample every shipment of a drawn cluster enters with its paired errors. Two-sided p = 2*min(P(d<=0), P(d>=0)) (centred-percentile)."""
    e_a, e_b, cl = np.asarray(e_a), np.asarray(e_b), np.asarray(clusters); u, inv = np.unique(cl, return_inverse=True)
    sa = np.bincount(inv, weights=e_a ** 2, minlength=len(u)); sb = np.bincount(inv, weights=e_b ** 2, minlength=len(u)); n = np.bincount(inv, minlength=len(u)).astype(float)
    rng = np.random.default_rng(seed); d = np.empty(B)
    for k in range(B):
        j = rng.integers(0, len(u), len(u)); N = n[j].sum(); d[k] = np.sqrt(sa[j].sum() / N) - np.sqrt(sb[j].sum() / N)
    obs = np.sqrt(np.mean(e_a ** 2)) - np.sqrt(np.mean(e_b ** 2)); cen = d - d.mean()
    p = float(np.mean(np.abs(cen) >= abs(obs)))  # bootstrap p for H0: difference = 0 (centred distribution)
    return obs, [float(np.percentile(d, 2.5)), float(np.percentile(d, 97.5))], max(p, 1.0 / B)
