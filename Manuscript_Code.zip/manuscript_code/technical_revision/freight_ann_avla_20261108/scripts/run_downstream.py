"""Minimum downstream cost experiment (SPEC_FROZEN.md §8; approvals P1-P6, R2 subset, R6-R8, §4 items 6 and 8; A4/A5).
Per planning origin (31-Aug-2013, 31-Aug-2014):
  1. weight-estimation members (S configs from the primary run, seed 42) trained on the trimmed freight-training set of the
     preceding cut-off, scored on the untrimmed preceding-year evaluation set (filter verified in verification_aug2012/);
  2. AVLA weights (+ exact optimum, acceptance test 8 within 1e-6) and one smearing factor from the combined residuals (R7);
  3. final members refitted on the cost model's own trimmed freight-training set for the origin (P1), combined with step-2 weights;
  4. base case re-planned and realised with the ANN-AVLA freight function; Observed (B1) re-costed with it; §8 checks;
  5. reference run with the existing surrogate B3 (reproduces R1 base), and B3 base plans re-costed under ANN-AVLA (existing-plan re-costing);
  6. following-year accuracy of the downstream instance on fr_ev; monotonicity of the freight curves the planner evaluates.
Not performed (A5): full planning x evaluation matrix, decision-change report, dense-grid check, smearing / bootstrap sensitivities.
Usage: python run_downstream.py --primary ../outputs/primary --out ../outputs/downstream"""
import os
for v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"): os.environ.setdefault(v, "1")
import sys, json, time, hashlib, argparse, datetime, warnings
import numpy as np, pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import freight_exp as FX
sys.path.insert(0, f"{FX.TR}/experiments_v2_20261108T0543Z")
import xlib as X
import r1 as R1
E, SD, C3, V2 = X.E, X.SD, X.C3, X.V2
warnings.filterwarnings("ignore")
VER = f"{FX.PKG}/verification_aug2012/outputs"
def sha_asns(a): return hashlib.sha256("\n".join(sorted(map(str, a))).encode("utf-8")).hexdigest()

def replica(T_END):
    """Verified freight filter (identical rule to verification_aug2012/verify_filter.py::replica, on stage2data.SHIP)."""
    T_END = pd.Timestamp(T_END); E0, E1 = T_END + pd.Timedelta(days=1), T_END + pd.DateOffset(years=1)
    elig = lambda s: s[s.opt.isin(C3.MODELLED) & (s.W > 0) & (s.F > 0)]
    pre = elig(SD.SHIP[SD.SHIP.date <= T_END]).copy(); fpk = (pre.F / pre.W).to_numpy()
    lo, hi = (float(v) for v in np.quantile(fpk, [0.01, 0.99], method="linear")); tr = pre[(fpk >= lo) & (fpk <= hi)]
    ev_all = elig(SD.SHIP[(SD.SHIP.date >= E0) & (SD.SHIP.date <= E1)]); ev = ev_all[ev_all.country.isin(set(tr.country))]
    return tr, ev, lo, hi

def expected_hashes(cut):
    if cut == "2012-08-31": j = json.load(open(f"{VER}/replica_2012.json")); return j["train_asn_sha256"], j["eval_asn_sha256"]
    j = json.load(open(f"{VER}/equivalence.json"))[cut]; return j["train_asn_sha256"], j["eval_asn_sha256"]

def monotonicity(fm, pairs, wsup):
    """Share of decreasing segments of the 4,000-point log-weight freight table for each (option, country) the planner evaluates,
    over the full table and within the training weight support of that option-country (option-level fallback)."""
    rows = []
    for o, c in pairs:
        tab = fm.smear * np.exp(np.asarray(fm._prep(o, c), float)); d = np.diff(tab); W = np.exp(fm.LOGW)
        lo, hi = wsup.get((o, c), wsup.get(o, (W[0], W[-1]))); m = (W[:-1] >= lo) & (W[1:] <= hi)
        rows.append(dict(opt=o, country=c, share_decreasing_full=float((d < 0).mean()), share_decreasing_support=float((d[m] < 0).mean()) if m.any() else np.nan,
                         max_rel_drop_support=float(np.max(np.maximum(0, -d[m]) / tab[:-1][m])) if m.any() else np.nan, support_lo=lo, support_hi=hi))
    return pd.DataFrame(rows)

def lane_delta(res_lanes, B1_lanes, pol):
    W = pd.DataFrame({"P": res_lanes.set_index("lane").total, "B1": B1_lanes.set_index("lane").total}); cty = B1_lanes.set_index("lane").country.loc[W.index].values
    return float(100 * (W.P.sum() / W.B1.sum() - 1)), E.boot(W.P, W.B1, cty)

def run_origin(T_END, prev, cfgs, out):
    t0 = time.time(); L = {"T_END": T_END, "weight_estimation_cutoff": prev}
    # ---- 1-2. weight estimation on preceding-year data ----
    wtr, wev, lo, hi = replica(prev); h = expected_hashes(prev)
    assert (sha_asns(wtr["ASN/DN #"]), sha_asns(wev["ASN/DN #"])) == h, "weight-estimation sets differ from the verified filter"
    gw = FX.AVLAFreight().fit(wtr, cfgs, seed=FX.PRIMARY_SEED); P = gw.member_log_predict(wev); y = np.log(wev.F.values)
    sw = FX.stack_weights(P, y, FX.PRIMARY_SEED); smear = FX.smear_factor(y - P @ sw["w_avla"])
    L["weight_estimation"] = {"train_rows": len(wtr), "train_max_date": str(wtr.date.max().date()), "score_rows": len(wev), "score_dates": [str(wev.date.min().date()), str(wev.date.max().date())],
                              "trim_thresholds": [lo, hi], "verified_hashes_match": True, "w_avla": dict(zip(FX.MEMBERS, sw["w_avla"].tolist())), "w_exact": dict(zip(FX.MEMBERS, sw["w_exact"].tolist())),
                              "rmse_avla": sw["rmse_avla"], "rmse_exact": sw["rmse_exact"], "gap": sw["gap"], "test8_pass": sw["pass_1e-6"], "smear_combined": smear,
                              "member_rmse_log": {m: FX.rmse(y - P[:, i]) for i, m in enumerate(FX.MEMBERS)}}
    # ---- 3. final members on the cost model's own freight-training set ----
    B = SD.build(T_END); tr_r, ev_r, _, _ = replica(T_END)
    assert set(B.fr_tr["ASN/DN #"]) == set(tr_r["ASN/DN #"]) and set(B.fr_ev["ASN/DN #"]) == set(ev_r["ASN/DN #"])
    G = FX.AVLAFreight().fit(B.fr_tr, cfgs, seed=FX.PRIMARY_SEED).set_combination(sw["w_avla"], smear); B.FM["ANN_AVLA"] = G
    L["final_members"] = {"train_rows": len(B.fr_tr), "train_max_date": str(B.fr_tr.date.max().date()), "price_as_mapping": SD.PRICE_AS}
    # ---- 6a. following-year accuracy (exploratory; fr_ev is the test year, used for nothing else) ----
    ev = B.fr_ev; acc = {}
    for k, fm in (("ANN-AVLA", G), ("B3", B.FM["ANN"]), ("OLS (cost model)", B.FM["OLS"])):
        p = fm.predict(ev.W.values, ev.opt.values, ev.country.values); acc[k] = {"RMSE_log": FX.rmse(np.log(p) - np.log(ev.F.values)), "MdAPE_pct": float(100 * np.median(np.abs(p - ev.F.values) / ev.F.values)),
                                                                               "total_pred_over_actual": float(p.sum() / ev.F.values.sum()), "n": len(ev)}
    L["following_year_accuracy_exploratory"] = acc
    # ---- 4-5. planning runs ----
    R1.B = B; R1.OQ = X.obs_quarters(B); base = next(c for c in X.frozen_cases() if c[0] == "base")
    runs = {}
    for tag, fm in (("B3", "ANN"), ("ANN-AVLA", "ANN_AVLA")):
        r = R1.run_case((base[0], base[1], {**base[2], "fm": fm})); runs[tag] = r
        W = R1.W_of(r["lanes"]); cty = r["lanes"][r["lanes"].policy == "B1"].set_index("lane").country.loc[W.index].values; t = r["totals"]
        L[f"plan_and_evaluate_{tag}"] = {"fails": len(r["fails"]), "recon_max_rel": float(max(c["recon_max_rel"] for c in r["checks"].values())),
                                         "delta_vs_Observed_pct": {p: float(100 * (t[p] / t["B1"] - 1)) for p in E.POLICIES}, "CONSOLIDATED_cluster_CI95": E.boot(W["CONSOLIDATED"], W["B1"], cty),
                                         "totals": t, "components": r["components"], "runtime_s": r["runtime_s"]}
        r["lanes"].to_csv(f"{out}/lane_costs_{tag}.csv", index=False); r["decisions"].to_csv(f"{out}/decisions_{tag}.csv.gz", index=False)
    plans_b3 = runs["B3"]["plans"]; ev2 = V2.EngineV2(B, {**base[2], "fm": "ANN_AVLA"}); obs = ev2.observed(True); rc = {}
    for pol in E.POLICIES: d, ci = lane_delta(ev2.realise(plans_b3[pol], pol), obs, pol); rc[pol] = {"delta_vs_Observed_pct": d, "cluster_CI95": ci}
    L["existing_B3_plans_recosted_under_ANN-AVLA_exploratory"] = rc
    # ---- 6b. monotonicity (exploratory) ----
    pairs = sorted({(o, l["country"]) for l in B.lanes for o in l["opts"] if o != C3.EMBEDDED})
    sh = SD.SHIP[(SD.SHIP.date <= B.T_END) & (SD.SHIP.W > 0)]; wsup = {k: (float(g.W.min()), float(g.W.max())) for k, g in sh.groupby(["opt", "country"])}
    wsup.update({o: (float(g.W.min()), float(g.W.max())) for o, g in sh.groupby("opt")})
    MO = pd.concat([monotonicity(G, pairs, wsup).assign(model="ANN-AVLA"), monotonicity(B.FM["ANN"], pairs, wsup).assign(model="B3")]); MO.to_csv(f"{out}/monotonicity.csv", index=False)
    L["monotonicity_exploratory"] = {m: {"pairs": len(x), "pairs_with_any_decrease_in_support": int((x.share_decreasing_support > 0).sum()), "max_rel_drop_in_support": float(x.max_rel_drop_support.max())} for m, x in MO.groupby("model")}
    L["acceptance_section8"] = {"weights_test8": sw["pass_1e-6"], "fails_zero": L["plan_and_evaluate_ANN-AVLA"]["fails"] == 0, "recon_le_1e-9": L["plan_and_evaluate_ANN-AVLA"]["recon_max_rel"] <= 1e-9,
                                "all_bundles_planned": L["plan_and_evaluate_ANN-AVLA"]["fails"] == 0}
    L["acceptance_section8"]["ALL_PASS"] = all(L["acceptance_section8"].values()); L["runtime_s"] = time.time() - t0
    return L

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--primary", default=f"{FX.PKG}/outputs/primary"); ap.add_argument("--out", default=f"{FX.PKG}/outputs/downstream"); a = ap.parse_args()
    acc = json.load(open(f"{a.primary}/acceptance.json")); assert acc["ALL_PASS"], "primary acceptance not passed: downstream must not run"
    assert FX.sha_file(f"{FX.PKG}/SPEC_FROZEN.md") == "b6ce31086e5859d73b07afb067481abb6af9eba034e5fd9282cdc22fc06080ae"
    cfgs = {m: FX.cfg_from_key(json.dumps(v)) for m, v in json.load(open(f"{a.primary}/downstream_S_configs.json")).items()}
    os.makedirs(a.out, exist_ok=True); LOG = {"started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds"), "S_configs": {m: str(v) for m, v in cfgs.items()}, "seed": FX.PRIMARY_SEED,
               "code_sha256": {f: FX.sha_file(f"{HERE}/{f}") for f in ("run_downstream.py", "freight_exp.py", "freight_lib.py")},
               "not_performed_A5": ["full planning x evaluation matrix (ANN-AVLA plans under B3)", "decision-change report", "20,000-point dense-grid check", "smearing sensitivities", "country-only bootstrap sensitivity", "calibration by decile"]}
    for T_END, prev in (("2013-08-31", "2012-08-31"), ("2014-08-31", "2013-08-31")):
        o = f"{a.out}/{T_END[:4]}_{int(T_END[:4]) + 1}"; os.makedirs(o, exist_ok=True); LOG[T_END] = run_origin(T_END, prev, cfgs, o)
        json.dump(LOG, open(f"{a.out}/downstream_log.json", "w"), indent=1, default=str); print(T_END, json.dumps(LOG[T_END]["acceptance_section8"]), flush=True)
    LOG["ALL_PASS"] = all(LOG[t]["acceptance_section8"]["ALL_PASS"] for t in ("2013-08-31", "2014-08-31"))
    LOG["finished_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds")
    LOG["output_sha256"] = {os.path.relpath(os.path.join(r, f), a.out): FX.sha_file(os.path.join(r, f)) for r, _, fs in os.walk(a.out) for f in fs if f != "downstream_log.json"}
    json.dump(LOG, open(f"{a.out}/downstream_log.json", "w"), indent=1, default=str)
