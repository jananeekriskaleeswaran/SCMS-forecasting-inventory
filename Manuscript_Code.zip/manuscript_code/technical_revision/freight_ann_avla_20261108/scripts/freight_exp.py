"""Implementation of SPEC_FROZEN.md (freight ANN–AVLA) plus the clarifications in logs/approvals.md.
Library only: data, features (S/E), members, baselines B1/B2/B3, constrained stacking (AVLA solver + exact reference),
smearing, metrics, inference, acceptance helpers, and the downstream freight wrapper. No module-level fitting."""
import os as _os_root
_HA_ROOT = _os_root.environ.get("HYBRID_ANN_ROOT") or _os_root.path.abspath(_os_root.path.join(_os_root.path.dirname(_os_root.path.abspath(__file__)), "..", "..", ".."))  # portable root (build_repo.py)
import sys, os, json, hashlib, warnings
import numpy as np, pandas as pd
TR = f"{_HA_ROOT}/technical_revision"; PKG = f"{TR}/freight_ann_avla_20261108"
for p in (f"{_HA_ROOT}/proj/src", f"{TR}/pso_stage", f"{TR}/avla_ann", f"{PKG}/scripts"):
    if p not in sys.path: sys.path.insert(0, p)
from freight_lib import avla_weights, exact_weights, holm, cluster_bootstrap_rmse_diff, to_w   # frozen utilities
import cost3 as C3
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.neural_network import MLPRegressor
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor

# ---------------- frozen design constants (spec §3, §5.2, §11) ----------------
TRAIN_END = pd.Timestamp("2012-08-31")
FOLDS = {"VAL": ("2012-09-01", "2013-08-31"), "T1": ("2013-09-01", "2014-08-31"), "T2": ("2014-09-01", "2015-08-31")}
FOLD_TRAIN_END = {"VAL": "2012-08-31", "T1": "2013-08-31", "T2": "2014-08-31"}
PRECEDING = {"T1": "VAL", "T2": "T1"}                       # weight / smearing year for each test fold (spec §5.3, §5.5)
SEEDS = [42, 1, 2, 3, 4, 5]; PRIMARY_SEED = 42; MEMBERS = ["ANN", "RF", "GBR"]
GRIDS = {"ANN": [dict(hidden_layer_sizes=h, alpha=a) for h in [(8,), (16,), (32, 16), (64, 32)] for a in [1e-3, 1e-2, 1e-1, 1.0]],
         "RF": [dict(max_depth=d, min_samples_leaf=l) for d in [None, 6, 12] for l in [1, 5, 20]],
         "GBR": [dict(n_estimators=n, learning_rate=lr, max_depth=d) for n in [200, 500] for lr in [0.03, 0.1] for d in [2, 3, 4]]}
EXCLUDED_FROM_COMMON = ["Direct Drop|Air Charter"]            # spec §3 (S3)
PG = ["ARV", "HRDT", "ANTM", "ACT", "MRDT"]
E_RULE = 0.99                                                # spec §5.4
AVLA_TOL = 1e-6                                              # spec §7 test 8
HOLM_FAMILY = ["ANN", "RF", "GBR", "B2", "B3"]               # spec §6, approvals C5

def complexity(member, cfg):
    """Deterministic 'simpler model' key for exact ties (spec §5.2)."""
    if member == "ANN": return (sum(cfg["hidden_layer_sizes"]), len(cfg["hidden_layer_sizes"]), -cfg["alpha"])
    if member == "RF": return (cfg["max_depth"] if cfg["max_depth"] is not None else 10 ** 9, -cfg["min_samples_leaf"])
    return (cfg["n_estimators"] * cfg["max_depth"], cfg["n_estimators"], cfg["max_depth"], cfg["learning_rate"])

def cfg_key(cfg): return json.dumps({k: (list(v) if isinstance(v, tuple) else v) for k, v in sorted(cfg.items())})
def cfg_from_key(k): d = json.loads(k); return {kk: (tuple(v) if kk == "hidden_layer_sizes" else v) for kk, v in d.items()}

def make_model(member, cfg, seed, n_jobs=1):
    if member == "ANN": return make_pipeline(StandardScaler(), MLPRegressor(max_iter=3000, random_state=seed, **cfg))
    if member == "RF": return RandomForestRegressor(n_estimators=500, random_state=seed, n_jobs=n_jobs, **cfg)
    if member == "GBR": return GradientBoostingRegressor(subsample=0.8, random_state=seed, **cfg)
    raise ValueError(member)

# ---------------- data (spec §2) ----------------
def load_data():
    """Shipment table with the frozen inclusion status (prerun/shipments_with_status.csv, verified at freeze) and E-set inputs."""
    from common import load_raw; from shipments import build_shipments
    r = load_raw(); s = build_shipments(r)
    # Shipment Mode is literally "N/A" in the raw file (pandas reads it as missing): keep the recorded value as its own category
    s["mode"] = s["mode"].astype(object).where(s["mode"].notna(), MODE_NA); s["opt"] = s.fulfill + "|" + s["mode"].astype(str)
    st = pd.read_csv(f"{PKG}/prerun/shipments_with_status.csv", usecols=["ASN/DN #", "status", "inc"])
    s = s.merge(st, on="ASN/DN #", how="left", validate="1:1"); assert s.inc.notna().all()
    # E-set composition inputs from the raw lines (spec §4)
    v = r["Line Item Value"].astype(float); g = r.assign(_v=v).groupby(["ASN/DN #", "Product Group"])._v.sum().unstack(fill_value=0.0).reindex(columns=PG, fill_value=0.0)
    n = r.groupby(["ASN/DN #", "Product Group"]).size().unstack(fill_value=0).reindex(columns=PG, fill_value=0)
    tot = g.sum(1); share = g.div(tot.where(tot > 0), axis=0)
    share_n = n.div(n.sum(1), axis=0); share = share.where(tot.gt(0), share_n, axis=0)     # value share; line-count share if shipment value is 0
    share.columns = [f"pg_{c}" for c in PG]
    mb = r.groupby("ASN/DN #")["Managed By"].agg(lambda x: x.mode().iloc[0]).rename("managed_by")
    mb_n = r.groupby("ASN/DN #")["Managed By"].nunique().rename("managed_by_n")
    s = s.merge(share, left_on="ASN/DN #", right_index=True).merge(mb, left_on="ASN/DN #", right_index=True).merge(mb_n, left_on="ASN/DN #", right_index=True)
    s["time_index"] = (s.date.dt.year - 2006) * 12 + (s.date.dt.month - 1)
    inc = s[s.inc.astype(bool)].copy().sort_values(["date", "ASN/DN #"]).reset_index(drop=True)
    inc["fold"] = "TRAIN"
    for f, (a, b) in FOLDS.items(): inc.loc[(inc.date >= a) & (inc.date <= b), "fold"] = f
    inc.loc[inc.date > FOLDS["T2"][1], "fold"] = "UNUSED"
    inc["channel"] = inc.opt.str.split("|").str[0]; inc["cluster"] = inc.country + "|" + inc.date.dt.strftime("%Y-%m")
    return inc, r

def fold_rows(d, fold): return d[d.fold == fold]
def train_rows(d, fold): return d[(d.date <= pd.Timestamp(FOLD_TRAIN_END[fold])) & (d.fold != "UNUSED")]

# ---------------- features (spec §4) ----------------
MODE_NA = "N/A"          # implementation clarification pending approval (211 included training shipments)
ZERO_VALUE_RULE = None   # E-set log(value) for value <= 0: undefined in the frozen spec; must be set explicitly after user approval
ZERO_VALUE_RULES = ("floor_indicator", "log1p")

class FeatureSpace:
    """S: logW, option one-hot, country one-hot. E: S + log(value), n_lines, n_items, product-group shares, managed-by one-hot, time index.
    Categories come from the training rows only; unseen categories map to all-zero dummies."""
    def __init__(self, kind, zero_value_rule=None):
        assert kind in ("S", "E"); self.kind = kind; self.zvr = zero_value_rule if zero_value_rule is not None else ZERO_VALUE_RULE
    def fit(self, d):
        self.opts = sorted(d.opt.unique()); self.countries = sorted(d.country.unique())
        self.mbs = sorted(d.managed_by.unique()) if self.kind == "E" else []
        self.columns = ["logW"] + [f"opt_{o}" for o in self.opts] + [f"country_{c}" for c in self.countries]
        if self.kind == "E":
            self.columns += ["log_value", "n_lines", "n_items"] + [f"pg_{c}" for c in PG] + [f"mb_{m}" for m in self.mbs] + ["time_index"]
            if self.zvr == "floor_indicator": self.columns += ["zero_value"]; v = d.value[d.value > 0]; self.vfloor = float(v.min())   # floor from training rows only
            elif self.zvr not in (None, "log1p"): raise ValueError(self.zvr)
        self.n_train = len(d); return self
    def transform(self, d):
        X = np.zeros((len(d), len(self.columns))); col = {c: i for i, c in enumerate(self.columns)}
        X[:, 0] = np.log(np.asarray(d.W, float))
        for k, vals, pre in (("opt", d.opt.values, "opt_"), ("country", d.country.values, "country_")):
            for j, v in enumerate(vals):
                i = col.get(pre + str(v));
                if i is not None: X[j, i] = 1.0
        if self.kind == "E":
            v = np.asarray(d.value, float)
            if (v <= 0).any() and self.zvr is None: raise ValueError(f"{int((v <= 0).sum())} shipments with value <= 0: E-set zero-value rule not approved")
            if self.zvr == "floor_indicator": X[:, col["log_value"]] = np.log(np.maximum(v, self.vfloor)); X[:, col["zero_value"]] = (v <= 0).astype(float)
            elif self.zvr == "log1p": X[:, col["log_value"]] = np.log1p(v)
            else: X[:, col["log_value"]] = np.log(v)
            X[:, col["n_lines"]] = d.n_lines.values; X[:, col["n_items"]] = d.n_items.values
            for c in PG: X[:, col[f"pg_{c}"]] = d[f"pg_{c}"].values
            for j, v in enumerate(d.managed_by.values):
                i = col.get(f"mb_{v}");
                if i is not None: X[j, i] = 1.0
            X[:, col["time_index"]] = d.time_index.values
        return X

def fit_predict(member, cfg, seed, kind, tr, preds, n_jobs=1, zero_value_rule=None):
    """Fit one member on training rows tr, return log predictions for each frame in preds plus audit facts."""
    fs = FeatureSpace(kind, zero_value_rule).fit(tr); Xtr = fs.transform(tr); y = np.log(tr.F.values)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore"); m = make_model(member, cfg, seed, n_jobs).fit(Xtr, y)
    out = [m.predict(fs.transform(p)) for p in preds]
    audit = {"train_max_date": str(tr.date.max().date()), "train_n": len(tr), "pred_min_date": [str(p.date.min().date()) for p in preds],
             "encoder_from_train_only": set(fs.opts) == set(tr.opt) and set(fs.countries) == set(tr.country)}
    if member == "ANN": audit["scaler_mean_matches_train"] = bool(np.allclose(m[0].mean_, Xtr.mean(0)))
    return out, audit, (m, fs)

# ---------------- selection (spec §5.2, §5.4) ----------------
def rmse(e): return float(np.sqrt(np.mean(np.square(e))))

def select(val_table):
    """val_table: rows (kind, member, cfg, seed, rmse). Returns per kind/member chosen cfg and the feature-set decision. Pure function."""
    g = val_table.groupby(["kind", "member", "cfg"]).rmse.mean().reset_index()
    chosen = {}
    for (kind, member), x in g.groupby(["kind", "member"]):
        x = x.assign(cx=[complexity(member, cfg_from_key(c)) for c in x.cfg]).sort_values(["rmse", "cx"], kind="mergesort")
        chosen[(kind, member)] = {"cfg": x.cfg.iloc[0], "mean_val_rmse": float(x.rmse.iloc[0])}
    mS = np.mean([chosen[("S", m)]["mean_val_rmse"] for m in MEMBERS]); mE = np.mean([chosen[("E", m)]["mean_val_rmse"] for m in MEMBERS]) if ("E", "ANN") in chosen else np.inf
    kind = "E" if mE <= E_RULE * mS else "S"
    return chosen, {"mean_S": float(mS), "mean_E": float(mE), "ratio_E_over_S": float(mE / mS), "threshold": E_RULE, "selected": kind}

# ---------------- baselines ----------------
class B1Median:
    """Median freight per kg by option x weight decile, times weight (spec §5.1; rule in approvals §4 item 10). No smearing."""
    Q = np.linspace(0.1, 0.9, 9)
    def fit(self, d):
        W = d.W.values.astype(float); fpk = d.F.values / W; self.pool_edges = np.unique(np.quantile(W, self.Q, method="linear"))
        pb = np.digitize(W, self.pool_edges, right=False); self.pool_med = {int(b): float(np.median(fpk[pb == b])) for b in np.unique(pb)}
        self.global_med = float(np.median(fpk)); self.edges, self.cell, self.opt_med, self.n_opt, self.source = {}, {}, {}, {}, {}
        for o, x in d.groupby("opt"):
            w, f = x.W.values.astype(float), x.F.values / x.W.values; self.n_opt[o] = len(x)
            e = np.unique(np.quantile(w, self.Q, method="linear")) if len(x) >= 10 else self.pool_edges; self.source[o] = "within" if len(x) >= 10 else "pooled"
            b = np.digitize(w, e, right=False); self.edges[o] = e
            self.cell[o] = {int(k): float(np.median(f[b == k])) for k in np.unique(b)}; self.opt_med[o] = float(np.median(f))
        return self
    def fpk(self, W, o):
        if o in self.cell:
            b = int(np.digitize([W], self.edges[o], right=False)[0])
            return (self.cell[o][b], "cell") if b in self.cell[o] else (self.opt_med[o], "option_median")
        b = int(np.digitize([W], self.pool_edges, right=False)[0])
        return (self.pool_med[b], "pooled_decile") if b in self.pool_med else (self.global_med, "global")
    def predict_usd(self, d):
        r = [self.fpk(w, o) for w, o in zip(d.W.values.astype(float), d.opt.values)]
        self.last_sources = pd.Series([s for _, s in r]).value_counts().to_dict(); return np.array([v for v, _ in r]) * d.W.values

def ols_fit_predict(tr, preds):
    """B2: existing cost3.OLSFreight (channel-specific slope) trained on the fold's training shipments; returns log predictions."""
    m = C3.OLSFreight().fit(tr[["opt", "country", "W", "F"]]); return [m.reg.predict(m._X(p[["opt", "country", "W"]])) for p in preds], m

def b3_log_predict(fm, d):
    """B3 log prediction and USD prediction with its configured in-sample smearing (spec §5.1, §5.5 exception)."""
    lp = fm.reg.predict(fm._X(d[["opt", "country", "W"]])); return lp, fm.smear * np.exp(lp)

# ---------------- stacking, smearing ----------------
def stack_weights(P, y, seed):
    """Constrained stacking weights: AVLA solver plus the exact simplex optimum as correctness reference (spec §5.3, approvals R1)."""
    wa, fa = avla_weights(P, y, seed); we = exact_weights(P, y); fe = rmse(y - P @ we)
    return {"w_avla": wa, "rmse_avla": float(fa), "w_exact": we, "rmse_exact": fe, "gap": float(fa - fe), "pass_1e-6": bool(fa - fe <= AVLA_TOL)}

def inv_rmse_weights(P, y): r = np.sqrt(((y[:, None] - P) ** 2).mean(0)); w = 1 / r; return w / w.sum()
def smear_factor(resid_log): return float(np.mean(np.exp(resid_log)))

# ---------------- metrics (spec §6) ----------------
def metrics(y_log, p_log, F, p_usd, ref_rmse=None):
    e = y_log - p_log; out = {"n": len(e), "RMSE_log": rmse(e), "MAE_log": float(np.mean(np.abs(e))),
                              "R2_log_vs_fold_mean": float(1 - np.sum(e ** 2) / np.sum((y_log - y_log.mean()) ** 2))}
    for k, v in (ref_rmse or {}).items(): out[f"skill_vs_{k}"] = float(1 - out["RMSE_log"] / v)
    eu = F - p_usd; out.update({"MAE_usd": float(np.mean(np.abs(eu))), "MdAPE_pct": float(100 * np.median(np.abs(eu) / F)),
                                "total_pred_over_actual": float(p_usd.sum() / F.sum()), "RMSE_usd": rmse(eu)})
    return out

def sha_file(p): h = hashlib.sha256(); h.update(open(p, "rb").read()); return h.hexdigest()
def sha_df(df): return hashlib.sha256(pd.util.hash_pandas_object(df, index=False).values.tobytes()).hexdigest()

# ---------------- downstream freight wrapper (spec §8; approvals P1-P6, R7, item 8) ----------------
class _Stack:
    def __init__(self, models, w): self.models, self.w = models, np.asarray(w, float)
    def predict(self, X): return np.column_stack([m.predict(X) for m in self.models]) @ self.w

class AVLAFreight(C3.ANNFreight):
    """Drop-in replacement for cost3.ANNFreight: S features, constrained stacking of ANN/RF/GBR, one smearing factor (R7),
    same 4,000-point log-weight interpolation interface (f/_prep/_eval inherited)."""
    name = "ANN–AVLA (S features, constrained stacking)"
    def fit(self, sh, configs=None, seed=PRIMARY_SEED):
        self.fs = FeatureSpace("S").fit(sh); X = self.fs.transform(sh); y = np.log(sh.F.values); self.seed = seed; self.configs = configs
        with warnings.catch_warnings():
            warnings.simplefilter("ignore"); self.models = [make_model(m, configs[m], seed).fit(X, y) for m in MEMBERS]
        self.reg = None; self.smear = None; self.beta = None; return self
    def member_log_predict(self, d): X = self.fs.transform(d); return np.column_stack([m.predict(X) for m in self.models])
    def set_combination(self, w, smear):
        self.w = np.asarray(w, float); self.reg = _Stack(self.models, self.w); self.smear = float(smear)
        if hasattr(self, "_c"): del self._c
        return self
    def _X(self, sh, fit=False): return self.fs.transform(sh)
