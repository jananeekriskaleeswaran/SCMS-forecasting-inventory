"""Primary prediction experiment (SPEC_FROZEN.md §§3-7). Usage: python run_primary.py [--out DIR] [--n_jobs 2]
The pipeline function run() is also driven by the pre-run tests on synthetic data (tiny grids, stub B3)."""
import os as _os_root
_HA_ROOT = _os_root.environ.get("HYBRID_ANN_ROOT") or _os_root.path.abspath(_os_root.path.join(_os_root.path.dirname(_os_root.path.abspath(__file__)), "..", "..", ".."))  # portable root (build_repo.py)
import os
for v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"): os.environ.setdefault(v, "1")
import sys, json, time, argparse, platform, datetime
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import freight_exp as FX
from joblib import Parallel, delayed

def log(msg, L):
    L.append(f"{datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds')} {msg}"); print(L[-1], flush=True)

def _task(kind, member, cfg_k, seed, tr, va, zvr):
    t0 = time.time(); (p,), audit, _ = FX.fit_predict(member, FX.cfg_from_key(cfg_k), seed, kind, tr, [va], zero_value_rule=zvr)
    return dict(kind=kind, member=member, cfg=cfg_k, seed=seed, pred=p, audit=audit, sec=time.time() - t0)

def run(data, out, grids=FX.GRIDS, seeds=FX.SEEDS, kinds=("S", "E"), b3_provider=None, n_jobs=2, zero_value_rule=None):
    zvr = zero_value_rule if zero_value_rule is not None else FX.ZERO_VALUE_RULE
    os.makedirs(f"{out}/checkpoints", exist_ok=True); L = []; T0 = time.time(); ACC = {}
    d = data; y_all = np.log(d.F.values); d = d.assign(y_log=y_all)
    TRN, VAL, T1, T2 = FX.train_rows(d, "VAL"), FX.fold_rows(d, "VAL"), FX.fold_rows(d, "T1"), FX.fold_rows(d, "T2")
    log(f"rows train {len(TRN)} val {len(VAL)} T1 {len(T1)} T2 {len(T2)}", L)
    # ---------- 1. validation tuning: every config x seed x member x feature set (fit <= Aug-2012, predict VAL) ----------
    vrows, vpred, audits = [], {}, []
    for kind in kinds:
        for member in FX.MEMBERS:
            ck = f"{out}/checkpoints/val_{kind}_{member}.pkl"
            if os.path.exists(ck): R = pd.read_pickle(ck); log(f"loaded checkpoint {ck}", L)
            else:
                jobs = [(kind, member, FX.cfg_key(c), s) for c in grids[member] for s in seeds]
                t0 = time.time(); R = Parallel(n_jobs=n_jobs)(delayed(_task)(*j, TRN, VAL, zvr) for j in jobs); pd.to_pickle(R, ck)
                log(f"tuned {kind}/{member}: {len(jobs)} fits in {time.time() - t0:.0f}s", L)
            for r in R:
                vrows.append(dict(kind=r["kind"], member=r["member"], cfg=r["cfg"], seed=r["seed"], rmse=FX.rmse(VAL.y_log.values - r["pred"]), sec=r["sec"]))
                vpred[(r["kind"], r["member"], r["cfg"], r["seed"])] = r["pred"]; audits.append(dict(stage="tune", **{k: r[k] for k in ("kind", "member", "cfg", "seed")}, **r["audit"]))
    VT = pd.DataFrame(vrows); VT.to_csv(f"{out}/selection_validation_all.csv", index=False)
    chosen, fsel = FX.select(VT); kind = fsel["selected"]
    sel = pd.DataFrame([dict(kind=k, member=m, **v) for (k, m), v in chosen.items()]); sel.to_csv(f"{out}/selection_members.csv", index=False)
    json.dump(fsel, open(f"{out}/selection_featureset.json", "w"), indent=1)
    json.dump({m: FX.cfg_from_key(chosen[("S", m)]["cfg"]) for m in FX.MEMBERS}, open(f"{out}/downstream_S_configs.json", "w"), indent=1, default=list)
    log(f"feature set selected: {kind} (E/S = {fsel['ratio_E_over_S']:.4f})", L)
    # ---------- 2. refit selected members, predict test folds ----------
    cfg = {m: chosen[(kind, m)]["cfg"] for m in FX.MEMBERS}; P = {}   # P[(fold, member, seed)] = log predictions
    for m in FX.MEMBERS:
        for s in seeds: P[("VAL", m, s)] = vpred[(kind, m, cfg[m], s)]
    jobs = [(fold, m, s) for fold in ("T1", "T2") for m in FX.MEMBERS for s in seeds]
    def refit(fold, m, s):
        tr = FX.train_rows(d, fold); te = FX.fold_rows(d, fold); (p,), a, _ = FX.fit_predict(m, FX.cfg_from_key(cfg[m]), s, kind, tr, [te], zero_value_rule=zvr); return fold, m, s, p, a
    ck = f"{out}/checkpoints/refit_{kind}.pkl"
    if os.path.exists(ck): RR = pd.read_pickle(ck)
    else: t0 = time.time(); RR = Parallel(n_jobs=n_jobs)(delayed(refit)(*j) for j in jobs); pd.to_pickle(RR, ck); log(f"refit test folds: {len(jobs)} fits in {time.time() - t0:.0f}s", L)
    for fold, m, s, p, a in RR: P[(fold, m, s)] = p; audits.append(dict(stage="refit", kind=kind, member=m, cfg=cfg[m], seed=s, fold=fold, **a))
    # ---------- 3. baselines ----------
    B = {}
    for fold in ("VAL", "T1", "T2"):
        tr, te = FX.train_rows(d, fold), FX.fold_rows(d, fold)
        (lp,), _ = FX.ols_fit_predict(tr, [te]); B[("B2", fold)] = lp
        b1 = FX.B1Median().fit(tr); B[("B1_usd", fold)] = b1.predict_usd(te); B[("B1_sources", fold)] = b1.last_sources
        audits.append(dict(stage="baseline", member="B1/B2", fold=fold, train_max_date=str(tr.date.max().date()), pred_min_date=[str(te.date.min().date())]))
    for fold, tend in (("T1", "2013-08-31"), ("T2", "2014-08-31")):
        fm = b3_provider(tend); lp, usd = FX.b3_log_predict(fm, FX.fold_rows(d, fold)); B[("B3", fold)] = lp; B[("B3_usd", fold)] = usd
        B[("B3_cfg", fold)] = getattr(fm, "cfg", None); B[("B3_smear", fold)] = fm.smear
    # ---------- 4. stacking weights, ablations, smearing (preceding-year out-of-sample) ----------
    rows, W = [], []
    smear_rows = []
    for fold in ("T1", "T2"):
        pf = FX.PRECEDING[fold]; yp = FX.fold_rows(d, pf).y_log.values; te = FX.fold_rows(d, fold)
        for s in seeds:
            Pp = np.column_stack([P[(pf, m, s)] for m in FX.MEMBERS]); Pt = np.column_stack([P[(fold, m, s)] for m in FX.MEMBERS])
            sw = FX.stack_weights(Pp, yp, s); wi = FX.inv_rmse_weights(Pp, yp); we = np.ones(3) / 3
            best = min(FX.MEMBERS, key=lambda m: chosen[(kind, m)]["mean_val_rmse"])
            combos = {"ANN-AVLA": sw["w_avla"], "EXACT": sw["w_exact"], "EQUAL": we, "INVRMSE": wi, **{m: np.eye(3)[i] for i, m in enumerate(FX.MEMBERS)},
                      "BEST_SINGLE": np.eye(3)[FX.MEMBERS.index(best)]}
            W.append(dict(fold=fold, seed=s, preceding=pf, n_weight_rows=len(yp), **{f"w_avla_{m}": sw["w_avla"][i] for i, m in enumerate(FX.MEMBERS)},
                          **{f"w_exact_{m}": sw["w_exact"][i] for i, m in enumerate(FX.MEMBERS)}, **{f"w_invrmse_{m}": wi[i] for i, m in enumerate(FX.MEMBERS)},
                          rmse_avla=sw["rmse_avla"], rmse_exact=sw["rmse_exact"], gap=sw["gap"], pass_1e6=sw["pass_1e-6"], best_single_on_validation=best))
            for name, w in combos.items():
                sm = FX.smear_factor(yp - Pp @ w); lp = Pt @ w
                smear_rows.append(dict(fold=fold, seed=s, model=name, smear=sm, n_resid=len(yp), resid_from=pf))
                rows.append(pd.DataFrame({"ASN/DN #": te["ASN/DN #"].values, "fold": fold, "model": name, "seed": s, "log_pred": lp, "usd_pred": sm * np.exp(lp)}))
        # baselines (deterministic; stored under seed 42 and repeated for the seed-wise table)
        lp2 = B[("B2", fold)]; sm2 = FX.smear_factor(yp - B[("B2", pf)]); smear_rows.append(dict(fold=fold, seed=None, model="B2", smear=sm2, n_resid=len(yp), resid_from=pf))
        for name, lp, usd in (("B2", lp2, sm2 * np.exp(lp2)), ("B1", np.log(B[("B1_usd", fold)]), B[("B1_usd", fold)]), ("B3", B[("B3", fold)], B[("B3_usd", fold)])):
            rows.append(pd.DataFrame({"ASN/DN #": te["ASN/DN #"].values, "fold": fold, "model": name, "seed": FX.PRIMARY_SEED, "log_pred": lp, "usd_pred": usd}))
        smear_rows.append(dict(fold=fold, seed=None, model="B3", smear=B[("B3_smear", fold)], n_resid=None, resid_from="in-sample (configured exception)"))
    PR = pd.concat(rows, ignore_index=True)
    meta = d[["ASN/DN #", "date", "opt", "country", "channel", "cluster", "F", "y_log"]]
    PR = PR.merge(meta, on="ASN/DN #", how="left", validate="m:1"); PR["common"] = ~PR.opt.isin(FX.EXCLUDED_FROM_COMMON)
    PR.to_csv(f"{out}/predictions_test.csv.gz", index=False); pd.DataFrame(W).to_csv(f"{out}/weights.csv", index=False); pd.DataFrame(smear_rows).to_csv(f"{out}/smearing.csv", index=False)
    VP = pd.DataFrame([dict(member=m, seed=s, **{"ASN/DN #": a, "log_pred": v}) for m in FX.MEMBERS for s in seeds for a, v in zip(VAL["ASN/DN #"].values, P[("VAL", m, s)])])
    VP.to_csv(f"{out}/predictions_validation_selected.csv.gz", index=False)
    # ---------- 5. metrics ----------
    C = PR[PR.common]; MT = []
    for (model, seed), x in C.groupby(["model", "seed"]):
        for scope, z in [("pooled", x), ("T1", x[x.fold == "T1"]), ("T2", x[x.fold == "T2"])]:
            ref = {}
            for b in ("B2", "B3"):
                zb = C[(C.model == b) & (C.seed == FX.PRIMARY_SEED) & (C.fold.isin(z.fold.unique()))].set_index("ASN/DN #").loc[z["ASN/DN #"]]
                ref[b] = FX.rmse(zb.y_log - zb.log_pred)
            MT.append(dict(model=model, seed=seed, scope=scope, **FX.metrics(z.y_log.values, z.log_pred.values, z.F.values, z.usd_pred.values, ref)))
    MT = pd.DataFrame(MT); MT.to_csv(f"{out}/metrics_by_seed.csv", index=False)
    stoch = MT[MT.model.isin(["ANN-AVLA", "ANN", "RF", "GBR", "EXACT", "EQUAL", "INVRMSE", "BEST_SINGLE"])]
    stoch.groupby(["model", "scope"]).agg(["mean", "std"]).drop(columns=["seed", "n"], level=0).to_csv(f"{out}/metrics_six_seed_mean_sd.csv")
    M42 = MT[MT.seed == FX.PRIMARY_SEED]; M42.to_csv(f"{out}/metrics_primary_seed42.csv", index=False)
    BR = []
    for (model, fold, key), x in pd.concat([C.assign(key="option:" + C.opt), C.assign(key="channel:" + C.channel)])[lambda z: z.seed == FX.PRIMARY_SEED].groupby(["model", "fold", "key"]):
        BR.append(dict(model=model, fold=fold, group=key, n=len(x), RMSE_log=FX.rmse(x.y_log - x.log_pred), MdAPE_pct=float(100 * np.median(np.abs(x.F - x.usd_pred) / x.F))))
    pd.DataFrame(BR).to_csv(f"{out}/metrics_breakdown_seed42.csv", index=False)
    AC = PR[~PR.common & (PR.seed == FX.PRIMARY_SEED) & (PR.model != "B3")]
    pd.DataFrame([dict(model=m, fold=f, n=len(x), RMSE_log=FX.rmse(x.y_log - x.log_pred)) for (m, f), x in AC.groupby(["model", "fold"])]).to_csv(f"{out}/metrics_excluded_option_seed42.csv", index=False)
    # ---------- 6. inference: five Holm comparisons, pooled common set, seed 42 ----------
    X42 = C[C.seed == FX.PRIMARY_SEED]; a = X42[X42.model == "ANN-AVLA"].set_index("ASN/DN #"); inf = []
    for comp in FX.HOLM_FAMILY:
        b = X42[X42.model == comp].set_index("ASN/DN #").loc[a.index]
        obs, ci, p = FX.cluster_bootstrap_rmse_diff(a.y_log - a.log_pred, b.y_log - b.log_pred, a.cluster.values, B=5000, seed=7)
        inf.append(dict(comparison=f"ANN-AVLA vs {comp}", n=len(a), n_clusters=int(a.cluster.nunique()), rmse_diff=obs, ci_lo=ci[0], ci_hi=ci[1], p=p))
    inf = pd.DataFrame(inf); inf["p_holm"] = FX.holm(inf.p.values); inf["claim_better"] = (inf.p_holm < 0.05) & (inf.ci_hi < 0)
    inf["verdict"] = np.where(inf.claim_better, "ANN-AVLA better", "not distinguishable"); inf.to_csv(f"{out}/inference.csv", index=False)
    # ---------- 7. acceptance tests 1-8 ----------
    A = {}
    tf = [x for x in audits if "pred_min_date" in x]
    A["1_training_before_prediction"] = all(pd.Timestamp(x["train_max_date"]) < min(pd.Timestamp(t) for t in x["pred_min_date"]) for x in tf)
    A["2_encoders_scalers_train_only"] = all(x.get("encoder_from_train_only", True) for x in audits) and all(x.get("scaler_mean_matches_train", True) for x in audits)
    unseen = sorted(set(pd.concat([T1, T2]).country) - set(FX.train_rows(d, "T1").country)); A["2b_unseen_test_countries"] = unseen
    rng = np.random.default_rng(123); ok3 = True
    for fold in ("T1", "T2"):
        dd = d.copy(); m = dd.fold == fold; dd.loc[m, "y_log"] = rng.normal(size=m.sum())   # replace this fold's actual values
        pf = FX.PRECEDING[fold]; yp2 = FX.fold_rows(dd, pf).y_log.values
        for s in seeds:
            Pp = np.column_stack([P[(pf, mm, s)] for mm in FX.MEMBERS]); w2 = FX.stack_weights(Pp, yp2, s)["w_avla"]
            w1 = pd.DataFrame(W).query("fold == @fold and seed == @s")[[f"w_avla_{mm}" for mm in FX.MEMBERS]].values[0]; ok3 &= bool(np.array_equal(w1, w2))
    A["3_weights_invariant_to_fold_actuals"] = ok3
    dd = d.copy(); m = dd.fold.isin(["T1", "T2"]); dd.loc[m, "F"] = np.exp(rng.normal(5, 2, m.sum()))
    def sel_inputs(z):
        tr, va = FX.train_rows(z, "VAL"), FX.fold_rows(z, "VAL"); return FX.sha_df(tr.drop(columns=["y_log"], errors="ignore")) + FX.sha_df(va.drop(columns=["y_log"], errors="ignore"))
    A["4_selection_invariant_to_test_actuals"] = bool(sel_inputs(d) == sel_inputs(dd) and FX.select(VT) == (chosen, fsel))
    sr = pd.DataFrame(smear_rows); A["5_smearing_preceding_year_only"] = bool(((sr.model == "B3") | (sr.resid_from == sr.fold.map(FX.PRECEDING))).all())
    R2 = pd.read_csv(f"{out}/predictions_test.csv.gz"); R2 = R2[R2.common]; mx = 0.0
    for (model, seed, fold), x in R2.groupby(["model", "seed", "fold"]):
        v = MT[(MT.model == model) & (MT.seed == seed) & (MT.scope == fold)].RMSE_log.values[0]; mx = max(mx, abs(FX.rmse(x.y_log - x.log_pred) - v))
    sets = {k: frozenset(x["ASN/DN #"]) for k, x in R2.groupby(["model", "seed"])}
    A["6_metrics_recompute_max_abs_diff"] = mx; A["6_common_set_identical_all_models"] = len(set(sets.values())) == 1; A["6_pass"] = bool(mx < 1e-12 and A["6_common_set_identical_all_models"])
    A["7_aggregation"] = ACC.get("aggregation", "checked separately (pre-run: max |diff| = 0)")
    ww = pd.DataFrame(W); A["8_avla_matches_exact_all_problems"] = bool(ww.pass_1e6.all()); A["8_max_gap"] = float(ww.gap.max()); A["8_n_problems"] = len(ww)
    A["ALL_PASS"] = bool(A["1_training_before_prediction"] and A["2_encoders_scalers_train_only"] and A["3_weights_invariant_to_fold_actuals"] and A["4_selection_invariant_to_test_actuals"]
                         and A["5_smearing_preceding_year_only"] and A["6_pass"] and A["8_avla_matches_exact_all_problems"])
    json.dump(A, open(f"{out}/acceptance.json", "w"), indent=1, default=str)
    pd.DataFrame(audits).to_csv(f"{out}/fit_audit.csv", index=False)
    json.dump({"B1_fallback_sources": {f: B[("B1_sources", f)] for f in ("T1", "T2")}, "B3_cfg": {f: B[("B3_cfg", f)] for f in ("T1", "T2")}}, open(f"{out}/baseline_notes.json", "w"), indent=1, default=str)
    log(f"done in {time.time() - T0:.0f}s; acceptance ALL_PASS={A['ALL_PASS']}", L)
    open(f"{out}/run_log.txt", "w").write("\n".join(L)); return A

def real_b3(tend):
    sys.path.insert(0, f"{FX.TR}/consolidation"); import stage2data as S2
    return S2.build(tend).FM["ANN"]

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--out", default=f"{FX.PKG}/outputs/primary"); ap.add_argument("--n_jobs", type=int, default=2)
    ap.add_argument("--zero_value_rule", required=True, choices=FX.ZERO_VALUE_RULES, help="E-set log(value) rule for value <= 0 (requires user approval)"); a = ap.parse_args()
    FX.ZERO_VALUE_RULE = a.zero_value_rule
    os.makedirs(a.out, exist_ok=True)
    assert FX.sha_file(f"{FX.PKG}/SPEC_FROZEN.md") == "b6ce31086e5859d73b07afb067481abb6af9eba034e5fd9282cdc22fc06080ae", "frozen spec changed"
    data, raw = FX.load_data()
    exp = {"TRAIN": 3865, "VAL": 761, "T1": 901, "T2": 646}; got = data.fold.value_counts().to_dict()
    assert all(got.get(k) == v for k, v in exp.items()), got
    num = pd.to_numeric(raw["Freight Cost (USD)"], errors="coerce").groupby(raw["ASN/DN #"]).sum(min_count=1)
    agg = float((data.set_index("ASN/DN #").F - num.loc[data["ASN/DN #"]].values).abs().max())
    import sklearn, scipy
    prov = {"started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds"), "spec_sha256": FX.sha_file(f"{FX.PKG}/SPEC_FROZEN.md"),
            "approvals_sha256": FX.sha_file(f"{FX.PKG}/logs/approvals.md"),
            "code_sha256": {f: FX.sha_file(f"{FX.PKG}/scripts/{f}") for f in ("freight_exp.py", "run_primary.py", "freight_lib.py")},
            "input_sha256": {p: FX.sha_file(p) for p in (f"{_HA_ROOT}/proj/data/scms_raw.csv", f"{FX.PKG}/prerun/shipments_with_status.csv", f"{FX.TR}/consolidation/stage2data.py", f"{FX.TR}/pso_stage/cost3.py", f"{FX.TR}/avla_ann/avla.py", f"{FX.TR}/avla_ann/exact.py")},
            "data_sha256": FX.sha_df(data.drop(columns=["status"])), "fold_counts": got, "aggregation_max_abs_diff": agg,
            "env": {"python": platform.python_version(), "numpy": np.__version__, "pandas": pd.__version__, "sklearn": sklearn.__version__, "scipy": scipy.__version__},
            "seeds": {"members": FX.SEEDS, "avla": "= member seed", "bootstrap": 7, "acceptance_randomisation": 123}, "n_jobs": a.n_jobs, "zero_value_rule": a.zero_value_rule, "mode_na_category": FX.MODE_NA,
            "pg_share_basis": "line-item value share; line-count share if shipment value is 0"}
    json.dump(prov, open(f"{a.out}/provenance_run.json", "w"), indent=1)
    A = run(data, a.out, b3_provider=real_b3, n_jobs=a.n_jobs, zero_value_rule=a.zero_value_rule)
    A["7_aggregation"] = {"max_abs_diff": agg, "pass": agg == 0.0}; A["ALL_PASS"] = bool(A["ALL_PASS"] and agg == 0.0)
    json.dump(A, open(f"{a.out}/acceptance.json", "w"), indent=1, default=str)
    prov["finished_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds")
    prov["output_sha256"] = {f: FX.sha_file(f"{a.out}/{f}") for f in sorted(os.listdir(a.out)) if os.path.isfile(f"{a.out}/{f}")}
    json.dump(prov, open(f"{a.out}/provenance_run.json", "w"), indent=1)
