"""(A) Consistency run: the frozen forecaster (AVLA-ANN + order book, seed 42; forecast_freeze_E1E2_20261116) fed into the existing
ANN-PSO forecast-to-cost pipeline (experiments_v2_20261108T0543Z/r2.py, CV channel), both planning years. ANN is re-run as the reproduction check.
(B) Exploratory scenario (lever 1): each lane may use any modelled shipping option already used, within the 2-year planning history, by any
lane of the same country and fulfilment channel. All costs, lead times, bounds and the planner are unchanged. Main results are not modified.
User approval: 2026-11-16 11:42 IST."""
import os as _os_root
_HA_ROOT = _os_root.environ.get("HYBRID_ANN_ROOT") or _os_root.path.abspath(_os_root.path.join(_os_root.path.dirname(_os_root.path.abspath(__file__)), "..", ".."))  # portable root (build_repo.py)
import os, sys, json, time, copy, hashlib, warnings, numpy as np, pandas as pd
warnings.filterwarnings("ignore")
HERE = os.path.dirname(os.path.abspath(__file__)); OUT = f"{HERE}/outputs"; os.makedirs(OUT, exist_ok=True)
TR = f"{_HA_ROOT}/technical_revision"; sys.path.insert(0, f"{TR}/experiments_v2_20261108T0543Z")
import xlib as X
import r2 as R2
import r1 as R1
E, SD, C3, V2 = X.E, X.SD, X.C3, X.V2
OBF = pd.read_csv(f"{TR}/orderbook_avla_20261113/outputs/ensemble_forecasts.csv", parse_dates=["month"])
OBF = OBF[OBF.ob & (OBF.config == "tuned") & (OBF.seed == 42)].set_index("month").sort_index()
REF = {2: pd.read_csv(f"{TR}/experiments_v2_20261108T0543Z/results/R2/step2_forecaster_costs.csv"), 3: pd.read_csv(f"{TR}/experiments_v2_20261108T0543Z/results/R2/step3_forecaster_costs.csv")}

def cv_new(T_END):
    T_END = pd.Timestamp(T_END); f = OBF[(OBF.index > T_END - pd.DateOffset(months=24)) & (OBF.index <= T_END)]; assert len(f) == 24
    e = f.actual - f["AVLA-ANN"]; return float(np.sqrt(np.mean(e ** 2)) / f.actual.mean()), str(f.index.min().date()), str(f.index.max().date())

def widen(B):
    """Lever 1: lane options = union of modelled options of lanes with the same country and channel (same 2-year history window)."""
    B2 = copy.copy(B); B2.lanes = copy.deepcopy(B.lanes); pool = {}
    for l in B.lanes: pool.setdefault((l["country"], l["channel"]), set()).update(o for o in l["opts"] if o in C3.MODELLED)
    changed = 0
    for l in B2.lanes:
        if l["opts"] == [C3.EMBEDDED]: continue
        new = sorted(pool[(l["country"], l["channel"])] | set(l["opts"])); changed += int(new != l["opts"]); l["opts"] = new
    return B2, changed

def summarise(r):
    W = R1.W_of(r["lanes"]); cty = r["lanes"][r["lanes"].policy == "B1"].set_index("lane").country.loc[W.index].values; t = r["totals"]
    return {"fails": len(r["fails"]), "recon_max_rel": float(max(c["recon_max_rel"] for c in r["checks"].values())), "totals": t,
            "delta_vs_Observed_pct": {p: float(100 * (t[p] / t["B1"] - 1)) for p in E.POLICIES}, "CONSOLIDATED_CI95": E.boot(W["CONSOLIDATED"], W["B1"], cty), "components": r["components"]}

if __name__ == "__main__":
    T0 = time.time(); LOG = {"started": time.strftime("%Y-%m-%d %H:%M:%S"), "code_sha256": {f: hashlib.sha256(open(p, "rb").read()).hexdigest() for f, p in
           (("run.py", __file__), ("r2.py", f"{TR}/experiments_v2_20261108T0543Z/r2.py"), ("r1.py", f"{TR}/experiments_v2_20261108T0543Z/r1.py"), ("xlib.py", f"{TR}/experiments_v2_20261108T0543Z/xlib.py"))}}
    for step, T_END in ((2, "2013-08-31"), (3, "2014-08-31")):
        B = SD.build(T_END); R2.B = B; L = {}
        cv_ann = R2.cv_of("ANN", T_END)[0]; assert abs(cv_ann - B.CV) <= 1e-12 * B.CV
        cvn, a, b = cv_new(T_END); L["cv"] = {"ANN (frozen procedure)": cv_ann, "AVLA-ANN + order book": cvn, "cv_window": f"{a}..{b}", "cv_mult": cvn / B.CV}
        # ---- (A) consistency run via the existing R2 job ----
        RA = {lab: R2.job((lab, m, False)) for lab, m in (("ANN", 1.0), ("AVLA-ANN + order book", cvn / B.CV))}
        assert not RA["ANN"]["fails"] and not RA["AVLA-ANN + order book"]["fails"], "check failures"
        ref = REF[step].set_index(["forecaster", "policy"]); A = {}
        for p in R2.POLS:
            tot = {lab: float(pd.Series(RA[lab]["common"][p]["total"]).sum()) for lab in RA}; b1 = float(pd.Series(RA["ANN"]["common"]["B1"]["total"]).sum())
            Pn, Pa = pd.Series(RA["AVLA-ANN + order book"]["common"][p]["total"]).sort_index(), pd.Series(RA["ANN"]["common"][p]["total"]).sort_index()
            cty = pd.Series({i: l["country"] for i, l in enumerate(B.lanes)}).loc[Pn.index].values
            A[p] = {"cost_ANN": tot["ANN"], "cost_ANN_reproduces_saved_R2": bool(abs(tot["ANN"] - ref.loc[("ANN", p), "cost_common"]) <= 1e-6 * tot["ANN"]),
                    "cost_new": tot["AVLA-ANN + order book"], "diff_vs_ANN_pct": float(100 * (tot["AVLA-ANN + order book"] / tot["ANN"] - 1)), "CI95_vs_ANN_pct": E.boot(Pn, Pa, cty),
                    "delta_vs_Observed_pct_new": float(100 * (tot["AVLA-ANN + order book"] / b1 - 1)), "delta_vs_Observed_pct_ANN": float(100 * (tot["ANN"] / b1 - 1)),
                    "range_of_10_existing_forecasters_vs_ANN_pct": [float(REF[step][REF[step].policy == p].diff_vs_ANN_pct_common.min()), float(REF[step][REF[step].policy == p].diff_vs_ANN_pct_common.max())]}
        L["A_consistency"] = A; print(step, "A done", round(time.time() - T0), flush=True)
        # ---- (B) scenario: country-level option sets ----
        R1.B = B; R1.OQ = X.obs_quarters(B); base = next(c for c in X.frozen_cases() if c[0] == "base")
        rb = R1.run_case(base); L["B_reference_current_options"] = summarise(rb)
        B2, nchg = widen(B); R1.B = B2; R1.OQ = X.obs_quarters(B2); rs = R1.run_case(base); S = summarise(rs)
        S["lanes_with_more_options"] = nchg; S["n_lanes"] = len(B.lanes); L["B_scenario_country_options"] = S
        dec = rs["decisions"]; dec0 = rb["decisions"]
        try:
            m = dec[dec.policy == "CONSOLIDATED"].merge(dec0[dec0.policy == "CONSOLIDATED"], on=[c for c in ("lane", "quarter") if c in dec.columns], suffixes=("_s", "_r"))
            oc = [c for c in dec.columns if c in ("opt", "option", "o")]
            if oc: S["share_plan_rows_option_changed"] = float((m[oc[0] + "_s"] != m[oc[0] + "_r"]).mean()); S["option_mix_scenario"] = dec[dec.policy == "CONSOLIDATED"][oc[0]].value_counts().to_dict()
        except Exception as ex: S["decision_compare_note"] = repr(ex)
        rs["lanes"].to_csv(f"{OUT}/step{step}_scenario_lane_costs.csv", index=False); rb["lanes"].to_csv(f"{OUT}/step{step}_reference_lane_costs.csv", index=False)
        LOG[f"step{step}"] = L; json.dump(LOG, open(f"{OUT}/results.json", "w"), indent=1, default=str); print(step, "B done", round(time.time() - T0), flush=True)
    LOG["runtime_s"] = time.time() - T0; json.dump(LOG, open(f"{OUT}/results.json", "w"), indent=1, default=str)
