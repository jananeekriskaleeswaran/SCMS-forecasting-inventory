import os as _os_root
_HA_ROOT = _os_root.environ.get("HYBRID_ANN_ROOT") or _os_root.path.abspath(_os_root.path.join(_os_root.path.dirname(_os_root.path.abspath(__file__)), "..", "..", ".."))  # portable root
"""Descriptive check of what the order-book feature contains at each test origin (no forecasting). OB_t as in run_ob.py:
lines with ordered = min(PQ first sent, PO sent) < t and delivered >= t. Reports the share of OB_t quantity whose PO was NOT yet sent at t
(counted only because a price quote existed and the line was later ordered and delivered), and the share with missing PO date."""
import sys, json, numpy as np, pandas as pd
sys.path.insert(0, _HA_ROOT + "/technical_revision/orderbook_avla_20261113"); sys.path.insert(0, _HA_ROOT + "/technical_revision/avla_ann")
import importlib.util
spec = importlib.util.spec_from_file_location("run_ob", _HA_ROOT + "/technical_revision/orderbook_avla_20261113/run_ob.py"); ro = importlib.util.module_from_spec(spec); spec.loader.exec_module(ro)
r0 = pd.read_csv(_HA_ROOT + "/proj/data/scms_raw.csv", encoding="latin-1", low_memory=False)
r = ro.raw_lines(); s = r0["PO Sent to Vendor Date"].astype(str)
r["po"] = pd.to_datetime(s, format="%m-%d-%Y", errors="coerce").fillna(pd.to_datetime(s, format="%m/%d/%Y", errors="coerce"))
months = pd.date_range("2013-09-01", "2015-08-01", freq="MS"); rows = []
for m in months:
    inb = (r.ordered < m) & (r.deliv >= m); q = r.q[inb].sum()
    rows.append({"month": m, "OB_kpacks": q / 1000, "share_PO_not_yet_sent": r.q[inb & (r.po >= m)].sum() / q, "share_PO_missing": r.q[inb & r.po.isna()].sum() / q,
                 "share_delivered_in_month_t": r.q[inb & (r.deliv < m + pd.offsets.MonthBegin(1))].sum() / q})
D = pd.DataFrame(rows); print(D.round(3).to_string(index=False)); print(D.drop(columns="month").describe().round(3).to_string())
D.to_csv(_HA_ROOT + "/technical_revision/dm_main_comparators_20261117/audit/orderbook_composition_test_window.csv", index=False)
print("PO missing overall share of lines:", round(r.po.isna().mean(), 3), "| PO-missing text examples:", r0.loc[r.po.isna(), "PO Sent to Vendor Date"].value_counts().head(3).to_dict())
