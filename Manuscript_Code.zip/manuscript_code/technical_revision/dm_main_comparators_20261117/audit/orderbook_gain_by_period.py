import os as _os_root
_HA_ROOT = _os_root.environ.get("HYBRID_ANN_ROOT") or _os_root.path.abspath(_os_root.path.join(_os_root.path.dirname(_os_root.path.abspath(__file__)), "..", "..", ".."))  # portable root
"""Descriptive split of the order-book effect (AVLA-ANN tuned, seed 42, with vs without OB) into test months before and after the
order book becomes truncated by the dataset's end (Mar-2015 onward). Saved forecasts only; no fitting."""
import pandas as pd, numpy as np, json
o = pd.read_csv(_HA_ROOT + '/technical_revision/orderbook_avla_20261113/outputs/ensemble_forecasts.csv', parse_dates=['month'])
t = o[(o.config == 'tuned') & (o.seed == 42) & (o.month >= '2013-09-01') & (o.month <= '2015-08-01')]
a, b = t[t.ob].set_index('month'), t[~t.ob].set_index('month'); R = {}
for lab, (s, e) in {'Sep13-Feb15': ('2013-09-01', '2015-02-01'), 'Mar15-Aug15': ('2015-03-01', '2015-08-01'), 'all': ('2013-09-01', '2015-08-01')}.items():
    A, B = a.loc[s:e], b.loc[s:e]; sse = lambda x: float(((x.actual - x['AVLA-ANN']) ** 2).sum())
    R[lab] = {"n": len(A), "RMSE_with_OB": float(np.sqrt(sse(A) / len(A))), "RMSE_without_OB": float(np.sqrt(sse(B) / len(B))), "SSE_reduction_from_OB": sse(B) - sse(A)}
json.dump(R, open('orderbook_gain_by_period.json', 'w'), indent=1); print(json.dumps(R, indent=1))
