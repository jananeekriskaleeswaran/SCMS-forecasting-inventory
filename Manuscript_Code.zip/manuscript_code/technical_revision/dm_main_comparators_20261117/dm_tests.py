import os as _os_root
_HA_ROOT = _os_root.environ.get("HYBRID_ANN_ROOT") or _os_root.path.abspath(_os_root.path.join(_os_root.path.dirname(_os_root.path.abspath(__file__)), "..", ".."))  # portable root
"""DM-HLN tests per PREDECLARATION.md. No fitting, no forecasting: saved test-window forecasts only.
Forecast assembly copied from forecast_freeze_E1E2_20261116/e1_e2.py (same sources, same labels); RMSEs are checked against the frozen E2 table."""
import os, sys, json, hashlib, numpy as np, pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests
HERE = os.path.dirname(os.path.abspath(__file__)); OUT = f"{HERE}/outputs"
TR = _HA_ROOT + "/technical_revision"; sys.path.insert(0, _HA_ROOT + "/research_comparison/track_B_fair_benchmark")
from preprocessing import monthly_series
SRC_F1 = f"{TR}/reviewer_tests/forecast_benchmark/outputs/forecasts_all.csv"; SRC_OB = f"{TR}/orderbook_avla_20261113/outputs/ensemble_forecasts.csv"
E2T = f"{TR}/forecast_freeze_E1E2_20261116/outputs/E2_table_test.csv"
y = monthly_series(); A0, B0 = "2013-09-01", "2015-08-01"

f = pd.read_csv(SRC_F1, parse_dates=["month"])
LAB = {"ANN": "ANN (fixed manuscript configuration, MLP 128-64)", "AVLA-ANN (paper ensemble)": "AVLA-ANN (corrected, paper members)"}
rows = [pd.DataFrame({"model": LAB.get(m, m), "seed": s, "month": x.month, "pred": x.pred.values}) for (m, s), x in f.groupby(["model", "seed"])]
ob = pd.read_csv(SRC_OB, parse_dates=["month"])
obt = ob[ob.ob & (ob.config == "tuned")]
for col, name in (("AVLA-ANN", "AVLA-ANN + order book (pre-declared extension)"), ("ANN", "ANN + order book (member of extension)"), ("Equal weights", "Equal weights + order book")):
    rows += [pd.DataFrame({"model": name, "seed": s, "month": x.month, "pred": x[col].values}) for s, x in obt.groupby("seed")]
nob = ob[(~ob.ob) & (ob.config == "tuned")]
rows += [pd.DataFrame({"model": "AVLA-ANN (tuned members, no order book)", "seed": s, "month": x.month, "pred": x["AVLA-ANN"].values}) for s, x in nob.groupby("seed")]
idx = y.loc[A0:B0].index; ma12 = y.shift(1).rolling(12).mean()
rows.append(pd.DataFrame({"model": "MA(12)", "seed": 42, "month": idx, "pred": ma12.loc[idx].values}))
P = pd.concat(rows, ignore_index=True); P = P[(P.month >= A0) & (P.month <= B0)].copy(); P["actual"] = y.loc[P.month].values

def err(m, seed):
    x = P[P.model == m]
    if x.seed.nunique() > 1: x = x[x.seed == seed]
    x = x.sort_values("month"); assert len(x) == 24 and (x.month.values == idx.values).all(), (m, seed, len(x))
    return (x.actual - x.pred).values

def dm(e1, e2, loss="sq"):   # HLN-corrected DM, h = 1, two-sided, t(T-1); identical to orderbook_avla_20261113/analyze.py for squared loss
    d = (e1 ** 2 - e2 ** 2) if loss == "sq" else (np.abs(e1) - np.abs(e2)); T = len(d)
    s = d.mean() / np.sqrt(d.var(ddof=0) / T) * np.sqrt((T - 1) / T); return float(s), float(2 * stats.t.sf(abs(s), T - 1))

PROP = "AVLA-ANN + order book (pre-declared extension)"
PRIMARY = ["ARIMA(0,1,2)", "SES", "Random Forest (tuned)", "ANN (fixed manuscript configuration, MLP 128-64)", "MA(12)"]
ABL = ["AVLA-ANN (corrected, paper members)", "AVLA-ANN (tuned members, no order book)", "Equal weights + order book", "ANN + order book (member of extension)"]
rmse = lambda e: float(np.sqrt(np.mean(e ** 2)))

# RMSE check vs frozen E2 table (seed 42)
e2 = pd.read_csv(E2T).set_index("model"); chk = {}
for m in PRIMARY + ABL[:1] + ABL[2:] + [PROP]:
    chk[m] = abs(rmse(err(m, 42)) - e2.loc[m, "RMSE"])
assert max(chk.values()) < 1e-8, chk

def family(models, loss, seed=42, tag=""):
    ep = err(PROP, seed); R = []
    for m in models:
        ec = err(m, seed); s, p = dm(ep, ec, loss)
        R.append({"family": tag, "loss": loss, "seed": seed, "comparator": m, "RMSE_proposed": rmse(ep), "RMSE_comparator": rmse(ec),
                  "MAE_proposed": float(np.mean(np.abs(ep))), "MAE_comparator": float(np.mean(np.abs(ec))), "DM_HLN": s, "p": p,
                  "favours": "proposed" if s < 0 else "comparator"})
    R = pd.DataFrame(R); R["p_holm"] = multipletests(R.p, method="holm")[1]; R["significant_holm_0.05"] = R.p_holm < 0.05; return R

prim = family(PRIMARY, "sq", tag="primary"); s1 = family(PRIMARY, "abs", tag="S1 absolute loss"); s2 = family(ABL, "sq", tag="S2 ablation")
s3 = pd.concat([family(PRIMARY, "sq", seed=s, tag="S3 seed robustness") for s in (42, 1, 2, 3, 4, 5)], ignore_index=True)
pd.concat([prim, s1, s2], ignore_index=True).to_csv(f"{OUT}/dm_results.csv", index=False); s3.to_csv(f"{OUT}/dm_seed_robustness.csv", index=False)
s3r = s3.groupby("comparator").agg(p_min=("p", "min"), p_max=("p", "max"), p_holm_min=("p_holm", "min"), p_holm_max=("p_holm", "max"),
                                   any_sig=("significant_holm_0.05", "any"), DM_min=("DM_HLN", "min"), DM_max=("DM_HLN", "max")).reset_index()
s3r.to_csv(f"{OUT}/dm_seed_robustness_summary.csv", index=False)
h = lambda p: hashlib.sha256(open(p, "rb").read()).hexdigest()
json.dump({"predeclaration_sha256": h(f"{HERE}/PREDECLARATION.md"), "script_sha256": h(__file__),
           "inputs_sha256": {os.path.basename(p): h(p) for p in (SRC_F1, SRC_OB, E2T)}, "rmse_check_max_abs_diff": max(chk.values()),
           "any_primary_significant": bool(prim["significant_holm_0.05"].any()), "any_ablation_significant": bool(s2["significant_holm_0.05"].any()),
           "any_seed_significant": bool(s3["significant_holm_0.05"].any())}, open(f"{OUT}/provenance.json", "w"), indent=1)
pd.set_option("display.width", 250); cols = ["family", "comparator", "RMSE_proposed", "RMSE_comparator", "DM_HLN", "p", "p_holm", "favours"]
print(pd.concat([prim, s1, s2])[cols].to_string(index=False)); print(s3r.to_string(index=False)); print(json.load(open(f"{OUT}/provenance.json")))
