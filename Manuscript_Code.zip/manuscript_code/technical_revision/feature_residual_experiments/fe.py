"""Feature construction (strictly past-only) and the ANN forecasting function for Experiment A (SPEC_FROZEN.md)."""
import os as _os_root
_HA_ROOT = _os_root.environ.get("HYBRID_ANN_ROOT") or _os_root.path.abspath(_os_root.path.join(_os_root.path.dirname(_os_root.path.abspath(__file__)), "..", ".."))  # portable root (build_repo.py)
import sys, warnings, numpy as np, pandas as pd
from sklearn.preprocessing import MinMaxScaler
from sklearn.neural_network import MLPRegressor
sys.path.insert(0, f"{_HA_ROOT}/research_comparison/track_B_fair_benchmark")
from preprocessing import monthly_series

F0 = ["Month_Index", "S1", "S2", "Lag1", "Lag2", "RM3"]
SETS = {"F0": (F0, 3), "F1": (F0 + ["Lag3", "Lag6", "Lag12"], 12), "F2": (F0 + ["RM6", "RM12"], 12),
        "F3": (F0 + ["TR3", "SD6", "TR12"], 12),
        "F4": (F0 + ["Lag3", "Lag6", "Lag12", "RM6", "RM12", "TR3", "SD6", "TR12"], 12), "F0-r12": (F0, 12)}
ANN_DEFAULT = dict(hidden_layer_sizes=(128, 64), max_iter=800)
VAL0, TEST0, HIST0 = pd.Timestamp("2011-09-01"), pd.Timestamp("2013-09-01"), pd.Timestamp("2009-09-01")

def features(L):
    """Row r uses only L[:r] (shift(1) everywhere); Month_Index/S1/S2 are calendar-only."""
    p = L.shift(1); f = pd.DataFrame(index=L.index)
    f["Month_Index"] = np.arange(len(L)); f["S1"] = np.sin(2 * np.pi * L.index.month / 12); f["S2"] = np.cos(2 * np.pi * L.index.month / 12)
    for k in (1, 2, 3, 6, 12): f[f"Lag{k}"] = L.shift(k)
    for k in (3, 6, 12): f[f"RM{k}"] = p.rolling(k).mean()
    f["TR3"] = (L.shift(1) - L.shift(4)) / 3
    f["SD6"] = p.rolling(6).std(ddof=1)
    f["TR12"] = (p.rolling(3).mean() - L.shift(10).rolling(3).mean()) / 9   # mean(y_{t-1..t-3}) - mean(y_{t-10..t-12})
    return f

def forecast(L, t, fset, seed, ann=ANN_DEFAULT, return_scaler=False):
    """One-step forecast of month t using only L[:t]."""
    cols, r0 = SETS[fset]; Lp = L.iloc[:t + 1].copy(); Lp.iloc[-1] = np.nan
    F = features(Lp)[cols]; X, y = F.iloc[r0:t].values, Lp.iloc[r0:t].values; xt = F.iloc[[t]].values
    assert not np.isnan(X).any() and not np.isnan(xt).any() and not np.isnan(y).any()
    sc = MinMaxScaler().fit(X); Xs, xs = sc.transform(X), sc.transform(xt)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore"); m = MLPRegressor(random_state=seed, **ann).fit(Xs, y)
    p = float(m.predict(xs)[0])
    return (p, sc, X) if return_scaler else p

def origins(L):
    idx = list(L.index); return list(range(idx.index(HIST0), len(L)))
