"""Analysis per PREDECLARATION.md: reproduction check, validation-only selection, test metrics (both R² definitions), DM-HLN + Holm,
longer-window robustness, forward projection Sep-2015..Aug-2016 (paper AVLA–ANN without OB). Writes outputs/*.csv|json|png."""
import os as _os_root
_HA_ROOT = _os_root.environ.get("HYBRID_ANN_ROOT") or _os_root.path.abspath(_os_root.path.join(_os_root.path.dirname(_os_root.path.abspath(__file__)), "..", ".."))  # portable root (build_repo.py)
import os
for v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"): os.environ.setdefault(v, "1")
import sys, json, warnings, numpy as np, pandas as pd
from scipy import stats
HERE = os.path.dirname(os.path.abspath(__file__)); OUT = f"{HERE}/outputs"; sys.path.insert(0, HERE)
import run_ob as R
warnings.filterwarnings("ignore")
y = R.monthly_series(); IDX = list(y.index)
EF = pd.read_csv(f"{OUT}/ensemble_forecasts.csv", parse_dates=["month"]); SEEDS = sorted(EF.seed.unique()); S42 = 42
WIN = {"validation": ("2011-09-01", "2013-08-01"), "test": ("2013-09-01", "2015-08-01"), "robustness (Sep-2010..Aug-2015)": ("2010-09-01", "2015-08-01")}
naive = y.shift(1); ma12 = y.shift(1).rolling(12).mean()
hm = {s: pd.Series({t: y[(y.index >= s) & (y.index < t)].mean() for t in y.index[24:]}) for s in ("2007-01-01", "2009-01-01")}

def metrics(a, p, months):
    e = a - p; rm = float(np.sqrt(np.mean(e ** 2)))
    out = {"n": len(e), "RMSE": rm, "MAE": float(np.mean(np.abs(e))), "MAPE %": float(100 * np.mean(np.abs(e / a))),
           "R2 (vs window mean)": float(1 - np.sum(e ** 2) / np.sum((a - a.mean()) ** 2))}
    for s, h in hm.items(): out[f"R2 vs historical mean from {s[:7]}"] = float(1 - np.sum(e ** 2) / np.sum((a - h.loc[months].values) ** 2))
    out["Skill vs naive"] = 1 - rm / float(np.sqrt(np.mean((a - naive.loc[months].values) ** 2)))
    out["Skill vs MA(12)"] = 1 - rm / float(np.sqrt(np.mean((a - ma12.loc[months].values) ** 2)))
    return out

def dm(e1, e2):
    d = e1 ** 2 - e2 ** 2; T = len(d); s = d.mean() / np.sqrt(d.var(ddof=0) / T) * np.sqrt((T - 1) / T); return float(s), float(2 * stats.t.sf(abs(s), T - 1))
def holm(p):
    p = np.asarray(p); o = np.argsort(p); k = len(p); adj = np.empty(k); run = 0
    for r, i in enumerate(o): run = max(run, min(1, (k - r) * p[i])); adj[i] = run
    return adj

def series(ob, cfg, seed, col):
    d = EF[(EF.ob == ob) & (EF.config == cfg) & (EF.seed == seed)].set_index("month").sort_index(); return d[col]

def win(s, w): a, b = WIN[w]; return s.loc[a:b]

RES = {}
# ---- 1. reproduction of the paper results (no OB, manuscript configuration, seed 42) ----
paper_avla = series(False, "manuscript", S42, "AVLA-ANN"); paper_ann = series(False, "manuscript", S42, "ANN")
FA = pd.read_csv(f"{_HA_ROOT}/technical_revision/reviewer_tests/forecast_benchmark/outputs/forecasts_all.csv", parse_dates=["month"])
f_ann = FA[(FA.model == "ANN") & (FA.seed == 42)].set_index("month").pred
rt = win(paper_avla, "test"); RES["reproduction"] = {"paper_AVLA_ANN_test_RMSE": float(np.sqrt(np.mean((y.loc[rt.index] - rt) ** 2))), "expected": 1081.8855153337302,
    "ANN_member_vs_benchmark_ANN_max_abs_diff": float((paper_ann.loc[f_ann.index] - f_ann).abs().max())}
RES["reproduction"]["pass"] = bool(abs(RES["reproduction"]["paper_AVLA_ANN_test_RMSE"] - 1081.8855153337302) < 1e-6 and RES["reproduction"]["ANN_member_vs_benchmark_ANN_max_abs_diff"] < 1e-6)
# ---- 2. validation-only selection ----
def mean_val_rmse(ob, cfg):
    return float(np.mean([np.sqrt(np.mean((y.loc[win(series(ob, cfg, s, 'AVLA-ANN'), 'validation').index] - win(series(ob, cfg, s, 'AVLA-ANN'), 'validation')) ** 2)) for s in SEEDS]))
sel = {f"ob={ob}, {cfg}": mean_val_rmse(ob, cfg) for ob in (False, True) for cfg in ("manuscript", "tuned")}
cfg_sel = min(("manuscript", "tuned"), key=lambda c: sel[f"ob=True, {c}"])
RES["selection"] = {"mean_validation_RMSE_AVLA_ANN": sel, "seeds_used": [int(s) for s in SEEDS], "selected_config_with_OB": cfg_sel,
                    "improves_on_paper_AVLA_ANN_on_validation": bool(sel[f"ob=True, {cfg_sel}"] < sel["ob=False, manuscript"])}
# ---- 3. tables for validation, test, robustness ----
MODELS = {"AVLA-ANN + order book (selected)": (True, cfg_sel, "AVLA-ANN"), "ANN + order book (member)": (True, cfg_sel, "ANN"), "RF + order book (member)": (True, cfg_sel, "RF"),
          "GBR + order book (member)": (True, cfg_sel, "GB"), "Equal weights + order book": (True, cfg_sel, "Equal weights"),
          "AVLA-ANN (paper, corrected)": (False, "manuscript", "AVLA-ANN"), "ANN (paper, corrected)": (False, "manuscript", "ANN"), "AVLA-ANN (tuned members, no order book)": (False, "tuned", "AVLA-ANN")}
for w in WIN:
    rows = []
    for name, (ob, cfg, col) in MODELS.items():
        s42 = win(series(ob, cfg, S42, col), w); m = metrics(y.loc[s42.index].values, s42.values, s42.index)
        per = [metrics(y.loc[win(series(ob, cfg, s, col), w).index].values, win(series(ob, cfg, s, col), w).values, win(series(ob, cfg, s, col), w).index) for s in SEEDS]
        rows.append({"model": name, **m, "RMSE mean (seeds)": np.mean([p["RMSE"] for p in per]), "RMSE SD (seeds)": np.std([p["RMSE"] for p in per], ddof=1) if len(per) > 1 else np.nan,
                     "R2 (vs window mean) mean (seeds)": np.mean([p["R2 (vs window mean)"] for p in per]), "n seeds": len(per)})
    months = win(series(True, cfg_sel, S42, "AVLA-ANN"), w).index
    for name, p in (("MA(12)", ma12), ("Naive", naive)): rows.append({"model": name, **metrics(y.loc[months].values, p.loc[months].values, months), "n seeds": 1})
    T = pd.DataFrame(rows).sort_values("RMSE"); T.to_csv(f"{OUT}/table_{w.split(' ')[0]}.csv", index=False); RES[f"table_{w.split(' ')[0]}"] = T.round(4).to_dict("records")
# ---- 4. DM-HLN on test (seed 42): Holm m = 2; MA(12) descriptive ----
sel42 = win(series(True, cfg_sel, S42, "AVLA-ANN"), "test"); a = y.loc[sel42.index].values; e_sel = a - sel42.values; tests = []
for name, s in (("AVLA-ANN (paper, corrected)", win(paper_avla, "test")), ("ANN (paper, corrected)", win(paper_ann, "test"))):
    st, p = dm(e_sel, a - s.loc[sel42.index].values); tests.append({"comparison": f"AVLA-ANN + order book vs {name}", "RMSE_new": float(np.sqrt(np.mean(e_sel ** 2))),
                                                                    "RMSE_ref": float(np.sqrt(np.mean((a - s.loc[sel42.index].values) ** 2))), "DM_HLN": st, "p": p})
ph = holm([t["p"] for t in tests]); [t.update(p_holm=float(h)) for t, h in zip(tests, ph)]
st, p = dm(e_sel, a - ma12.loc[sel42.index].values); tests.append({"comparison": "AVLA-ANN + order book vs MA(12) (descriptive, not in Holm family)", "RMSE_new": float(np.sqrt(np.mean(e_sel ** 2))),
                                                                   "RMSE_ref": float(np.sqrt(np.mean((a - ma12.loc[sel42.index].values) ** 2))), "DM_HLN": st, "p": p, "p_holm": None})
pd.DataFrame(tests).to_csv(f"{OUT}/dm_tests_test.csv", index=False); RES["dm_tests_test"] = tests
W42 = EF[(EF.ob) & (EF.config == cfg_sel) & (EF.seed == S42)]; RES["avla_weights_test_mean"] = W42[W42.month >= "2013-09-01"][["wA_ANN", "wA_RF", "wA_GB"]].mean().round(3).to_dict()
RES["avla_vs_exact_max_rel_gap"] = float(EF.gap_rel.max())

# ---- 5. forward projection Sep-2015..Aug-2016: paper AVLA-ANN (manuscript cfg, no OB), seed 42 ----
from sklearn.preprocessing import MinMaxScaler
from sklearn.neural_network import MLPRegressor
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
C = R.MB.CFGS["manuscript"]; Tn = len(y); F = R.MB.features(y); X = F.iloc[3:Tn].values; Y = y.iloc[3:Tn].values; sc = MinMaxScaler().fit(X)
mods = [MLPRegressor(random_state=S42, **C["ANN"]).fit(sc.transform(X), Y), RandomForestRegressor(random_state=S42, n_jobs=1, **C["RF"]).fit(sc.transform(X), Y),
        GradientBoostingRegressor(random_state=S42, **C["GB"]).fit(sc.transform(X), Y)]
last = EF[(~EF.ob) & (EF.config == "manuscript") & (EF.seed == S42)].sort_values("month").tail(12)
w, _ = R.avla_weights(last[R.M].values, last.actual.values, S42)
fut = pd.date_range("2015-09-01", periods=12, freq="MS")
def feat_rows(paths, idx, month):   # identical to members.features for row idx (verified below)
    return np.column_stack([np.full(len(paths), idx), np.full(len(paths), np.sin(2 * np.pi * month / 12)), np.full(len(paths), np.cos(2 * np.pi * month / 12)),
                            paths[:, idx - 1], paths[:, idx - 2], paths[:, idx - 3:idx].mean(1)])
H = np.tile(y.values, (1, 1)); assert np.allclose(feat_rows(H, Tn - 1, y.index[-1].month)[0], F.iloc[Tn - 1].values)
errs = (y.loc[rt.index] - rt).values   # 24 one-step test errors of the paper AVLA-ANN
def run_paths(n, noise, rng):
    P = np.hstack([np.tile(y.values, (n, 1)), np.zeros((n, 12))])
    for h, m in enumerate(fut):
        idx = Tn + h; Xh = sc.transform(feat_rows(P, idx, m.month)); f = np.column_stack([mm.predict(Xh) for mm in mods]) @ w
        P[:, idx] = np.maximum(f + (rng.choice(errs, n) if noise else 0.0), 0.0)   # demand cannot be negative (added after a provisional run showed a negative 2.5% bound)
    return P[:, Tn:]
point = run_paths(1, False, None)[0]; B = run_paths(2000, True, np.random.default_rng(7))
PJ = pd.DataFrame({"month": fut, "projection": point, "p10": np.percentile(B, 10, 0), "p90": np.percentile(B, 90, 0), "p2.5": np.percentile(B, 2.5, 0), "p97.5": np.percentile(B, 97.5, 0)})
PJ.to_csv(f"{OUT}/forward_projection_2015_2016.csv", index=False)
RES["forward_projection"] = {"model": "AVLA-ANN (paper, corrected), manuscript configuration, no order book, seed 42", "weights_ANN_RF_GB": [float(v) for v in w],
                             "intervals": "residual bootstrap, 2,000 recursive paths, resampling the 24 one-step test errors; simulated values floored at 0 (non-negative demand; change made after a provisional run, documented)", "status": "projection only; no accuracy claim",
                             "annual_total_kpacks": float(point.sum())}
json.dump(RES, open(f"{OUT}/summary.json", "w"), indent=1, default=float)

# ---- 6. figures ----
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
INK, MUTED, A, B2 = "#1f2328", "#6e7781", "#2f6fdf", "#d4693a"
fig, ax = plt.subplots(figsize=(9, 4), dpi=200); tm = sel42.index
ax.plot(tm, y.loc[tm], color=INK, lw=2, marker="o", ms=3, label="Actual")
ax.plot(tm, sel42.values, color=A, lw=2, label="AVLA–ANN + order book")
ax.plot(tm, win(paper_avla, "test").loc[tm], color=B2, lw=2, ls="--", label="AVLA–ANN (paper, corrected)")
ax.set_ylabel("Monthly delivered quantity (thousand packs)"); ax.set_title("Test window Sep-2013 to Aug-2015, one-month-ahead forecasts", fontsize=10, loc="left")
for s in ("top", "right"): ax.spines[s].set_visible(False)
ax.grid(axis="y", color="#e5e7eb", lw=0.6); ax.legend(frameon=False, fontsize=8); fig.tight_layout(); fig.savefig(f"{OUT}/fig_test_forecasts.png"); plt.close(fig)
fig, ax = plt.subplots(figsize=(9, 4), dpi=200); h0 = y.loc["2012-01-01":]
ax.plot(h0.index, h0.values, color=INK, lw=2, label="Actual (to Aug-2015)")
ax.fill_between(PJ.month, PJ["p2.5"], PJ["p97.5"], color=A, alpha=0.15, lw=0, label="95% interval"); ax.fill_between(PJ.month, PJ.p10, PJ.p90, color=A, alpha=0.3, lw=0, label="80% interval")
ax.plot(PJ.month, PJ.projection, color=A, lw=2, label="AVLA–ANN projection")
ax.set_ylabel("Monthly delivered quantity (thousand packs)"); ax.set_title("Forward projection Sep-2015 to Aug-2016 (no actuals available; illustration only)", fontsize=10, loc="left")
for s in ("top", "right"): ax.spines[s].set_visible(False)
ax.grid(axis="y", color="#e5e7eb", lw=0.6); ax.legend(frameon=False, fontsize=8); fig.tight_layout(); fig.savefig(f"{OUT}/fig_forward_projection.png"); plt.close(fig)
print(json.dumps({k: RES[k] for k in ("reproduction", "selection", "dm_tests_test", "avla_weights_test_mean")}, indent=1, default=float))
