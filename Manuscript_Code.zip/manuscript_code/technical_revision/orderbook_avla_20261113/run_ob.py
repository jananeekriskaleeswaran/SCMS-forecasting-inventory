"""AVLA–ANN with an open-order-book input (PREDECLARATION.md). Stage 1: member forecasts; stage 2: AVLA weights.
Usage: python run_ob.py  -> outputs/member_forecasts.csv, outputs/ensemble_forecasts.csv, outputs/ob_checks.json"""
import os as _os_root
_HA_ROOT = _os_root.environ.get("HYBRID_ANN_ROOT") or _os_root.path.abspath(_os_root.path.join(_os_root.path.dirname(_os_root.path.abspath(__file__)), "..", ".."))  # portable root (build_repo.py)
import os
for v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"): os.environ.setdefault(v, "1")
import sys, json, time, warnings, numpy as np, pandas as pd
from joblib import Parallel, delayed
HERE = os.path.dirname(os.path.abspath(__file__)); OUT = f"{HERE}/outputs"; os.makedirs(OUT, exist_ok=True)
TR = f"{_HA_ROOT}/technical_revision"; TB = f"{_HA_ROOT}/research_comparison/track_B_fair_benchmark"
sys.path.insert(0, TB); sys.path.insert(0, f"{TR}/avla_ann")
from preprocessing import monthly_series
import members as MB                       # paper features() and CFGS (unchanged)
from weighting import avla_weights, to_w   # paper AVLA weighting (unchanged)
from exact import opt_simplex
from sklearn.preprocessing import MinMaxScaler
from sklearn.neural_network import MLPRegressor
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
SEEDS = [42, 1, 2, 3, 4, 5]; W = 12; M = ["ANN", "RF", "GB"]

def raw_lines():
    r = pd.read_csv(f"{_HA_ROOT}/proj/data/scms_raw.csv", encoding="latin-1", low_memory=False)
    r["deliv"] = pd.to_datetime(r["Delivered to Client Date"], format="%d-%b-%y")
    for c, n in (("PQ First Sent to Client Date", "pq"), ("PO Sent to Vendor Date", "po")):
        s = r[c].astype(str); r[n] = pd.to_datetime(s, format="%m-%d-%Y", errors="coerce").fillna(pd.to_datetime(s, format="%m/%d/%Y", errors="coerce"))
    r["ordered"] = r[["pq", "po"]].min(axis=1); return r[["deliv", "ordered", "Line Item Quantity"]].rename(columns={"Line Item Quantity": "q"})

def order_book(r, months):
    """OB_t: quantity (thousand packs) of lines ordered before month t and not yet delivered at the start of month t."""
    return pd.Series([r.q[(r.ordered < m) & (r.deliv >= m)].sum() / 1000.0 for m in months], index=months)

def forecast(y, ob, t, cfg, seed, use_ob):
    Lp = y.iloc[:t + 1].copy(); Lp.iloc[-1] = np.nan; F = MB.features(Lp)
    if use_ob: F["OB"] = ob.values[:t + 1]
    X, yy, xt = F.iloc[3:t].values, Lp.iloc[3:t].values, F.iloc[[t]].values
    sc = MinMaxScaler().fit(X); X, xt = sc.transform(X), sc.transform(xt); C = MB.CFGS[cfg]; out = {}
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        out["ANN"] = MLPRegressor(random_state=seed, **C["ANN"]).fit(X, yy).predict(xt)[0]
        out["RF"] = RandomForestRegressor(random_state=seed, n_jobs=1, **C["RF"]).fit(X, yy).predict(xt)[0]
        out["GB"] = GradientBoostingRegressor(random_state=seed, **C["GB"]).fit(X, yy).predict(xt)[0]
    return out

def weights_one(d, seed):
    d = d.sort_values("t").reset_index(drop=True); rows = []
    for i in range(W, len(d)):
        past = d.iloc[i - W:i]; P, a = past[M].values, past.actual.values; p = d.loc[i, M].values.astype(float)
        wa, fa = avla_weights(P, a, seed); we = opt_simplex(P, a, verify=False); fe = np.sqrt(np.mean((a - P @ we) ** 2))
        rows.append({"month": d.loc[i, "month"], "t": d.loc[i, "t"], "actual": d.loc[i, "actual"], **{m: p[j] for j, m in enumerate(M)},
                     "AVLA-ANN": p @ wa, "Equal weights": p.mean(), "Exact optimum": p @ we, "wA_ANN": wa[0], "wA_RF": wa[1], "wA_GB": wa[2],
                     "gap_rel": (fa - fe) / fe})
    return rows

if __name__ == "__main__":
    T0 = time.time(); y = monthly_series(); r = raw_lines(); ob = order_book(r, y.index)
    # ---- order-book availability checks ----
    chk = {}
    contrib_ok = all((r[(r.ordered < m) & (r.deliv >= m)].ordered < m).all() for m in y.index); chk["1_only_lines_ordered_before_t"] = bool(contrib_ok)
    rng = np.random.default_rng(0); ok = True
    for m in y.index[24::6]:
        r2 = r.copy(); fut = r2.deliv >= m; r2.loc[fut, "deliv"] = m + pd.to_timedelta(rng.integers(0, 2000, fut.sum()), unit="D")
        ok &= bool(np.isclose(order_book(r2, [m]).iloc[0], ob.loc[m]))
    chk["2_invariant_to_future_delivery_timing"] = ok
    ok = True
    for m in y.index[24::6]:
        r2 = r.copy(); sel = (r2.deliv >= m) & (r2.deliv < m + pd.DateOffset(months=1)) & r2.ordered.isna(); r2.loc[sel, "q"] = 1e12
        ok &= bool(np.isclose(order_book(r2, [m]).iloc[0], ob.loc[m]))
    chk["3_invariant_to_month_t_quantities_of_lines_without_order_date"] = ok
    chk["series_check_max_abs_diff_vs_raw_delivered_sum"] = float((y - r.groupby(r.deliv.dt.to_period("M")).q.sum().div(1000).reindex(y.index.to_period("M")).values).abs().max())
    pd.DataFrame({"y": y, "OB": ob}).to_csv(f"{OUT}/series_and_order_book.csv")
    t0 = list(y.index).index(pd.Timestamp("2009-09-01")); O = list(range(t0, len(y)))
    jobs = [(c, s, t, u) for u in (False, True) for c in ("manuscript", "tuned") for s in SEEDS for t in O]
    res = Parallel(n_jobs=2)(delayed(forecast)(y, ob, t, c, s, u) for c, s, t, u in jobs)
    MF = pd.DataFrame([{"ob": u, "config": c, "seed": s, "t": t, "month": y.index[t], "actual": y.iloc[t], **o} for (c, s, t, u), o in zip(jobs, res)])
    MF.to_csv(f"{OUT}/member_forecasts.csv", index=False); chk["member_stage_seconds"] = round(time.time() - T0)
    groups = [(u, c, s) for u in (False, True) for c in ("manuscript", "tuned") for s in SEEDS]
    groups = [g for g in groups if g[2] == 42] + [g for g in groups if g[2] != 42]          # primary seed first
    parts = []
    for batch in (groups[:4], groups[4:]):
        WR = Parallel(n_jobs=2)(delayed(weights_one)(MF[(MF.ob == u) & (MF.config == c) & (MF.seed == s)], s) for u, c, s in batch)
        parts += [pd.DataFrame(w).assign(ob=u, config=c, seed=s) for (u, c, s), w in zip(batch, WR)]
        EF = pd.concat(parts, ignore_index=True); EF.to_csv(f"{OUT}/ensemble_forecasts.csv", index=False)
        print("weights saved for seeds", sorted(EF.seed.unique()), round(time.time() - T0), "s", flush=True)
    chk["avla_vs_exact_max_rel_gap"] = float(EF.gap_rel.max()); chk["avla_vs_exact_pass_1e-6"] = bool(EF.gap_rel.max() <= 1e-6)
    chk["total_seconds"] = round(time.time() - T0); json.dump(chk, open(f"{OUT}/ob_checks.json", "w"), indent=1); print(json.dumps(chk, indent=1))
