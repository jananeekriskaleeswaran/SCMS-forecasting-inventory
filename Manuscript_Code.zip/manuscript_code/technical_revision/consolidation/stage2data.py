"""Parametrised Stage 2 data builder (SPEC addendum): everything re-derived from data <= T_END."""
import os as _os_root
_HA_ROOT = _os_root.environ.get("HYBRID_ANN_ROOT") or _os_root.path.abspath(_os_root.path.join(_os_root.path.dirname(_os_root.path.abspath(__file__)), "..", ".."))  # portable root (build_repo.py)
import sys, itertools, numpy as np, pandas as pd
from types import SimpleNamespace
sys.path.insert(0, f"{_HA_ROOT}/proj/src"); sys.path.insert(0, f"{_HA_ROOT}/technical_revision/pso_stage")
from common import load_raw
from shipments import build_shipments, lane_shipment_lines, weight_per_pack
import cost3 as C3
RAW = load_raw(); SHIP = build_shipments(RAW); SHIP["opt"] = SHIP.fulfill + "|" + SHIP["mode"].astype(str)
FV = RAW.groupby("ASN/DN #")["Fulfill Via"].first(); LINES = lane_shipment_lines(RAW); LINES["fulfill"] = LINES["ASN/DN #"].map(FV)
LINES["opt"] = LINES.fulfill + "|" + LINES["mode"].astype(str); WPP = weight_per_pack(RAW, SHIP)
PRICE_AS = {"Direct Drop|Air Charter": "Direct Drop|Air", "From RDC|Ocean": "From RDC|Truck"}
rmse = lambda e: float(np.sqrt(np.mean(np.square(e))))

def _cv(T_END):
    A = pd.concat([pd.read_csv(f"{_HA_ROOT}/technical_revision/ann_improvement/outputs/forecasts_{p}_singles.csv") for p in ("val", "test")])
    A = A[(A.candidate == "B0") & (A.seed == 42)].copy(); A["month"] = pd.to_datetime(A.month)
    w = A[(A.month > T_END - pd.DateOffset(months=24)) & (A.month <= T_END)]; assert len(w) == 24, len(w)
    return rmse(w.actual - w.pred) / w.actual.mean()

def build(T_END):
    T_END = pd.Timestamp(T_END); E0 = T_END + pd.Timedelta(days=1); E1 = T_END + pd.DateOffset(years=1)
    B = SimpleNamespace(T_END=T_END, E0=E0, E1=E1); s_tr = SHIP[SHIP.date <= T_END]
    def ffr(s):
        s = s[s.opt.isin(C3.MODELLED) & (s.W > 0) & (s.F > 0)].copy(); s["fpk"] = s.F / s.W; return s
    fr_tr = ffr(s_tr); lo, hi = fr_tr.fpk.quantile([.01, .99]); fr_tr = fr_tr[fr_tr.fpk.between(lo, hi)]
    fr_ev = ffr(SHIP[(SHIP.date >= E0) & (SHIP.date <= E1)]); fr_ev = fr_ev[fr_ev.country.isin(fr_tr.country.unique())]
    B.FM = {"ANN": C3.ANNFreight().fit(fr_tr), "OLS": C3.OLSFreight().fit(fr_tr)}; B.fr_tr, B.fr_ev = fr_tr, fr_ev
    B.freight_validation = {k: {"eval_RMSE_log": rmse(np.log(m.predict(fr_ev.W.values, fr_ev.opt.values, fr_ev.country.values)) - np.log(fr_ev.F.values)), "n_eval": len(fr_ev)} for k, m in B.FM.items()}
    lt = s_tr[s_tr.lead_time_days.between(0, 400) & (s_tr.fulfill == "Direct Drop")]
    LT = {f"Direct Drop|{m}": (float(g.lead_time_days.median()), float(g.lead_time_days.std())) for m, g in lt.groupby("mode") if m in ("Air", "Ocean", "Truck")}
    LT["Direct Drop|Air Charter"] = LT["Direct Drop|Air"]
    for m in ("Air", "Air Charter", "Truck", "Ocean"): LT[f"From RDC|{m}"] = (30.0, 15.0)
    B.LT = LT; B.CV = _cv(T_END)
    wpp_tr = WPP[WPP.date <= T_END]; w_lane = wpp_tr.groupby(["Country", "Item Description"]).wpp.median(); w_item = wpp_tr.groupby("Item Description").wpp.median()
    L2 = LINES[(LINES.date <= T_END) & (LINES.date > T_END - pd.DateOffset(years=2))]; Lev = LINES[(LINES.date >= E0) & (LINES.date <= E1)]
    nch = L2.groupby(["Country", "Item Description"]).fulfill.nunique(); lanes = []
    for (cty, item, ch), d in L2.groupby(["Country", "Item Description", "fulfill"]):
        if d["ASN/DN #"].nunique() < 4: continue
        D = d[d.date > T_END - pd.DateOffset(years=1)].packs.sum(); ev = Lev[(Lev.Country == cty) & (Lev["Item Description"] == item) & (Lev.fulfill == ch)]
        if D <= 0 or ev.packs.sum() <= 0: continue
        w = w_lane.get((cty, item), np.nan); wsrc = "lane"
        if not np.isfinite(w): w, wsrc = w_item.get(item, np.nan), "item"
        if not np.isfinite(w) or w <= 0: continue
        used = sorted(set(d.opt)); opts = [o for o in used if o in C3.MODELLED]
        if not opts and used == [C3.EMBEDDED]: opts = [C3.EMBEDDED]
        if not opts: continue
        dom = d.groupby("opt").packs.sum().idxmax(); dom = dom if dom in opts else opts[0]; per_ship = d.groupby("ASN/DN #").packs.sum()
        lanes.append(dict(country=cty, item=item, channel=ch, opts=opts, dom_opt=dom, D_plan=float(D), D_act=float(ev.packs.sum()), c=float(d.pack_price.median()),
                          w=float(w), w_source=wsrc, qmin_obs=float(per_ship.min()), qmax_obs=float(per_ship.max()), n_ship_2y=int(d["ASN/DN #"].nunique()), mixed_channel_history=int(nch[(cty, item)] > 1)))
    B.lanes = lanes; key = {(l["country"], l["item"], l["channel"]): i for i, l in enumerate(lanes)}; B.key = key
    ship_i = SHIP.set_index("ASN/DN #"); obs = []
    for asn, li in Lev[[k in key for k in zip(Lev.Country, Lev["Item Description"], Lev.fulfill)]].groupby("ASN/DN #"):
        srow = ship_i.loc[asn]; allli = Lev[Lev["ASN/DN #"] == asn]
        wmod = np.array([p * (lanes[key[(c, it, f)]]["w"] if (c, it, f) in key else w_lane.get((c, it), w_item.get(it, np.nan))) for p, c, it, f in zip(allli.packs, allli.Country, allli["Item Description"], allli.fulfill)])
        share_all = wmod / wmod.sum() if np.isfinite(wmod).all() and wmod.sum() > 0 else allli.packs.values / allli.packs.sum()
        W_ship = srow.W if srow.W > 0 else float(np.nansum(wmod)); opt = srow.opt if srow.opt in C3.MODELLED + [C3.EMBEDDED] + list(PRICE_AS) else None
        for (_, x), shr in zip(allli.iterrows(), share_all):
            k = (x.Country, x["Item Description"], x.fulfill)
            if k not in key: continue
            L = lanes[key[k]]; o = opt if opt else L["dom_opt"]
            obs.append({"lane": key[k], "asn": asn, "opt_recorded": srow.opt, "opt_priced": PRICE_AS.get(o, o), "packs": x.packs, "share": float(shr), "W_ship": float(W_ship), "w": L["w"], "country": L["country"]})
    B.OBS = pd.DataFrame(obs)
    # bundles and weight caps
    tr = L2.copy(); tr["lane"] = [key.get(k, -1) for k in zip(tr.Country, tr["Item Description"], tr.fulfill)]
    B.obs_sets = sorted({tuple(sorted(set(g.lane) - {-1})) for _, g in tr.groupby("ASN/DN #") if len(set(g.lane) - {-1}) >= 2})
    B.bundles = sorted({tuple(c) for s in B.obs_sets for r in range(2, len(s) + 1) for c in itertools.combinations(s, r)})
    sh = s_tr[s_tr.W > 0]; B.WCAP = sh.groupby(["opt", "country"]).W.max().to_dict(); B.WCAP_OPT = sh.groupby("opt").W.max().to_dict()
    # quarterly demand and trailing-12 plans
    B.TAUS = [E0 + pd.DateOffset(months=3 * k) for k in range(4)]
    ser = {i: LINES[(LINES.Country == l["country"]) & (LINES["Item Description"] == l["item"]) & (LINES.fulfill == l["channel"])][["date", "packs"]] for i, l in enumerate(lanes)}
    dem = lambda i, a, b: float(ser[i][(ser[i].date >= a) & (ser[i].date < b)].packs.sum())
    B.QDEM = {i: [dem(i, t, t + pd.DateOffset(months=3)) for t in B.TAUS] for i in range(len(lanes))}
    B.DPLAN = {i: [dem(i, t - pd.DateOffset(months=12), t) for t in B.TAUS] for i in range(len(lanes))}
    for i in range(len(lanes)): assert abs(sum(B.QDEM[i]) - lanes[i]["D_act"]) < 1e-6 * lanes[i]["D_act"] and abs(B.DPLAN[i][0] - lanes[i]["D_plan"]) < 1e-6 * lanes[i]["D_plan"]
    return B
