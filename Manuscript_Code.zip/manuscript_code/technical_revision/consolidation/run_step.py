"""Run Step 2 (T_END 2013-08-31) or Step 3 (T_END 2014-08-31) exactly as frozen. Usage: python3 run_step.py 2|3"""
import sys, os, json, time, hashlib, warnings, numpy as np, pandas as pd
from multiprocessing import Pool
warnings.filterwarnings("ignore")
import stage2data as SD, engine as E
STEP = int(sys.argv[1]); T_END = {2: "2013-08-31", 3: "2014-08-31"}[STEP]; OUT = f"outputs/step{STEP}"; os.makedirs(OUT, exist_ok=True)
B = SD.build(T_END)

def cases():
    c = [("base", "", {}), ("freight-only", "K=0", {"K": 0.0})]
    c += [("h", v, {"h": v}) for v in (0.10, 0.15, 0.25, 0.30, 0.40)]
    c += [("K", v, {"K": v}) for v in (250.0, 500.0, 2000.0, 4000.0)]
    c += [("z", v, {"z": v}) for v in (1.282, 2.054, 2.326)]
    c += [("RDC lead time (d)", v, {"rdc_lt": {f"From RDC|{m}": (float(v), v / 2) for m in ("Air", "Air Charter", "Truck", "Ocean")}}) for v in (7, 14, 60)]
    c += [("RDC Air 2x faster", "Air 15 d", {"rdc_lt": {"From RDC|Air": (15.0, 7.5)}})]
    c += [("sigma multiplier", v, {"cv_mult": v}) for v in (0.5, 1.5, 2.0)]
    c += [(f"freight x [{o}]", v, {"fmult": {o: v}}) for o in C3.MODELLED for v in (0.7, 1.3)]
    c += [("freight model", "OLS", {"fm": "OLS"}), ("Q cap (months)", 3.0, {"cap": 3.0}), ("Q cap (months)", 12.0, {"cap": 12.0})]
    return c
C3 = SD.C3

def run_case(args):
    name, val, p = args; t0 = time.time(); e = E.Engine(B, p); res, plans = e.run_all()
    tot = {k: float(v.total.sum()) for k, v in res.items()}
    comp = {k: {c: float(v[c].sum()) for c in E.PARTS} for k, v in res.items()}
    lanes = pd.concat([v.assign(policy=k) for k, v in res.items()]) if name in ("base", "freight-only") or (name == "K" and val == 250.0) else None
    summ = {pol: {"bundles_q": [sum(len(b) > 1 for b, _, _ in u) for u in plans[pol]], "lanes_bundled_q": [sum(len(b) for b, _, _ in u if len(b) > 1) for u in plans[pol]]} for pol in E.POLICIES}
    dec = [{"policy": pol, "q": q, "bundle": "/".join(map(str, b)), "size": len(b), "opt": o, "T_years": T} for pol in E.POLICIES for q, u in enumerate(plans[pol]) for b, o, T in u] if name == "base" else None
    return dict(name=name, value=str(val), totals=tot, components=comp, lanes=lanes, plan_summary=summ, decisions=dec, runtime_s=time.time() - t0)

def pso_check(seeds=range(1, 11), n_random=200):
    e = E.Engine(B); rows = []; rng = np.random.default_rng(2024); dp_diff = []
    cons = e.plan("CONSOLIDATED")
    for q in range(4):
        D = {i: B.DPLAN[i][q] for i in range(e.N)}; tb = e.bundle_table(q, "all"); single = e.bundle_table(q, "single")
        chosen = {b for b, _, _ in cons[q] if b in tb or b in single}; feas = sorted(tb); rnd = [feas[j] for j in rng.choice(len(feas), min(n_random, len(feas)), replace=False)]
        probs = sorted(chosen | set(rnd)); pso_cost = {s: {} for s in seeds}
        for b in probs:
            ex = (tb.get(b) or single.get(b))
            for s in seeds:
                r = e.solve_pso(b, D, seed=s); pso_cost[s][b] = r[0]
                rows.append({"q": q, "bundle": "/".join(map(str, b)), "size": len(b), "in_dp_choice": b in chosen, "seed": s, "exact": ex[0], "pso": r[0], "gap_pct": 100 * (r[0] / ex[0] - 1), "same_option": r[1] == ex[1]})
        # DP recomputed with PSO costs for the bundles checked (others exact): planning-objective difference
        act = sorted(i for i in D if D[i] > 0); exact_costs = {b: v[0] for b, v in {**single, **tb}.items()}
        v_ex, _ = e.partition(act, exact_costs)
        for s in seeds:
            pc = dict(exact_costs); pc.update(pso_cost[s]); v_ps, _ = e.partition(act, pc); dp_diff.append({"q": q, "seed": s, "dp_exact": v_ex, "dp_pso": v_ps, "diff_pct": 100 * (v_ps / v_ex - 1)})
    return pd.DataFrame(rows), pd.DataFrame(dp_diff)

if __name__ == "__main__":
    t0 = time.time(); LOG = {"step": STEP, "T_END": T_END, "spec_addendum_sha256": hashlib.sha256(open("SPEC_ADDENDUM_STEPS2_3_FROZEN.md", "rb").read()).hexdigest(),
                            "engine_sha256": hashlib.sha256(open("engine.py", "rb").read()).hexdigest(), "stage2data_sha256": hashlib.sha256(open("stage2data.py", "rb").read()).hexdigest(),
                            "run_step_sha256": hashlib.sha256(open("run_step.py", "rb").read()).hexdigest(),
                            "n_lanes": len(B.lanes), "n_countries": len({l["country"] for l in B.lanes}), "n_rdc": sum(l["channel"] == "From RDC" for l in B.lanes),
                            "CV": B.CV, "n_bundles": len(B.bundles), "n_observed_sets": len(B.obs_sets), "freight_validation": B.freight_validation, "obs_lines": len(B.OBS)}
    C = cases(); assert len(C) == 34
    with Pool(2) as pool: R = pool.map(run_case, C, chunksize=1)
    sens = []; cty = None
    for r in R:
        t = r["totals"]; row = {"parameter": r["name"], "value": r["value"], **{f"{k}_total": v for k, v in t.items()}}
        for pol in E.POLICIES: row[f"{pol}_vs_B1_pct"] = 100 * (t[pol] / t["B1"] - 1); row[f"{pol}_vs_B2_pct"] = 100 * (t[pol] / t["B2"] - 1)
        row["runtime_s"] = r["runtime_s"]; sens.append(row)
        if r["lanes"] is not None:
            tag = {"base": "base", "freight-only": "K0"}.get(r["name"], "K250"); r["lanes"].to_csv(f"{OUT}/lane_costs_{tag}.csv", index=False)
            Lw = r["lanes"].pivot(index="lane", columns="policy", values="total"); cty = r["lanes"][r["lanes"].policy == "B1"].set_index("lane").country.loc[Lw.index].values
            LOG[f"{tag}"] = {"totals": t, "components": r["components"], "plan_summary": r["plan_summary"],
                             "delta_vs_B1_pct": {p: 100 * (t[p] / t["B1"] - 1) for p in E.POLICIES + ["B2"]}, "delta_vs_B2_pct": {p: 100 * (t[p] / t["B2"] - 1) for p in E.POLICIES + ["B1"]},
                             "cluster_CI95_vs_B1_pct": {p: E.boot(Lw[p], Lw["B1"], cty) for p in E.POLICIES}, "cluster_CI95_vs_B2_pct": {p: E.boot(Lw[p], Lw["B2"], cty) for p in E.POLICIES + ["B1"]},
                             "lane_CI95_vs_B1_pct": {p: E.boot(Lw[p], Lw["B1"], cty, cluster=False) for p in E.POLICIES},
                             "lanes_cheaper_than_B1": {p: int((Lw[p] < Lw["B1"]).sum()) for p in E.POLICIES}, "lanes_dearer_than_B1": {p: int((Lw[p] > Lw["B1"]).sum()) for p in E.POLICIES}}
        if r["decisions"] is not None: pd.DataFrame(r["decisions"]).to_csv(f"{OUT}/decisions_base.csv", index=False)
    S = pd.DataFrame(sens); S.to_csv(f"{OUT}/sensitivity.csv", index=False)
    sens32 = S[~S.parameter.isin(["base", "freight-only"])]; assert len(sens32) == 32
    LOG["sensitivity_share_cheaper_than_B1"] = {p: float((sens32[f"{p}_vs_B1_pct"] < 0).mean()) for p in E.POLICIES}
    LOG["sensitivity_range_vs_B1_pct"] = {p: [float(sens32[f"{p}_vs_B1_pct"].min()), float(sens32[f"{p}_vs_B1_pct"].max())] for p in E.POLICIES}
    print("cases done", time.time() - t0, flush=True)
    PR, DD = pso_check(); PR.to_csv(f"{OUT}/pso_check.csv", index=False); DD.to_csv(f"{OUT}/pso_dp_check.csv", index=False)
    by_prob = PR.groupby(["q", "bundle"]).gap_pct.max()
    LOG["pso"] = {"problems": int(len(by_prob)), "runs": int(len(PR)), "share_runs_within_0.1pct": float((PR.gap_pct <= 0.1).mean()),
                  "share_problems_all_seeds_within_0.1pct": float((by_prob <= 0.1).mean()), "max_gap_pct": float(PR.gap_pct.max()), "min_gap_pct": float(PR.gap_pct.min()),
                  "dp_total_diff_pct_max": float(DD.diff_pct.max()), "dp_total_diff_pct_mean": float(DD.diff_pct.mean())}
    b = LOG["base"]; k250 = LOG["K250"]
    LOG["claim_criteria_CONSOLIDATED_vs_B1"] = {
        "1_base_cluster_CI_below_0": bool(b["cluster_CI95_vs_B1_pct"]["CONSOLIDATED"][1] < 0),
        "2_cheaper_in_>=75pct_of_32_cases": bool(LOG["sensitivity_share_cheaper_than_B1"]["CONSOLIDATED"] >= 0.75),
        "3_K250_cluster_CI_below_0": bool(k250["cluster_CI95_vs_B1_pct"]["CONSOLIDATED"][1] < 0),
        "4_freight_only_reported": True, "5_PSO_within_0.1pct_on_>=95pct": bool(LOG["pso"]["share_runs_within_0.1pct"] >= 0.95), "6_all_policies_reported": True}
    LOG["claim_criteria_CONSOLIDATED_vs_B1"]["ALL"] = all(LOG["claim_criteria_CONSOLIDATED_vs_B1"].values())
    LOG["runtime_s"] = time.time() - t0; json.dump(LOG, open(f"logs/step{STEP}_log.json", "w"), indent=1, default=str)
    print(json.dumps({k: LOG[k] for k in ("claim_criteria_CONSOLIDATED_vs_B1", "sensitivity_share_cheaper_than_B1", "pso")}, indent=1))
    print(json.dumps({k: LOG["base"][k] for k in ("delta_vs_B1_pct", "cluster_CI95_vs_B1_pct", "lanes_cheaper_than_B1")}, indent=1))
