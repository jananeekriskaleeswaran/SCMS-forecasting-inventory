"""Steps 2-3 periodic policy engine (SPEC_ADDENDUM_STEPS2_3_FROZEN.md). One engine, one accounting, every policy and baseline.

Clarification fixed before any Step 2/3 run (logged in logs/deviations.md, outcome-independent):
  a member lane with zero actual demand in quarter q receives nothing that quarter and does not count those
  shipments in n_i; the bundle still ships if any member has demand; quarters with no member demand ship nothing.
"""
import numpy as np, pandas as pd, networkx as nx
from scipy.optimize import minimize_scalar
import stage2data as SD
C3 = SD.C3
PARTS = C3.PARTS
BASE = dict(h=0.20, K=1000.0, z=1.645, cap=6.0, cv_mult=1.0, fmult=None, rdc_lt=None, fm="ANN")
POLICIES = ["CONSOLIDATED", "INDEPENDENT", "OBSERVED_SET", "EOQ_DOMINANT"]


class Engine:
    def __init__(self, B, p=None):
        self.B, self.p = B, {**BASE, **(p or {})}; p = self.p
        self.lanes = B.lanes; self.N = len(B.lanes); self.FM = B.FM[p["fm"]]; self.cv = B.CV * p["cv_mult"]
        self.LT = dict(B.LT); self.LT.update(p["rdc_lt"] or {}); self.fmult = p["fmult"] or {}
        self.h, self.K, self.z, self.cap = p["h"], p["K"], p["z"], p["cap"]
        self._cache = {}

    # ---------- primitives ----------
    def frt(self, W, o, cty):
        if o == C3.EMBEDDED: return np.zeros_like(np.atleast_1d(W), dtype=float)
        return self.FM.f(np.atleast_1d(np.asarray(W, float)), o, cty) * self.fmult.get(o, 1.0)

    def sig(self, D, T, Lm, sL):
        sg = self.cv * D / 12.0
        return np.sqrt(((365.0 * T + Lm) / 30.0) * sg ** 2 + (D / 12.0) ** 2 * (sL / 30.0) ** 2)

    def wcap(self, o, cty):
        return self.B.WCAP.get((o, cty), self.B.WCAP_OPT.get(o, np.inf))

    def bundle_cost(self, S, o, T, D):
        T = np.atleast_1d(np.asarray(T, float)); L0 = self.lanes[S[0]]
        W = T * sum(D[i] * self.lanes[i]["w"] for i in S); fr = self.frt(W, o, L0["country"]); Lm, sL = self.LT[o]; c = 0.0
        for i in S:
            Li = self.lanes[i]
            c = c + self.h * Li["c"] * (D[i] * T / 2 + self.z * self.sig(D[i], T, Lm, sL)) + self.h * Li["c"] * D[i] * Lm / 365
        return (self.K + fr) / T + c

    def t_bounds(self, S, D, o):
        lo = max(max(1.0, self.lanes[i]["qmin_obs"]) / D[i] for i in S)
        hi = min(min(self.lanes[i]["qmax_obs"], D[i] * self.cap / 12.0) / D[i] for i in S)
        if len(S) == 1: return (hi, hi) if lo > hi else (lo, hi)
        hi = min(hi, self.wcap(o, self.lanes[S[0]]["country"]) / sum(D[i] * self.lanes[i]["w"] for i in S))
        return None if lo > hi else (lo, hi)

    def options(self, S, dominant_only=False):
        if dominant_only: return [self.lanes[S[0]]["dom_opt"]]
        return sorted(set.intersection(*[set(self.lanes[i]["opts"]) for i in S]))

    def solve_exact(self, S, D, opts=None, grid=2000):
        best = None
        for o in (opts or self.options(S)):
            b = self.t_bounds(S, D, o)
            if b is None: continue
            lo, hi = b
            if hi - lo < 1e-12: v, T = float(self.bundle_cost(S, o, lo, D)[0]), lo
            else:
                g = np.exp(np.linspace(np.log(lo), np.log(hi), grid)); cv = self.bundle_cost(S, o, g, D); j = int(cv.argmin())
                a, bb = np.log(g[max(j - 1, 0)]), np.log(g[min(j + 1, grid - 1)])
                r = minimize_scalar(lambda lt: float(self.bundle_cost(S, o, np.exp(lt), D)[0]), bounds=(a, bb), method="bounded", options={"xatol": 1e-10})
                v, T = (float(r.fun), float(np.exp(r.x))) if r.fun < cv[j] else (float(cv[j]), float(g[j]))
            if best is None or v < best[0]: best = (v, o, T)
        return best

    def solve_pso(self, S, D, seed, n_part=20, iters=50, w=(0.9, 0.4), c1=1.5, c2=1.5, vclamp=0.5):
        """Particle (u, log T); option decoded by equal-width floor over options feasible for this bundle (parent rule)."""
        opts = [o for o in self.options(S) if self.t_bounds(S, D, o) is not None]
        if not opts: return None
        bnd = {o: self.t_bounds(S, D, o) for o in opts}; LO = min(b[0] for b in bnd.values()); HI = max(b[1] for b in bnd.values())
        rng = np.random.default_rng(seed); lb = np.array([0.0, np.log(LO)]); ub = np.array([1.0 - 1e-12, np.log(HI) + 1e-12])
        def f(x):
            o = C3.decode(x[0], opts); lo, hi = bnd[o]; T = min(max(np.exp(x[1]), lo), hi); return float(self.bundle_cost(S, o, T, D)[0])
        X = rng.uniform(lb, ub, (n_part, 2)); V = np.zeros_like(X); pb = X.copy(); pbf = np.array([f(x) for x in X]); g = int(np.argmin(pbf)); gb, gbf = pb[g].copy(), pbf[g]
        vmax = vclamp * (ub - lb)
        for it in range(iters):
            wi = w[0] - (w[0] - w[1]) * it / max(iters - 1, 1); r1, r2 = rng.random((n_part, 2)), rng.random((n_part, 2))
            V = np.clip(wi * V + c1 * r1 * (pb - X) + c2 * r2 * (gb - X), -vmax, vmax); X = np.clip(X + V, lb, ub)
            fx = np.array([f(x) for x in X]); imp = fx < pbf; pb[imp], pbf[imp] = X[imp], fx[imp]; g = int(np.argmin(pbf))
            if pbf[g] < gbf: gb, gbf = pb[g].copy(), pbf[g]
        o = C3.decode(gb[0], opts); lo, hi = bnd[o]
        return (float(gbf), o, float(min(max(np.exp(gb[1]), lo), hi)))

    # ---------- planning ----------
    @staticmethod
    def partition(members, costs):
        """Exact min-cost partition (memoised DP over the lowest uncovered member), per connected component."""
        G = nx.Graph(); G.add_nodes_from(members)
        for b in costs:
            for a in b[1:]: G.add_edge(b[0], a)
        total, chosen = 0.0, []
        for comp in nx.connected_components(G):
            mem = sorted(comp); idx = {m: k for k, m in enumerate(mem)}; n = len(mem); by_low = {k: [] for k in range(n)}
            for b, c in costs.items():
                if b[0] in comp:
                    by_low[min(idx[i] for i in b)].append((sum(1 << idx[i] for i in b), c, b))
            f = {0: (0.0, None, None)}
            def solve(mask):
                if mask in f: return f[mask][0]
                low = (mask & -mask).bit_length() - 1; best = (np.inf, None, None)
                for bm, c, b in by_low[low]:
                    if bm & mask == bm:
                        v = solve(mask ^ bm) + c
                        if v < best[0]: best = (v, b, mask ^ bm)
                f[mask] = best; return best[0]
            import sys; sys.setrecursionlimit(10000)
            full = (1 << n) - 1; total += solve(full); m = full
            while m: _, b, m2 = f[m]; chosen.append(b); m = m2
        return total, chosen

    def bundle_table(self, q, kind):
        """Exact (cost, o, T) for every candidate unit at decision date q. kind: 'single' | 'all' | 'observed'."""
        key = (q, kind)
        if key in self._cache: return self._cache[key]
        D = {i: self.B.DPLAN[i][q] for i in range(self.N)}; act = {i for i in D if D[i] > 0}
        if kind == "single": cands = [(i,) for i in sorted(act)]
        else:
            src = self.B.bundles if kind == "all" else self.B.obs_sets
            cands = [b for b in src if all(i in act for i in b)]
        out = {}
        for b in cands:
            r = self.solve_exact(b, D)
            if r is not None: out[b] = r
        self._cache[key] = out; return out

    def plan(self, policy):
        """Returns per quarter a list of (bundle, o, T)."""
        plans, prev = [], {}
        for q in range(4):
            D = {i: self.B.DPLAN[i][q] for i in range(self.N)}; act = sorted(i for i in D if D[i] > 0)
            if policy == "EOQ_DOMINANT":
                if q == 0:
                    units = []
                    for i in act:
                        r = self.solve_exact((i,), D, opts=self.options((i,), dominant_only=True)); units.append(((i,), r[1], r[2]))
                    eoq = units
                plans.append(eoq); continue
            single = self.bundle_table(q, "single"); costs = {b: v[0] for b, v in single.items()}
            if policy == "CONSOLIDATED": tb = self.bundle_table(q, "all"); costs.update({b: v[0] for b, v in tb.items()})
            elif policy == "OBSERVED_SET": tb = self.bundle_table(q, "observed"); costs.update({b: v[0] for b, v in tb.items()})
            else: tb = {}
            _, chosen = self.partition(act, costs); allt = {**single, **tb}
            units = [(b, allt[b][1], allt[b][2]) for b in chosen]
            for i in range(self.N):                                    # D_plan = 0 -> keep previous (o, T) as singleton
                if D[i] <= 0 and i in prev: units.append(((i,), prev[i][0], prev[i][1]))
            for b, o, T in units:
                for i in b: prev[i] = (o, T)
            plans.append(units)
        return plans

    # ---------- realisation ----------
    def realise(self, plans):
        """Periodic fixed-cycle realisation; returns DataFrame of lane-level components."""
        acc = {i: dict(ordering=0.0, freight=0.0, n=0.0, Lsum=0.0, sLsum=0.0, Dsum=0.0, pipe=0.0) for i in range(self.N)}
        for q, units in enumerate(plans):
            for b, o, T in units:
                Dq = {i: 4.0 * self.B.QDEM[i][q] for i in b}; mem = [i for i in b if Dq[i] > 0]
                if not mem: continue
                nship = 0.25 / T; wts = np.array([T * Dq[i] * self.lanes[i]["w"] for i in mem]); W = wts.sum()
                fr = float(self.frt(W, o, self.lanes[b[0]]["country"])[0]); sh = wts / W; Lm, sL = self.LT[o]
                for i, s in zip(mem, sh):
                    a = acc[i]; a["ordering"] += nship * self.K * s; a["freight"] += nship * fr * s; a["n"] += nship
                    dq = self.B.QDEM[i][q]; a["Lsum"] += dq * Lm; a["sLsum"] += dq * sL; a["Dsum"] += dq; a["pipe"] += dq * Lm
        rows = []
        for i, a in acc.items():
            L = self.lanes[i]; D = a["Dsum"]
            if D <= 0: continue
            assert a["n"] > 0, (i, a)
            r = {"lane": i, "country": L["country"], "ordering": a["ordering"], "freight": a["freight"], "cycle": self.h * L["c"] * (D / a["n"]) / 2,
                 "safety": self.h * L["c"] * self.z * float(self.sig(D, 1.0 / a["n"], a["Lsum"] / D, a["sLsum"] / D)), "pipeline": self.h * L["c"] * a["pipe"] / 365, "n": a["n"]}
            r["total"] = sum(r[k] for k in PARTS); rows.append(r)
        return pd.DataFrame(rows)

    def observed(self, consolidated=True):
        O = self.B.OBS; rows = []
        for i in range(self.N):
            L = self.lanes[i]; o = O[O.lane == i]; D = o.packs.sum(); n = len(o)
            Lm = np.array([self.LT[x][0] for x in o.opt_priced]); sLm = np.array([self.LT[x][1] for x in o.opt_priced])
            wL, wsL = np.sum(o.packs.values * Lm) / D, np.sum(o.packs.values * sLm) / D
            if consolidated: fr = sum(float(self.frt(W, x, c)[0]) * s for W, x, c, s in zip(o.W_ship, o.opt_priced, o.country, o.share))
            else: fr = sum(float(self.frt(pk * w, x, c)[0]) for x, c, pk, w in zip(o.opt_priced, o.country, o.packs, o.w))
            r = {"lane": i, "country": L["country"], "ordering": self.K * (o.share.sum() if consolidated else n), "freight": fr,
                 "cycle": self.h * L["c"] * (D / n) / 2, "safety": self.h * L["c"] * self.z * float(self.sig(L["D_act"], 1.0 / n, wL, wsL)),
                 "pipeline": self.h * L["c"] * float(np.sum(o.packs.values * Lm)) / 365, "n": n}
            r["total"] = sum(r[k] for k in PARTS); rows.append(r)
        return pd.DataFrame(rows)

    def run_all(self):
        res = {"B1": self.observed(True), "B2": self.observed(False)}; plans = {}
        for pol in POLICIES:
            plans[pol] = self.plan(pol); res[pol] = self.realise(plans[pol]); assert len(res[pol]) == self.N, (pol, len(res[pol]))
        return res, plans


def boot(pol, base, countries, B=5000, seed=7, cluster=True):
    rng = np.random.default_rng(seed); p, b = pol.values, base.values
    if cluster:
        u = np.unique(countries); P = np.array([p[countries == c].sum() for c in u]); Q = np.array([b[countries == c].sum() for c in u]); m = len(u)
    else: P, Q, m = p, b, len(p)
    d = [100 * (P[j].sum() / Q[j].sum() - 1) for j in (rng.integers(0, m, m) for _ in range(B))]
    return [float(np.percentile(d, 2.5)), float(np.percentile(d, 97.5))]
