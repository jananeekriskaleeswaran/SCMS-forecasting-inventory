"""Independent reconstruction of lane-level costs from a v2 shipment ledger.
Uses only: the ledger (n, x, W_priced, opt per unit-quarter), the lane table, quarterly demand, lead-time table, parameters,
and the freight surrogate's own predict() (direct network evaluation, not the engine's interpolated frt()).
No function from engine.py / engine_v2.py is called."""
import math
import numpy as np

def reconstruct(ledger, lanes, QDEM, LT, params, CV, freight_predict, embedded="Direct Drop|Truck"):
    h, K, z = params["h"], params["K"], params["z"]; fmult = params.get("fmult") or {}
    acc = {}
    for r in ledger:
        o = r["opt"]; n = r["n"]; x = r["x"]; cty = lanes[int(str(r["bundle"]).split("/")[0])]["country"]
        Wtot = sum(lanes[i]["w"] * x[i] for i in x)
        F = 0.0 if o == embedded else float(freight_predict(np.array([r["W_priced"]]), [o], [cty])[0]) * fmult.get(o, 1.0)
        Lm, sL = LT[o]
        for i in x:
            share = lanes[i]["w"] * x[i] / Wtot; a = acc.setdefault(i, {"ord": 0.0, "fr": 0.0, "n": 0.0, "D": 0.0, "L": 0.0, "sL": 0.0})
            a["ord"] += n * K * share; a["fr"] += n * F * share; a["n"] += n
            dq = QDEM[i][r["q"]]; a["D"] += dq; a["L"] += dq * Lm; a["sL"] += dq * sL
    out = {}
    for i, a in acc.items():
        c = lanes[i]["c"]; D = a["D"]; Lbar = a["L"] / D; sLbar = a["sL"] / D; T = 1.0 / a["n"]
        monthly_sd = CV * D / 12.0
        sigma = math.sqrt(((365.0 * T + Lbar) / 30.0) * monthly_sd ** 2 + (D / 12.0) ** 2 * (sLbar / 30.0) ** 2)
        comp = {"ordering": a["ord"], "freight": a["fr"], "cycle": h * c * (D / a["n"]) / 2.0, "safety": h * c * z * sigma, "pipeline": h * c * a["L"] / 365.0}
        comp["total"] = sum(comp.values()); out[i] = comp
    return out
