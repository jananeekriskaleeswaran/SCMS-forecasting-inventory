"""consolidation_v2: bounded realisation (SPEC_BOUNDED_REALISATION.md).
Planning, B1/B2 and all cost formulas are inherited unchanged from ../consolidation/engine.py; only realise() differs.
Component switches allow the regression check (all off == v1) and the sequential decomposition."""
import os, sys, numpy as np, pandas as pd
V1 = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "consolidation"); sys.path.insert(0, V1)
import stage2data as SD, engine as E
C3 = SD.C3; PARTS = E.PARTS; POLICIES = E.POLICIES; boot = E.boot
ALL_ON = dict(lane_max=True, cover=True, wcap=True, lane_min=True, floor=True)
ALL_OFF = {k: False for k in ALL_ON}
TOL = 1e-12

def support_tables(B):
    """W_min / W_max of training shipments (W>0, date<=T_END) by (option, country), option-level fallback (same source as B.WCAP)."""
    if not hasattr(B, "WMIN"):
        sh = SD.SHIP[(SD.SHIP.date <= B.T_END) & (SD.SHIP.W > 0)]
        B.WMIN = sh.groupby(["opt", "country"]).W.min().to_dict(); B.WMIN_OPT = sh.groupby("opt").W.min().to_dict()
    return B

class EngineV2(E.Engine):
    def __init__(self, B, p=None, components=None):
        super().__init__(support_tables(B), p); self.comp = dict(ALL_ON if components is None else components); self.ledger = []
        self._validate_inputs()

    def _validate_inputs(self):
        """D9-L1 guard (audit fix): every lane option must have a finite lead-time mean and SD >= 0; otherwise refuse to run
        instead of letting NaN propagate into safety stock and pipeline costs."""
        for i, l in enumerate(self.lanes):
            for o in l["opts"]:
                if o not in self.LT: raise ValueError(f"lane {i}: option {o} has no lead time")
                m, s = self.LT[o]
                if not (np.isfinite(m) and np.isfinite(s) and m >= 0 and s >= 0): raise ValueError(f"lane {i}: option {o} has invalid lead time {(m, s)}")

    def wmin(self, o, c): return self.B.WMIN.get((o, c), self.B.WMIN_OPT.get(o, 0.0))

    def realise_unit(self, b, o, T, q):
        """Returns (n, x dict, W, W_priced, freight per shipment, record) for one unit-quarter, or None if no member demand."""
        if not (np.isfinite(T) and T > 0): raise ValueError(f"invalid cycle T={T} for unit {b}")
        d = {i: float(self.B.QDEM[i][q]) for i in b}
        for i, v in d.items():
            if not np.isfinite(v) or v < 0: raise ValueError(f"invalid demand {v} for lane {i}, quarter {q}")
        A = [i for i in b if d[i] > 0]
        if not A: return None
        a = {i: max(1.0, self.lanes[i]["qmin_obs"]) for i in A}; bb = {i: float(self.lanes[i]["qmax_obs"]) for i in A}
        for i in A:
            if a[i] > bb[i]: raise ValueError(f"lane {i}: a={a[i]} > b={bb[i]}")
        cty = self.lanes[b[0]]["country"]; emb = (o == C3.EMBEDDED); n0 = 0.25 / T
        lims = {}
        if self.comp["lane_max"]: lims["H2"] = max(d[i] / bb[i] for i in A)
        if self.comp["cover"]: lims["H3"] = 3.0 / self.cap
        Wmax = self.wcap(o, cty)
        if self.comp["wcap"] and not emb and np.isfinite(Wmax): lims["H4"] = sum(self.lanes[i]["w"] * d[i] for i in A) / Wmax
        n_hard = max(lims.values()) if lims else 0.0
        n_soft = min(d[i] / a[i] for i in A) if self.comp["lane_min"] else np.inf
        flags = []
        if n_hard <= n_soft * (1 + TOL):
            n = min(max(n0, n_hard), n_soft)
            status = "OK" if abs(n - n0) <= TOL * n0 else ("UP" if n > n0 else "DOWN")
        else:
            n = n_hard; status = "EXCEPTION"
            for i in A:
                if d[i] / a[i] < max(d[i] / bb[i] if self.comp["lane_max"] else 0.0, lims.get("H3", 0.0)) * (1 - TOL): flags.append(f"E-LOWDEM:{i}")
                if "H4" in lims and lims["H4"] > (d[i] / a[i]) * (1 + TOL): flags.append(f"E-CAP:{i}")
                if self.comp["lane_max"] and any(d[j] / bb[j] > (d[i] / a[i]) * (1 + TOL) for j in A if j != i): flags.append(f"E-HETERO:{i}")
        x = {i: d[i] / n for i in A}; W = sum(self.lanes[i]["w"] * x[i] for i in A)
        Wmin = self.wmin(o, cty); below = (not emb) and W < Wmin * (1 - TOL)
        Wp = max(W, Wmin) if (self.comp["floor"] and not emb) else W
        fr = 0.0 if emb else float(self.frt(Wp, o, cty)[0])
        rec = {"q": q, "bundle": "/".join(map(str, b)), "size": len(b), "n_active": len(A), "opt": o, "T": T, "n0": n0, "n": n, "status": status,
               "flags": ";".join(flags), "binding_hard": max(lims, key=lims.get) if lims and n == n_hard else "", "W": W, "W_max": Wmax, "W_min": Wmin, "W_priced": Wp,
               "below_support": bool(below), "above_support": bool((not emb) and W > Wmax * (1 + 1e-9)), "freight_per_shipment": fr,
               "x": {i: x[i] for i in A}, "a": a, "b": bb, "d": {i: d[i] for i in A},
               "shortfall": {i: a[i] - x[i] for i in A if x[i] < a[i] * (1 - 1e-9)}, "over_max": {i: x[i] - bb[i] for i in A if x[i] > bb[i] * (1 + 1e-9)}}
        return n, x, W, Wp, fr, rec

    def realise(self, plans, policy=None):
        acc = {i: dict(ordering=0.0, freight=0.0, n=0.0, Lsum=0.0, sLsum=0.0, Dsum=0.0, pipe=0.0) for i in range(self.N)}
        for q, units in enumerate(plans):
            for b, o, T in units:
                r = self.realise_unit(b, o, T, q)
                if r is None: continue
                n, x, W, Wp, fr, rec = r; rec["policy"] = policy; self.ledger.append(rec); Lm, sL = self.LT[o]
                for i in x:
                    s = self.lanes[i]["w"] * x[i] / W; a_ = acc[i]
                    a_["ordering"] += n * self.K * s; a_["freight"] += n * fr * s; a_["n"] += n
                    dq = self.B.QDEM[i][q]; a_["Lsum"] += dq * Lm; a_["sLsum"] += dq * sL; a_["Dsum"] += dq; a_["pipe"] += dq * Lm
        rows = []
        for i, a_ in acc.items():
            L = self.lanes[i]; D = a_["Dsum"]
            if D <= 0: continue
            assert a_["n"] > 0, (i, a_)
            r = {"lane": i, "country": L["country"], "ordering": a_["ordering"], "freight": a_["freight"], "cycle": self.h * L["c"] * (D / a_["n"]) / 2,
                 "safety": self.h * L["c"] * self.z * float(self.sig(D, 1.0 / a_["n"], a_["Lsum"] / D, a_["sLsum"] / D)), "pipeline": self.h * L["c"] * a_["pipe"] / 365, "n": a_["n"]}
            r["total"] = sum(r[k] for k in PARTS); rows.append(r)
        return pd.DataFrame(rows)

    def run_all(self, plans=None):
        res = {"B1": self.observed(True), "B2": self.observed(False)}; plans = plans or {p: self.plan(p) for p in POLICIES}
        for pol in POLICIES:
            res[pol] = self.realise(plans[pol], policy=pol); assert len(res[pol]) == self.N, (pol, len(res[pol]))
        return res, plans

    def ledger_frame(self):
        return pd.DataFrame(self.ledger)
