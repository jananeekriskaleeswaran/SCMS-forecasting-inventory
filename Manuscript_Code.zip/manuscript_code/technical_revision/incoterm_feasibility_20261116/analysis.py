"""INCOTERM feasibility (exploratory; user approval 2026-11-16 13:39 IST). Direct Drop purchases only. No model fitting beyond descriptive OLS.
Q1: For the same item and vendor, how much higher is the pack price under DDP (vendor delivers; freight mostly 'Included in Commodity Cost')
    than under EXW/FCA (buyer pays freight separately)? Fixed effects: item x vendor and delivery year; cluster bootstrap over item-vendor pairs.
Q2: Under EXW/FCA, what does the buyer pay in freight + insurance as a share of commodity value? (shipment level, numeric freight only)
Q3: Is the DDP premium smaller or larger than EXW/FCA freight + insurance, i.e. is there a cost-saving INCOTERM choice to model?"""
import os as _os_root
_HA_ROOT = _os_root.environ.get("HYBRID_ANN_ROOT") or _os_root.path.abspath(_os_root.path.join(_os_root.path.dirname(_os_root.path.abspath(__file__)), "..", ".."))  # portable root (build_repo.py)
import os, sys, json, warnings, numpy as np, pandas as pd
import statsmodels.api as sm
warnings.filterwarnings("ignore"); HERE = os.path.dirname(os.path.abspath(__file__)); OUT = f"{HERE}/outputs"; os.makedirs(OUT, exist_ok=True)
sys.path.insert(0, f"{_HA_ROOT}/proj/src")
from common import load_raw
from shipments import build_shipments
r = pd.read_csv(f"{_HA_ROOT}/proj/data/scms_raw.csv", encoding="latin-1", low_memory=False)
r["year"] = pd.to_datetime(r["Delivered to Client Date"], format="%d-%b-%y").dt.year
dd = r[(r["Fulfill Via"] == "Direct Drop") & (r["Pack Price"] > 0)].copy(); dd["inco"] = dd["Vendor INCO Term"].astype(str)
dd["grp"] = np.where(dd.inco == "DDP", "DDP", np.where(dd.inco.isin(["EXW", "FCA"]), "EXW/FCA", "other"))
R = {}
# ---------- Q1: within item x vendor DDP premium ----------
pairs = dd.groupby(["Item Description", "Vendor"]).grp.agg(lambda s: {"DDP", "EXW/FCA"} <= set(s))
pairs = pairs[pairs].index; d1 = dd.set_index(["Item Description", "Vendor"]).loc[pairs].reset_index(); d1 = d1[d1.grp.isin(["DDP", "EXW/FCA"])].copy()
d1["pair"] = d1["Item Description"] + " | " + d1.Vendor; d1["lp"] = np.log(d1["Pack Price"]); d1["ddp"] = (d1.grp == "DDP").astype(float)
def fe_premium(x):
    x = x.reset_index(drop=True)
    X = pd.get_dummies(x[["pair"]].astype(str), drop_first=False).astype(float).join(pd.get_dummies(x.year.astype(str), prefix="y", drop_first=True).astype(float))
    X.insert(0, "ddp", x.ddp.values); m = sm.OLS(x.lp.values, X.values).fit(); return float(m.params[0])
b = fe_premium(d1); rng = np.random.default_rng(7); P = d1.pair.unique(); bs = []
for _ in range(2000):
    s = rng.choice(P, len(P)); xb = pd.concat([d1[d1.pair == p].assign(pair=f"{p}#{i}") for i, p in enumerate(s)], ignore_index=True)
    if xb.ddp.nunique() == 2: bs.append(fe_premium(xb))
same_year = d1.groupby(["pair", "year"]).grp.nunique(); sy = same_year[same_year == 2].index
d1y = d1.set_index(["pair", "year"]).loc[sy].reset_index(); med_sy = d1y.groupby(["pair", "year", "grp"]).lp.median().unstack()
R["Q1_DDP_price_premium"] = {"item_vendor_pairs": int(len(P)), "vendors": int(d1.Vendor.nunique()), "lines": int(len(d1)), "lines_DDP": int(d1.ddp.sum()),
    "log_premium_FE": b, "premium_pct_FE": float(100 * (np.exp(b) - 1)), "CI95_pct_cluster_bootstrap": [float(100 * (np.exp(np.percentile(bs, 2.5)) - 1)), float(100 * (np.exp(np.percentile(bs, 97.5)) - 1))],
    "bootstrap_draws_valid": len(bs), "same_pair_same_year_cells": int(len(med_sy)),
    "same_year_median_premium_pct": float(100 * (np.exp((med_sy["DDP"] - med_sy["EXW/FCA"]).median()) - 1)) if len(med_sy) else None,
    "share_same_year_cells_DDP_dearer": float(((med_sy["DDP"] - med_sy["EXW/FCA"]) > 0).mean()) if len(med_sy) else None}
d1.groupby(["pair", "grp"]).agg(lines=("ID", "size"), median_pack_price=("Pack Price", "median"), years=("year", lambda s: f"{s.min()}-{s.max()}")).to_csv(f"{OUT}/pairs_price_by_incoterm.csv")
# ---------- Q2: buyer-paid freight + insurance under EXW/FCA (shipment level) ----------
sh = build_shipments(load_raw()); raw = load_raw()
inc = raw.groupby("ASN/DN #").agg(inco=("Vendor INCO Term", lambda s: s.mode().iloc[0]), ins=("Line Item Insurance (USD)", lambda s: pd.to_numeric(s, errors="coerce").sum(min_count=1)),
                                    fulfill=("Fulfill Via", "first"))
s2 = sh.merge(inc, left_on="ASN/DN #", right_index=True, suffixes=("", "_r")); s2 = s2[(s2.fulfill_r == "Direct Drop") & (s2.F > 0) & (s2.value > 0)]
s2["fr_pct"] = 100 * s2.F / s2.value; s2["ins_pct"] = 100 * s2.ins / s2.value; s2["mode"] = s2["mode"].astype(str)
ex = s2[s2.inco.isin(["EXW", "FCA"])]
R["Q2_EXW_FCA_buyer_costs"] = {"shipments": int(len(ex)), "freight_pct_of_value_median": float(ex.fr_pct.median()), "freight_pct_IQR": [float(ex.fr_pct.quantile(.25)), float(ex.fr_pct.quantile(.75))],
    "insurance_pct_of_value_median": float(ex.ins_pct.median()), "freight_plus_insurance_pct_median": float((ex.fr_pct + ex.ins_pct.fillna(0)).median()),
    "by_mode_freight_pct_median": ex.groupby("mode").fr_pct.median().round(2).to_dict(), "by_mode_n": ex["mode"].value_counts().to_dict()}
pp = set(d1.pair); exl = r[(r["Fulfill Via"] == "Direct Drop") & r["Vendor INCO Term"].isin(["EXW", "FCA"])].assign(pair=lambda z: z["Item Description"] + " | " + z.Vendor)
exl = exl[exl.pair.isin(pp)]; s_pairs = s2[s2["ASN/DN #"].isin(exl["ASN/DN #"].unique())]
R["Q2_EXW_FCA_buyer_costs"]["same_21_pairs"] = {"shipments_with_numeric_freight": int(len(s_pairs)), "freight_plus_insurance_pct_median": float((s_pairs.fr_pct + s_pairs.ins_pct.fillna(0)).median()) if len(s_pairs) else None}
# ---------- Q3 ----------
prem = R["Q1_DDP_price_premium"]["premium_pct_FE"]; fi = R["Q2_EXW_FCA_buyer_costs"]["freight_plus_insurance_pct_median"]
R["Q3_comparison"] = {"DDP_premium_pct": prem, "EXW_FCA_freight_plus_insurance_pct": fi, "difference_pct_points (premium - freight&insurance)": prem - fi,
    "reading": "DDP cheaper" if prem < fi else "EXW/FCA cheaper", "premium_CI_overlaps_freight_level": bool(R["Q1_DDP_price_premium"]["CI95_pct_cluster_bootstrap"][0] <= fi <= R["Q1_DDP_price_premium"]["CI95_pct_cluster_bootstrap"][1])}
R["caveats"] = ["Exploratory: INCOTERM is usually agreed per vendor contract; only 21 item-vendor pairs were bought under both regimes.",
                "Prices compared within item x vendor with year fixed effects; order size, destination and mode may still differ between regimes.",
                "Under DDP, freight is mostly not recorded (78% 'Included in Commodity Cost'), so the vendor's freight cost is only inferred from the price premium.",
                "Buyer freight under EXW/FCA uses shipments with numeric freight; median shares are reported because the distribution is skewed."]
json.dump(R, open(f"{OUT}/incoterm_feasibility.json", "w"), indent=1, default=float); print(json.dumps({k: v for k, v in R.items() if k != "caveats"}, indent=1, default=float))
