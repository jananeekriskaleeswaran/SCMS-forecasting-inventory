"""Stage 2 v3 (SPEC_FROZEN.md): channel-aware (Q,R) cost model, freight models, solvers.
Options are 'channel|mode' strings. Cost (USD/yr, system perspective):
  ordering (D/Q)K + freight (D/Q)F_o(Qw) + cycle h c Q/2 + safety h c z sigma_LT + pipeline h c D L/365,
  sigma_LT = sqrt((L/30) sigma^2 + (D/12)^2 (s_L/30)^2)."""
import time, numpy as np, pandas as pd
from scipy.optimize import minimize_scalar
from sklearn.linear_model import LinearRegression
from sklearn.neural_network import MLPRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
PARTS = ["ordering", "freight", "cycle", "safety", "pipeline"]
MODELLED = ["Direct Drop|Air", "Direct Drop|Ocean", "From RDC|Air", "From RDC|Air Charter", "From RDC|Truck"]
EMBEDDED = "Direct Drop|Truck"
CHANNELS = ["Direct Drop", "From RDC"]

class OLSFreight:
    name = "OLS (log-linear, channel-specific slope)"
    def _X(self, sh, fit=False):
        X = pd.get_dummies(sh[["opt", "country"]].astype(str), prefix=["opt", "country"]).astype(float)
        ch = sh.opt.str.split("|").str[0]
        for c in CHANNELS: X[f"logW_{c}"] = np.log(sh.W.values) * (ch.values == c)
        if fit: self.cols = X.columns
        return X.reindex(columns=self.cols, fill_value=0.0)
    def fit(self, sh):
        X = self._X(sh, fit=True); y = np.log(sh.F.values); self.reg = LinearRegression().fit(X, y)
        self.smear = float(np.mean(np.exp(y - self.reg.predict(X))))
        self.beta = {c: float(self.reg.coef_[list(self.cols).index(f"logW_{c}")]) for c in CHANNELS}; return self
    def predict(self, W, opt, country):
        W = np.atleast_1d(np.asarray(W, float)); df = pd.DataFrame({"opt": opt, "country": country, "W": W})
        return self.smear * np.exp(self.reg.predict(self._X(df)))
    def f(self, W, opt, country):
        key = (opt, country)
        if not hasattr(self, "_c"): self._c = {}
        if key not in self._c: self._c[key] = self._prep(opt, country)
        return self._eval(self._c[key], W, opt)
    def _prep(self, opt, country): return float(np.log(self.predict([1.0], [opt], [country])[0] / self.smear))
    def _eval(self, a, W, opt): return self.smear * np.exp(a + self.beta[opt.split("|")[0]] * np.log(W))

class ANNFreight(OLSFreight):
    name = "ANN (MLP on option, country, log W)"
    GRID = [(h, a) for h in ((8,), (16,), (32, 16)) for a in (1e-3, 1e-1, 1.0)]
    LOGW = np.linspace(np.log(1e-3), np.log(5e5), 4000)
    @staticmethod
    def _model(h, a, seed): return make_pipeline(StandardScaler(), MLPRegressor(hidden_layer_sizes=h, alpha=a, max_iter=3000, random_state=seed))
    def _X(self, sh, fit=False):
        X = pd.get_dummies(sh[["opt", "country"]].astype(str), prefix=["opt", "country"]).astype(float); X["logW"] = np.log(sh.W.values)
        if fit: self.cols = X.columns
        return X.reindex(columns=self.cols, fill_value=0.0)
    def fit(self, sh, seed=42):
        sh = sh.sort_values("date"); cut = sh.date.max() - pd.DateOffset(years=1); tr, va = sh[sh.date <= cut], sh[sh.date > cut]; best = None
        for h, a in self.GRID:
            m = self._model(h, a, seed).fit(self._X(tr, fit=True), np.log(tr.F)); e = float(np.sqrt(np.mean((m.predict(self._X(va)) - np.log(va.F)) ** 2)))
            if best is None or e < best[0]: best = (e, h, a)
        self.cfg = {"hidden": best[1], "alpha": best[2], "val_rmse_log_last_train_year": best[0]}
        X = self._X(sh, fit=True); y = np.log(sh.F.values); self.reg = self._model(best[1], best[2], seed).fit(X, y)
        self.smear = float(np.mean(np.exp(y - self.reg.predict(X)))); self.beta = None; return self
    def _prep(self, opt, country):
        return self.reg.predict(self._X(pd.DataFrame({"opt": opt, "country": country, "W": np.exp(self.LOGW)})))
    def _eval(self, tab, W, opt): return self.smear * np.exp(np.interp(np.log(W), self.LOGW, tab))

def tc(Q, opt, lane, D, p, fm, LT, sigma, fmult=None, ltmult=None, parts=False):
    L, sL = LT[opt]; m = (ltmult or {}).get(opt, 1.0); L, sL = L * m, sL * m; n = D / Q
    fr = 0.0 if opt == EMBEDDED else n * (fmult or {}).get(opt, 1.0) * float(fm.f(Q * lane["w"], opt, lane["country"]))
    sLT = np.sqrt((L / 30.0) * sigma ** 2 + (D / 12.0) ** 2 * (sL / 30.0) ** 2)
    out = {"ordering": n * p["K"], "freight": fr, "cycle": p["h"] * lane["c"] * Q / 2, "safety": p["h"] * lane["c"] * p["z"] * sLT,
           "pipeline": p["h"] * lane["c"] * D * L / 365.0}
    out["total"] = sum(out[k] for k in PARTS); return out if parts else out["total"]

def bounds(lane, D, cap_months=6.0):
    lo = max(1.0, lane["qmin_obs"]); hi = min(lane["qmax_obs"], D * cap_months / 12.0)
    return (hi, hi) if lo > hi else (lo, hi)

class Counter:
    def __init__(self, f): self.f, self.n = f, 0
    def __call__(self, *a): self.n += 1; return self.f(*a)

def solve_exact(lane, D, p, fm, LT, sigma, grid_pts=400, cap_months=6.0, opts=None, **kw):
    t0 = time.time(); f = Counter(lambda q, o: tc(q, o, lane, D, p, fm, LT, sigma, **kw)); lo, hi = bounds(lane, D, cap_months); best = None
    for o in (opts or lane["opts"]):
        if hi - lo < 1e-9: cands = [(f(lo, o), lo)]
        else:
            a, b = np.log(lo), np.log(hi)
            r = minimize_scalar(lambda lq: f(np.exp(lq), o), bounds=(a, b), method="bounded", options={"xatol": 1e-8})
            g = np.linspace(a, b, grid_pts); gv = np.array([f(np.exp(x), o) for x in g]); j = int(gv.argmin())
            cands = [(float(r.fun), float(np.exp(r.x))), (float(gv[j]), float(np.exp(g[j])))]
            r2 = minimize_scalar(lambda lq: f(np.exp(lq), o), bounds=(g[max(j - 1, 0)], g[min(j + 1, grid_pts - 1)]), method="bounded", options={"xatol": 1e-10})
            cands.append((float(r2.fun), float(np.exp(r2.x))))
        v, q = min(cands)
        if best is None or v < best[0]: best = (v, q, o)
    return {"obj": best[0], "Q": best[1], "opt": best[2], "evals": f.n, "runtime_s": time.time() - t0}

def decode(u, opts): return opts[min(int(u * len(opts)), len(opts) - 1)]

def solve_pso(lane, D, p, fm, LT, sigma, seed, n_part=20, iters=50, w=(0.9, 0.4), c1=1.5, c2=1.5, vclamp=0.5, cap_months=6.0, record=False, **kw):
    """Particle = (u in [0,1), log Q); option = equal-width floor decode over the lane's feasible options."""
    t0 = time.time(); rng = np.random.default_rng(seed); opts = lane["opts"]; lo, hi = bounds(lane, D, cap_months)
    lb = np.array([0.0, np.log(lo)]); ub = np.array([1.0 - 1e-12, np.log(hi) + 1e-12])
    f = Counter(lambda x: tc(min(max(np.exp(x[1]), lo), hi), decode(x[0], opts), lane, D, p, fm, LT, sigma, **kw))
    X = rng.uniform(lb, ub, (n_part, 2)); V = np.zeros_like(X); pb = X.copy(); pbf = np.array([f(x) for x in X]); g = int(np.argmin(pbf)); gb, gbf = pb[g].copy(), pbf[g]
    hist = [gbf]; vmax = vclamp * (ub - lb)
    for it in range(iters):
        wi = w[0] - (w[0] - w[1]) * it / max(iters - 1, 1); r1, r2 = rng.random((n_part, 2)), rng.random((n_part, 2))
        V = np.clip(wi * V + c1 * r1 * (pb - X) + c2 * r2 * (gb - X), -vmax, vmax); X = np.clip(X + V, lb, ub)
        fx = np.array([f(x) for x in X]); imp = fx < pbf; pb[imp], pbf[imp] = X[imp], fx[imp]; g = int(np.argmin(pbf))
        if pbf[g] < gbf: gb, gbf = pb[g].copy(), pbf[g]
        hist.append(gbf)
    out = {"obj": float(gbf), "Q": float(min(max(np.exp(gb[1]), lo), hi)), "opt": decode(gb[0], opts), "evals": f.n, "runtime_s": time.time() - t0}
    if record: out["history"] = hist
    return out

def solve_random(lane, D, p, fm, LT, sigma, seed, budget, cap_months=6.0, **kw):
    t0 = time.time(); rng = np.random.default_rng(seed); lo, hi = bounds(lane, D, cap_months); best = (np.inf, None, None)
    for _ in range(budget):
        o = lane["opts"][rng.integers(len(lane["opts"]))]; q = float(np.exp(rng.uniform(np.log(lo), np.log(hi) + 1e-12))); q = min(max(q, lo), hi)
        v = tc(q, o, lane, D, p, fm, LT, sigma, **kw)
        if v < best[0]: best = (v, q, o)
    return {"obj": best[0], "Q": best[1], "opt": best[2], "evals": budget, "runtime_s": time.time() - t0}
