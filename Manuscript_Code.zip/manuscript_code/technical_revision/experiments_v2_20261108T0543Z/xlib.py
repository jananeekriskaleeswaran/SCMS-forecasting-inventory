"""Shared helpers for R1/R2/R4: frozen case list, per-case feasibility checks, independent reconstruction (policies via
consolidation_v2/independent.py; B1/B2 via an independent formula here), time-weighted cycle stock."""
import os as _os_root
_HA_ROOT = _os_root.environ.get("HYBRID_ANN_ROOT") or _os_root.path.abspath(_os_root.path.join(_os_root.path.dirname(_os_root.path.abspath(__file__)), "..", ".."))  # portable root (build_repo.py)
import os, sys, ast, math, numpy as np, pandas as pd
TR = f"{_HA_ROOT}/technical_revision"; sys.path.insert(0, f"{TR}/consolidation_v2")
import engine_v2 as V2, independent as IND
E, SD, C3 = V2.E, V2.SD, V2.C3
REL = 1e-9

def frozen_cases():
    """Executes the exact source of consolidation/run_step.py::cases (extracted with ast; no re-typing)."""
    src = open(f"{TR}/consolidation/run_step.py").read(); node = next(n for n in ast.parse(src).body if isinstance(n, ast.FunctionDef) and n.name == "cases")
    ns = {"C3": C3}; exec(ast.get_source_segment(src, node), ns); c = ns["cases"](); assert len(c) == 34; return c

def obs_quarters(B):
    O = B.OBS.copy(); d = O.asn.map(SD.SHIP.set_index("ASN/DN #").date)
    O["q"] = np.searchsorted(np.array(B.TAUS, dtype="datetime64[ns]"), d.values.astype("datetime64[ns]"), side="right") - 1
    assert O.q.between(0, 3).all(); return O

def check_policy(e, B, plan, df, ledger, pol):
    """Per-case feasibility invariants + independent reconstruction for one policy. Returns (summary dict, failures list)."""
    fails = []; m = e.cap; led = [r for r in ledger if r["policy"] == pol]
    exp_units = {(q, "/".join(map(str, b))) for q, units in enumerate(plan) for b, o, T in units if any(B.QDEM[i][q] > 0 for i in b)}
    got = [(r["q"], r["bundle"]) for r in led]
    if len(got) != len(set(got)) or set(got) != exp_units: fails.append(("unit records", len(exp_units), len(got)))
    tot = {}; n_exc_units = n_exc_members = n_below = 0
    for r in led:
        for i, x in r["x"].items():
            d = r["d"][i]; tot[i] = tot.get(i, 0.0) + r["n"] * x
            if abs(r["n"] * x - d) > REL * max(d, 1): fails.append(("conservation", r["q"], r["bundle"], i))
            if x > r["b"][i] * (1 + 1e-9): fails.append(("x>b", r["q"], r["bundle"], i))
            if x > (m / 3.0) * d * (1 + 1e-9): fails.append(("cover", r["q"], r["bundle"], i))
        if r["opt"] != C3.EMBEDDED:
            if r["W"] > r["W_max"] * (1 + 1e-9): fails.append(("W>Wmax", r["q"], r["bundle"]))
            if r["W"] < r["W_min"] * (1 - 1e-12) and abs(r["W_priced"] - r["W_min"]) > 1e-9 * r["W_min"]: fails.append(("floor", r["q"], r["bundle"]))
        if r["shortfall"]:
            if r["status"] != "EXCEPTION" or not r["flags"]: fails.append(("unflagged shortfall", r["q"], r["bundle"]))
            n_exc_members += len(r["shortfall"])
        n_exc_units += r["status"] == "EXCEPTION"; n_below += bool(r["below_support"])
    for i, l in enumerate(B.lanes):
        if abs(tot.get(i, 0.0) - l["D_act"]) > 1e-9 * l["D_act"]: fails.append(("annual conservation", i))
    rec = IND.reconstruct(led, B.lanes, B.QDEM, e.LT, {"h": e.h, "K": e.K, "z": e.z, "fmult": e.fmult}, e.cv, frozen_eval(e))   # D-R1-1: formula check
    rec_direct = IND.reconstruct(led, B.lanes, B.QDEM, e.LT, {"h": e.h, "K": e.K, "z": e.z, "fmult": e.fmult}, e.cv, e.FM.predict)  # surrogate check
    R = df.set_index("lane"); maxrel = 0.0
    for i, c in rec.items():
        for k in ("ordering", "freight", "cycle", "safety", "pipeline", "total"):
            a, b = float(R.loc[i, k]), float(c[k]); rel = abs(a - b) / max(abs(b), 1.0); maxrel = max(maxrel, rel)
            if rel > REL: fails.append(("reconstruction", pol, i, k, a, b))
    tw = sum(e.h * B.lanes[i]["c"] * 0.25 * x / 2 for r in led for i, x in r["x"].items())
    sur = surrogate_rows(e, [(r["W_priced"], r["opt"], B.lanes[int(r["bundle"].split("/")[0])]["country"]) for r in led])
    return {"total_direct_predict": float(sum(c["total"] for c in rec_direct.values())), "surrogate_rows": sur[0], "surrogate_rows_rel_gt_1e-9": sur[1], "surrogate_max_rel": sur[2],"unit_quarters": len(led), "exception_unit_quarters": n_exc_units, "exception_members": n_exc_members, "below_support": n_below,
            "multi_lane_bundles": sum(r["size"] > 1 for r in led), "shipments": float(sum(r["n"] for r in led)), "recon_max_rel": maxrel, "cycle_tw": tw}, fails

def frozen_eval(e):
    """The frozen surrogate evaluator used by the engine (interpolated table), wrapped to the reconstruct() signature."""
    return lambda W, o, c: e.FM.f(np.atleast_1d(np.asarray(W, float)), o[0], c[0])

def surrogate_rows(e, items):
    """|interpolated - direct| / direct for (W, opt, country) items with a modelled option. Returns (n, n_rel>1e-9, max_rel)."""
    rels = [abs(float(e.FM.f(np.array([W]), o, c)[0]) / float(e.FM.predict(np.array([W]), [o], [c])[0]) - 1) for W, o, c in items if o != C3.EMBEDDED]
    return len(rels), int(sum(r > 1e-9 for r in rels)), float(max(rels) if rels else 0.0)

def reconstruct_observed(e, B, consolidated, direct=False):
    """Independent B1/B2 reconstruction from OBS rows (own formula; surrogate's direct predict)."""
    O = B.OBS; out = {}
    for i, l in enumerate(B.lanes):
        o = O[O.lane == i]; D = float(o.packs.sum()); n = len(o); c = l["c"]
        F = lambda W, opt, cty: 0.0 if opt == C3.EMBEDDED else (float(e.FM.predict(np.array([W]), [opt], [cty])[0]) if direct else float(e.FM.f(np.array([W]), opt, cty)[0])) * e.fmult.get(opt, 1.0)
        if consolidated: ordv = e.K * o.share.sum(); fr = sum(F(W, op, ct) * s for W, op, ct, s in zip(o.W_ship, o.opt_priced, o.country, o.share))
        else: ordv = e.K * n; fr = sum(F(pk * w, op, ct) for op, ct, pk, w in zip(o.opt_priced, o.country, o.packs, o.w))
        Lm = np.array([e.LT[x][0] for x in o.opt_priced]); sL = np.array([e.LT[x][1] for x in o.opt_priced]); pk = o.packs.values
        Lw, sLw = float(np.sum(pk * Lm) / D), float(np.sum(pk * sL) / D); Da = l["D_act"]; T = 1.0 / n
        sigma = math.sqrt(((365.0 * T + Lw) / 30.0) * (e.cv * Da / 12.0) ** 2 + (Da / 12.0) ** 2 * (sLw / 30.0) ** 2)
        comp = {"ordering": ordv, "freight": fr, "cycle": e.h * c * (D / n) / 2, "safety": e.h * c * e.z * sigma, "pipeline": e.h * c * float(np.sum(pk * Lm)) / 365}
        comp["total"] = sum(comp.values()); out[i] = comp
    return out

def compare_obs(df, rec, tag):
    fails = []; R = df.set_index("lane"); mx = 0.0
    for i, c in rec.items():
        for k in ("ordering", "freight", "cycle", "safety", "pipeline", "total"):
            a, b = float(R.loc[i, k]), float(c[k]); rel = abs(a - b) / max(abs(b), 1.0); mx = max(mx, rel)
            if rel > REL: fails.append(("reconstruction", tag, i, k, a, b))
    return mx, fails

def tw_observed(e, B, OQ):
    g = OQ.groupby(["lane", "q"]).agg(d=("packs", "sum"), k=("asn", "nunique")).reset_index()
    return float(sum(e.h * B.lanes[l]["c"] * 0.25 * (d / k) / 2 for l, d, k in zip(g.lane, g.d, g.k)))
