"""R1: v2 Step 2/3, 34 frozen cases, per-case checks + independent reconstruction, TW robustness, bootstraps, criteria, E0/E1/E3."""
import os, sys, json, time, hashlib, warnings, numpy as np, pandas as pd, statsmodels.formula.api as smf
from multiprocessing import Pool
warnings.filterwarnings("ignore"); HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import xlib as X
E, SD, C3, V2 = X.E, X.SD, X.C3, X.V2
OUT = f"{HERE}/results/R1"; B = None; OQ = None; STEP = None

def run_case(args):
    name, val, p = args; t0 = time.time(); e = V2.EngineV2(B, p); plans = {pol: e.plan(pol) for pol in E.POLICIES}; res, _ = e.run_all(plans)
    fails, chk = [], {}
    for pol in E.POLICIES:
        s, f = X.check_policy(e, B, plans[pol], res[pol], e.ledger, pol); chk[pol] = s; fails += f
    for tag, cons in (("B1", True), ("B2", False)):
        mx, f = X.compare_obs(res[tag], X.reconstruct_observed(e, B, cons), tag); fails += f
        O = B.OBS; items = list(zip(O.W_ship, O.opt_priced, O.country)) if cons else list(zip(O.packs * O.w, O.opt_priced, O.country)); sur = X.surrogate_rows(e, items)
        chk[tag] = {"recon_max_rel": mx, "total_direct_predict": float(sum(c["total"] for c in X.reconstruct_observed(e, B, cons, direct=True).values())), "surrogate_rows": sur[0], "surrogate_rows_rel_gt_1e-9": sur[1], "surrogate_max_rel": sur[2]}
    tw_obs = X.tw_observed(e, B, OQ)
    tot = {k: float(v.total.sum()) for k, v in res.items()}; comp = {k: {c: float(v[c].sum()) for c in E.PARTS} for k, v in res.items()}
    cyc = {k: float(v.cycle.sum()) for k, v in res.items()}
    tw = {k: tot[k] - cyc[k] + (chk[k]["cycle_tw"] if k in E.POLICIES else tw_obs) for k in tot}
    keep = name in ("base", "freight-only") or (name == "K" and val == 250.0)
    lanes = pd.concat([v.assign(policy=k) for k, v in res.items()]) if keep else None
    if keep:   # lane-level TW totals for bootstrap of the robustness variant
        twl = {}
        for pol in E.POLICIES:
            acc = {}
            for r in e.ledger:
                if r["policy"] != pol: continue
                for i, x in r["x"].items(): acc[i] = acc.get(i, 0.0) + e.h * B.lanes[i]["c"] * 0.25 * x / 2
            d = res[pol].set_index("lane"); twl[pol] = (d.total - d.cycle + pd.Series(acc)).to_dict()
        g = OQ.groupby(["lane", "q"]).agg(d=("packs", "sum"), k=("asn", "nunique")).reset_index(); g["tw"] = [e.h * B.lanes[l]["c"] * 0.25 * (dd / k) / 2 for l, dd, k in zip(g.lane, g.d, g.k)]
        twb = g.groupby("lane").tw.sum()
        for tag in ("B1", "B2"): d = res[tag].set_index("lane"); twl[tag] = (d.total - d.cycle + twb).to_dict()
    else: twl = None
    dec = pd.DataFrame([{"policy": pol, "q": q, "bundle": "/".join(map(str, b)), "opt": o, "T_years": T} for pol in E.POLICIES for q, u in enumerate(plans[pol]) for b, o, T in u])
    led = pd.DataFrame([{k: v for k, v in r.items() if k not in ("x", "a", "b", "d", "shortfall", "over_max")} | {"shortfall": str(r["shortfall"])} for r in e.ledger])
    return dict(name=name, value=str(val), totals=tot, totals_tw=tw, components=comp, checks=chk, fails=fails, lanes=lanes, lanes_tw=twl, decisions=dec, ledger=led, runtime_s=time.time() - t0,
                plans=plans if name == "base" else None)

class ElasticityEvaluator:
    def __init__(self, base, dbeta, wref, wall): self.base, self.db, self.wref, self.wall = base, dbeta, wref, wall
    def f(self, W, o, c): W = np.atleast_1d(np.asarray(W, float)); return self.base.f(W, o, c) * (W / self.wref.get(o, self.wall)) ** self.db

def e3_evaluator():
    ev = B.fr_ev.copy(); ann = B.FM["ANN"]; ev["lW"] = np.log(ev.W); ev["lF"] = np.log(ev.F); ev["lA"] = np.log(ann.predict(ev.W.values, ev.opt.values, ev.country.values)); ev["g"] = ev.opt + "|" + ev.country
    ba = smf.ols("lF ~ lW + C(g)", ev).fit(); bn = smf.ols("lA ~ lW + C(g)", ev).fit()
    return ElasticityEvaluator(ann, float(ba.params.lW - bn.params.lW), ev.groupby("opt").lW.mean().apply(np.exp).to_dict(), float(np.exp(ev.lW.mean()))), {"beta_actual": float(ba.params.lW), "beta_ANN": float(bn.params.lW)}

def W_of(lanes_df): return lanes_df.pivot(index="lane", columns="policy", values="total")

if __name__ == "__main__":
    STEP = int(sys.argv[1]); T_END = {2: "2013-08-31", 3: "2014-08-31"}[STEP]; t_all = time.time(); os.makedirs(f"{OUT}/step{STEP}", exist_ok=True); O = f"{OUT}/step{STEP}"
    B = SD.build(T_END); OQ = X.obs_quarters(B); CASES = X.frozen_cases()
    with Pool(2) as pool: R = pool.map(run_case, CASES, chunksize=1)
    LOG = {"step": STEP, "T_END": T_END, "n_lanes": len(B.lanes), "n_countries": len({l["country"] for l in B.lanes}), "CV": B.CV,
           "code_sha": {f: hashlib.sha256(open(p, "rb").read()).hexdigest() for f, p in (("engine_v2", f"{X.TR}/consolidation_v2/engine_v2.py"), ("engine_v1", f"{X.TR}/consolidation/engine.py"), ("stage2data", f"{X.TR}/consolidation/stage2data.py"), ("independent", f"{X.TR}/consolidation_v2/independent.py"), ("xlib", f"{HERE}/xlib.py"), ("r1", f"{HERE}/r1.py"))}}
    rows, chk_rows, all_fails = [], [], []
    for r in R:
        row = {"parameter": r["name"], "value": r["value"], **{f"{k}_total": v for k, v in r["totals"].items()}, **{f"{k}_total_TW": v for k, v in r["totals_tw"].items()}, "runtime_s": r["runtime_s"]}
        for pol in E.POLICIES:
            row[f"{pol}_vs_B1_pct"] = 100 * (r["totals"][pol] / r["totals"]["B1"] - 1); row[f"{pol}_vs_B2_pct"] = 100 * (r["totals"][pol] / r["totals"]["B2"] - 1); row[f"{pol}_vs_B1_pct_TW"] = 100 * (r["totals_tw"][pol] / r["totals_tw"]["B1"] - 1)
        td = {k: r["checks"][k]["total_direct_predict"] for k in r["checks"]}
        for pol in E.POLICIES: row[f"{pol}_vs_B1_pct_direct_predict"] = 100 * (td[pol] / td["B1"] - 1); row[f"{pol}_direct_minus_frozen_pp"] = row[f"{pol}_vs_B1_pct_direct_predict"] - row[f"{pol}_vs_B1_pct"]
        rows.append(row)
        for pol, c in r["checks"].items(): chk_rows.append({"parameter": r["name"], "value": r["value"], "arm": pol, **c, "n_failures": sum(1 for f in r["fails"] if (len(f) > 1 and f[1] == pol) or pol in map(str, f))})
        all_fails += [(r["name"], r["value"]) + tuple(f) for f in r["fails"]]
        tag = r["name"].replace(" ", "_").replace("[", "").replace("]", "").replace("|", "-").replace("(", "").replace(")", "") + "_" + r["value"]
        r["decisions"].to_csv(f"{O}/decisions_{tag}.csv.gz", index=False, compression="gzip"); r["ledger"].to_csv(f"{O}/ledger_{tag}.csv.gz", index=False, compression="gzip")
        pd.DataFrame([{"arm": k, **v} for k, v in r["components"].items()]).assign(parameter=r["name"], value=r["value"]).to_csv(f"{O}/components_{tag}.csv", index=False)
    S = pd.DataFrame(rows); S.to_csv(f"{O}/case_results.csv", index=False); pd.DataFrame(chk_rows).to_csv(f"{O}/case_checks.csv", index=False)
    pd.DataFrame(all_fails).to_csv(f"{O}/check_failures.csv", index=False); LOG["check_failures"] = len(all_fails)
    LOG["recon_max_rel_all"] = float(pd.DataFrame(chk_rows).recon_max_rel.max())
    if all_fails: json.dump(LOG, open(f"{HERE}/logs/R1_step{STEP}_log.json", "w"), indent=1, default=str); print("CHECK FAILURES:", len(all_fails), all_fails[:5]); sys.exit(2)
    # ---- inference ----
    for r in R:
        if r["lanes"] is None: continue
        tagk = {"base": "base", "freight-only": "K0"}.get(r["name"], "K250"); r["lanes"].to_csv(f"{O}/lane_costs_{tagk}.csv", index=False)
        W = W_of(r["lanes"]); cty = r["lanes"][r["lanes"].policy == "B1"].set_index("lane").country.loc[W.index].values; t = r["totals"]
        LOG[tagk] = {"totals": t, "components": r["components"], "delta_vs_B1_pct": {p: 100 * (t[p] / t["B1"] - 1) for p in E.POLICIES + ["B2"]}, "abs_diff_vs_B1_usd": {p: t[p] - t["B1"] for p in E.POLICIES},
                     "cluster_CI95_vs_B1_pct": {p: E.boot(W[p], W["B1"], cty) for p in E.POLICIES}, "lane_CI95_vs_B1_pct": {p: E.boot(W[p], W["B1"], cty, cluster=False) for p in E.POLICIES},
                     "cluster_CI95_vs_B2_pct": {p: E.boot(W[p], W["B2"], cty) for p in E.POLICIES}, "checks": r["checks"]}
        WT = pd.DataFrame(r["lanes_tw"]).loc[W.index]
        LOG[tagk]["TW"] = {"delta_vs_B1_pct": {p: 100 * (WT[p].sum() / WT["B1"].sum() - 1) for p in E.POLICIES}, "cluster_CI95_vs_B1_pct": {p: E.boot(WT[p], WT["B1"], cty) for p in E.POLICIES}}
    s32 = S[~S.parameter.isin(["base", "freight-only"])]; assert len(s32) == 32
    LOG["sensitivity_share_cheaper_than_B1"] = {p: float((s32[f"{p}_vs_B1_pct"] < 0).mean()) for p in E.POLICIES}; LOG["sensitivity_range_vs_B1_pct"] = {p: [float(s32[f"{p}_vs_B1_pct"].min()), float(s32[f"{p}_vs_B1_pct"].max())] for p in E.POLICIES}
    LOG["sensitivity_share_cheaper_than_B1_TW"] = {p: float((s32[f"{p}_vs_B1_pct_TW"] < 0).mean()) for p in E.POLICIES}; LOG["sensitivity_range_vs_B1_pct_TW"] = {p: [float(s32[f"{p}_vs_B1_pct_TW"].min()), float(s32[f"{p}_vs_B1_pct_TW"].max())] for p in E.POLICIES}
    # ---- plans identical to saved v1 decisions (validity of reused PSO check) ----
    base = next(r for r in R if r["name"] == "base"); dv1 = pd.read_csv(f"{X.TR}/consolidation/outputs/step{STEP}/decisions_base.csv")
    a = base["decisions"].sort_values(["policy", "q", "bundle"]).reset_index(drop=True); b = dv1.sort_values(["policy", "q", "bundle"]).reset_index(drop=True)
    LOG["base_plans_identical_to_v1"] = bool(len(a) == len(b) and (a[["policy", "q", "bundle", "opt"]].values == b[["policy", "q", "bundle", "opt"]].values).all() and np.allclose(a.T_years, b.T_years, rtol=1e-12))
    v1 = json.load(open(f"{X.TR}/consolidation/logs/step{STEP}_log.json")); LOG["pso_check_reused_from_v1"] = v1["pso"]
    # ---- freight evaluators on v2 base plans ----
    plans = base["plans"]; G3, LOG["E3_estimates"] = e3_evaluator()
    for tagE, G in (("E0", B.FM["ANN"]), ("E1", B.FM["OLS"]), ("E3", G3)):
        ev = V2.EngineV2(B); ev.FM = G; res = {"B1": ev.observed(True), "B2": ev.observed(False)}
        for p in E.POLICIES: res[p] = ev.realise(plans[p], p)
        W = pd.DataFrame({k: v.set_index("lane").total for k, v in res.items()}); cty = res["B1"].set_index("lane").country.loc[W.index].values; t = W.sum()
        LOG[f"freight_{tagE}"] = {"delta_vs_B1_pct": {p: float(100 * (t[p] / t["B1"] - 1)) for p in E.POLICIES}, "cluster_CI95_vs_B1_pct": {p: E.boot(W[p], W["B1"], cty) for p in E.POLICIES}, "totals": t.to_dict()}
    k250 = LOG["K250"]; b0 = LOG["base"]
    LOG["claim_criteria_CONSOLIDATED_vs_B1"] = {"1_base_cluster_CI_below_0": bool(b0["cluster_CI95_vs_B1_pct"]["CONSOLIDATED"][1] < 0), "2_cheaper_in_>=75pct_of_32_cases": bool(LOG["sensitivity_share_cheaper_than_B1"]["CONSOLIDATED"] >= 0.75),
        "3_K250_cluster_CI_below_0": bool(k250["cluster_CI95_vs_B1_pct"]["CONSOLIDATED"][1] < 0), "4_freight_only_reported": True,
        "5_PSO_within_0.1pct_on_>=95pct": bool(LOG["pso_check_reused_from_v1"]["share_runs_within_0.1pct"] >= 0.95 and LOG["base_plans_identical_to_v1"]), "6_all_policies_reported": True}
    LOG["claim_criteria_CONSOLIDATED_vs_B1"]["ALL"] = all(LOG["claim_criteria_CONSOLIDATED_vs_B1"].values())
    LOG["runtime_s"] = time.time() - t_all; json.dump(LOG, open(f"{HERE}/logs/R1_step{STEP}_log.json", "w"), indent=1, default=str)
    print(json.dumps({k: LOG[k] for k in ("check_failures", "recon_max_rel_all", "base_plans_identical_to_v1", "claim_criteria_CONSOLIDATED_vs_B1", "sensitivity_share_cheaper_than_B1", "runtime_s")}, indent=1, default=str))
    print("base:", {k: round(v, 3) for k, v in b0["delta_vs_B1_pct"].items()}, b0["cluster_CI95_vs_B1_pct"]["CONSOLIDATED"])
