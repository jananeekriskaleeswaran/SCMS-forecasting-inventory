"""R2: ANN-to-cost via the CV channel (10 forecasters + lane-demand oracle reference), both years, v2 realisation.
Own-CV and common-evaluator costing; per-realisation feasibility + independent reconstruction; paired country-cluster bootstrap."""
import os, sys, json, time, copy, hashlib, warnings, numpy as np, pandas as pd
from multiprocessing import Pool
warnings.filterwarnings("ignore"); HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import xlib as X
E, SD, C3, V2 = X.E, X.SD, X.C3, X.V2
OUT = f"{HERE}/results/R2"; POLS = ["CONSOLIDATED", "INDEPENDENT"]
FORECASTERS = {"ANN": "ANN", "AVLA-ANN": "AVLA-ANN (paper ensemble)", "Random Forest": "Random Forest (tuned)", "XGBoost": "XGBoost (tuned)", "Ridge": "Ridge regression",
               "Holt": "Holt (damped)", "SARIMA": "SARIMA(0,1,1)(1,0,0)12", "SES": "SES", "Naive": "Naive", "Seasonal naive": "Seasonal naive"}
FC = pd.read_csv(f"{X.TR}/reviewer_tests/forecast_benchmark/outputs/forecasts_all.csv", parse_dates=["month"]); MS = pd.read_csv(f"{X.TR}/reviewer_tests/forecast_benchmark/outputs/metrics_summary.csv")
B = None

def cv_of(model, T_END):
    T_END = pd.Timestamp(T_END); f = FC[(FC.model == model) & (FC.seed == 42) & (FC.month > T_END - pd.DateOffset(months=24)) & (FC.month <= T_END)]
    assert len(f) == 24, (model, len(f)); e = f.actual - f.pred
    return float(np.sqrt(np.mean(e ** 2)) / f.actual.mean()), float(np.sqrt(np.mean(e ** 2))), str(f.month.min().date()), str(f.month.max().date())

def job(args):
    label, cvm, oracle = args; t0 = time.time()
    Bp = B
    if oracle: Bp = copy.copy(B); Bp.DPLAN = {i: [4.0 * B.QDEM[i][q] for q in range(4)] for i in range(len(B.lanes))}
    ep = V2.EngineV2(Bp, {"cv_mult": cvm}); plans = {p: ep.plan(p) for p in POLS}; out = {"label": label, "cv_mult": cvm}; fails = []
    for mode, ev in (("own", V2.EngineV2(B, {"cv_mult": cvm})), ("common", V2.EngineV2(B))):
        res = {"B1": ev.observed(True)}
        for p in POLS:
            res[p] = ev.realise(plans[p], p); s, f = X.check_policy(ev, B, plans[p], res[p], ev.ledger, p); fails += f; out[f"{mode}_{p}_checks"] = s
        mx, f = X.compare_obs(res["B1"], X.reconstruct_observed(ev, B, True), "B1"); fails += f
        out[mode] = {k: v.set_index("lane")[E.PARTS + ["total"]].to_dict() for k, v in res.items()}
    out["fails"] = fails; out["runtime_s"] = time.time() - t0; return out

if __name__ == "__main__":
    t_all = time.time(); os.makedirs(OUT, exist_ok=True); LOG = {"forecasters": FORECASTERS}; audit_rows = []
    for step, T_END in ((2, "2013-08-31"), (3, "2014-08-31")):
        B = SD.build(T_END); cvs = {k: cv_of(m, T_END) for k, m in FORECASTERS.items()}
        assert abs(cvs["ANN"][0] - B.CV) <= 1e-12 * B.CV, (cvs["ANN"][0], B.CV)                       # frozen procedure reproduced
        for k, m in FORECASTERS.items():
            t = MS[(MS.model == m) & (MS.window == "test")].iloc[0]
            audit_rows.append({"step": step, "forecaster": k, "benchmark_model": m, "CV": cvs[k][0], "RMSE_cv_window": cvs[k][1], "cv_window": f"{cvs[k][2]}..{cvs[k][3]}", "n_months": 24,
                               "cv_mult_vs_frozen": cvs[k][0] / B.CV, "test_RMSE_Sep13_Aug15": float(t.RMSE), "test_MAD": float(t["MAD (=MAE)"])})
        jobs = [(k, cvs[k][0] / B.CV, False) for k in FORECASTERS] + [("Lane-demand oracle (reference)", 1.0, True)]
        with Pool(2) as pool: R = pool.map(job, jobs, chunksize=1)
        fails = [f for r in R for f in r["fails"]]
        if fails: json.dump({"fails": fails[:50]}, open(f"{HERE}/logs/R2_failures.json", "w"), default=str); print("CHECK FAILURES", len(fails)); sys.exit(2)
        cty = pd.Series({i: l["country"] for i, l in enumerate(B.lanes)})
        res = {r["label"]: r for r in R}; ann = res["ANN"]; rows = []
        for r in R:
            for p in POLS:
                lane = lambda rr, mode, arm: pd.Series(rr[mode][arm]["total"]).sort_index()
                Pc, Pa, B1c = lane(r, "common", p), lane(ann, "common", p), lane(r, "common", "B1"); Po, B1o = lane(r, "own", p), lane(r, "own", "B1"); c = cty.loc[Pc.index].values
                comp = {f"{k}_common": float(pd.Series(r["common"][p][k]).sum()) for k in E.PARTS}
                rows.append({"step": step, "forecaster": r["label"], "policy": p, "cv_mult": r["cv_mult"], "cost_common": float(Pc.sum()), "cost_own": float(Po.sum()), "B1_common": float(B1c.sum()), "B1_own": float(B1o.sum()),
                             "diff_vs_ANN_usd_common": float(Pc.sum() - Pa.sum()), "diff_vs_ANN_pct_common": float(100 * (Pc.sum() / Pa.sum() - 1)), "CI95_vs_ANN_pct_common": E.boot(Pc, Pa, c) if r["label"] != "ANN" else [0.0, 0.0],
                             "delta_vs_B1_pct_common": float(100 * (Pc.sum() / B1c.sum() - 1)), "CI95_vs_B1_pct_common": E.boot(Pc, B1c, c),
                             "delta_vs_B1_pct_own": float(100 * (Po.sum() / B1o.sum() - 1)), "CI95_vs_B1_pct_own": E.boot(Po, B1o, c),
                             "exception_unit_quarters_common": r[f"common_{p}_checks"]["exception_unit_quarters"], "recon_max_rel_common": r[f"common_{p}_checks"]["recon_max_rel"],
                             "recon_max_rel_own": r[f"own_{p}_checks"]["recon_max_rel"], "runtime_s": r["runtime_s"], **comp})
        pd.DataFrame(rows).to_csv(f"{OUT}/step{step}_forecaster_costs.csv", index=False); LOG[f"step{step}"] = {"B_CV": B.CV, "n_lanes": len(B.lanes)}
        json.dump({r["label"]: {m: r[m] for m in ("own", "common")} for r in R}, open(f"{OUT}/step{step}_lane_level.json", "w"))
        print(f"step {step} done", flush=True)
    pd.DataFrame(audit_rows).to_csv(f"{OUT}/cv_input_audit.csv", index=False)
    LOG["runtime_s"] = time.time() - t_all; LOG["code_sha"] = {f: hashlib.sha256(open(f"{HERE}/{f}", "rb").read()).hexdigest() for f in ("r2.py", "xlib.py")}
    json.dump(LOG, open(f"{HERE}/logs/R2_log.json", "w"), indent=1, default=str)
