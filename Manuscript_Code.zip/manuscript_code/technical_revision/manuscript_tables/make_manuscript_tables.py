"""Build the tables, figure data and Figure 5 of the manuscript from the outputs of the analysis scripts.

Reads only the outputs of the stages listed in README.md; it does not refit or re-run anything.
Writes to manuscript_tables/outputs/.
"""
import os, json
import numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt

ROOT = os.environ.get("HYBRID_ANN_ROOT") or os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
TR = f"{ROOT}/technical_revision"
OUT = os.environ.get("MANUSCRIPT_TABLES_OUT") or f"{TR}/manuscript_tables/outputs"
os.makedirs(OUT, exist_ok=True)
YEARS = (("2013-14", 2), ("2014-15", 3))

# ---------- Table 3: forecast accuracy, main comparison ----------
E2 = pd.read_csv(f"{TR}/forecast_freeze_E1E2_20261116/outputs/E2_table_test.csv")
DM = pd.read_csv(f"{TR}/dm_main_comparators_20261117/outputs/dm_results.csv")
NAMES = {"MA(12)": "MA(12)", "ARIMA(0,1,2)": "ARIMA(0,1,2)", "SES": "SES", "Random Forest (tuned)": "Random forest (tuned)",
         "ANN (fixed manuscript configuration, MLP 128-64)": "ANN (base configuration)",
         "AVLA-ANN + order book (pre-declared extension)": "AVLA-ANN + order book (proposed)"}
rows = []
prim = DM[(DM.family == "primary") & (DM.seed == 42)].set_index("comparator")
for src, lab in NAMES.items():
    r = E2[E2.model == src].iloc[0]
    d = prim.loc[src] if src in prim.index else None
    rows.append({"Model": lab, "Order book": "Yes" if "order book" in src else "No", "RMSE": r.RMSE, "MSE (x10^3)": r.RMSE ** 2 / 1e3,
                 "MAD": r.MAE, "MASE": r.MASE, "Skill vs naive": r["Skill vs naive"],
                 "RMSE six seeds mean": r["RMSE mean (seeds)"] if r.seeds == 6 else np.nan, "RMSE six seeds SD": r["RMSE SD (seeds)"] if r.seeds == 6 else np.nan,
                 "DM vs proposed": d.DM_HLN if d is not None else np.nan, "p": d.p if d is not None else np.nan, "Holm p": d.p_holm if d is not None else np.nan})
pd.DataFrame(rows).to_csv(f"{OUT}/Table3_forecast_accuracy.csv", index=False)

# ---------- Supplementary Table S5: all 23 methods; S6: ablation ----------
E2[["rank (RMSE)", "model", "RMSE", "MAE", "MASE", "Skill vs naive", "RMSE mean (seeds)", "RMSE SD (seeds)", "seeds"]].to_csv(f"{OUT}/TableS5_all_methods.csv", index=False)
ab = DM[(DM.family == "S2 ablation") & (DM.seed == 42)][["comparator", "RMSE_comparator", "MAE_comparator", "DM_HLN", "p", "p_holm"]]
ab.to_csv(f"{OUT}/TableS6_ablation.csv", index=False)
# robustness of the DM conclusions (absolute loss; each seed)
DM[DM.family != "S2 ablation"].to_csv(f"{OUT}/Table3_DM_tests_all.csv", index=False)

# ---------- Table 4: policy costs and components ----------
pol, comp = [], []
for yr, s in YEARS:
    b = json.load(open(f"{TR}/experiments_v2_20261108T0543Z/logs/R1_step{s}_log.json"))["base"]
    for p in ("CONSOLIDATED", "OBSERVED_SET", "INDEPENDENT", "EOQ_DOMINANT"):
        pol.append({"Year": yr, "Policy": p, "Modelled cost (USD)": b["totals"][p], "Observed shipments (USD)": b["totals"]["B1"],
                    "Change vs observed (%)": b["delta_vs_B1_pct"][p], "95% CI low (%)": b["cluster_CI95_vs_B1_pct"][p][0], "95% CI high (%)": b["cluster_CI95_vs_B1_pct"][p][1]})
    for arm in ("B1", "CONSOLIDATED", "INDEPENDENT", "OBSERVED_SET", "EOQ_DOMINANT"):
        comp.append({"Year": yr, "Policy": "OBSERVED" if arm == "B1" else arm, **b["components"][arm], "total": sum(b["components"][arm].values())})
pd.DataFrame(pol).to_csv(f"{OUT}/Table4_policy_costs.csv", index=False)
pd.DataFrame(comp).to_csv(f"{OUT}/Table4_cost_components.csv", index=False)

# ---------- Table 5: PSO validation ----------
AU = f"{TR}/audit_followups_20261116/outputs"
pd.read_csv(f"{AU}/E1_summary_by_period.csv").to_csv(f"{OUT}/Table5_PSO_validation_summary.csv", index=False)
pd.read_csv(f"{AU}/E1_run_table.csv").to_csv(f"{OUT}/Table5_PSO_validation_runs.csv", index=False)

# ---------- Figure 5: sensitivity cases ----------
cases = []
for yr, s in YEARS:
    c = pd.read_csv(f"{TR}/experiments_v2_20261108T0543Z/results/R1/step{s}/case_results.csv")
    c.insert(0, "Year", yr); cases.append(c[["Year", "parameter", "value", "CONSOLIDATED_vs_B1_pct", "INDEPENDENT_vs_B1_pct"]])
cases = pd.concat(cases); cases.to_csv(f"{OUT}/Figure5_sensitivity_cases.csv", index=False)
lab = np.where(cases.parameter == "base", "Base case", cases.parameter + " = " + cases.value.astype(str))
cases = cases.assign(label=lab)
order = cases[cases.Year == "2013-14"].label.tolist()
fig, ax = plt.subplots(figsize=(7.2, 7.6))
for yr, col in (("2013-14", "#2f6fdf"), ("2014-15", "#d4693a")):
    x = cases[cases.Year == yr].set_index("label").loc[order]
    ax.plot(x.CONSOLIDATED_vs_B1_pct, range(len(x)), "o", color=col, ms=5, label=yr)
ax.axvline(0, color="#1f2328", lw=0.8); ax.set_yticks(range(len(order))); ax.set_yticklabels(order, fontsize=7); ax.invert_yaxis()
ax.set_xlabel("Consolidated plan vs observed shipments (%)"); ax.legend(frameon=False, fontsize=8, loc="lower right")
for sp in ("top", "right"): ax.spines[sp].set_visible(False)
ax.grid(axis="x", color="#e5e7eb", lw=0.6)
fig.tight_layout(); fig.savefig(f"{OUT}/Figure5_sensitivity.png", dpi=300); plt.close(fig)

# ---------- Robustness checks reported in Results ----------
rob = []
cs = json.load(open(f"{TR}/pso_consistency_scenario_20261116/outputs/results.json"))
fd = json.load(open(f"{TR}/freight_ann_avla_20261108/outputs/downstream/downstream_log.json"))
e4 = json.load(open(f"{AU}/e4/e4_summary.json"))
for yr, s in YEARS:
    lt = json.load(open(f"{AU}/e2/diag_step{s}_leadtime_only.json"))["totals"]
    ref = cs[f"step{s}"]["B_reference_current_options"]["delta_vs_Observed_pct"]["CONSOLIDATED"]
    f = fd["2013-08-31" if s == 2 else "2014-08-31"]["plan_and_evaluate_ANN-AVLA"]
    rob += [{"Year": yr, "Check": "Safety stock over lead time only, consolidated (%)", "Value": 100 * (lt["CONSOLIDATED"] / lt["B1"] - 1)},
            {"Year": yr, "Check": "Safety stock over lead time only, independent (%)", "Value": 100 * (lt["INDEPENDENT"] / lt["B1"] - 1)},
            {"Year": yr, "Check": "Top three countries: share of reduction", "Value": e4[yr]["top3_share_of_saving"]},
            {"Year": yr, "Check": "Top three countries: share of baseline cost", "Value": e4[yr]["top3_share_of_B1_cost"]},
            {"Year": yr, "Check": "Change without top three countries (%)", "Value": e4[yr]["delta_without_top3_pct"]},
            {"Year": yr, "Check": "Alternative ML freight model, consolidated (%)", "Value": f["delta_vs_Observed_pct"]["CONSOLIDATED"],
             "95% CI": str([round(v, 2) for v in f["CONSOLIDATED_cluster_CI95"]])},
            {"Year": yr, "Check": "Proposed forecaster, common costing: change in modelled cost of the plan (%)",
             "Value": 100 * ((1 + cs[f"step{s}"]["A_consistency"]["CONSOLIDATED"]["delta_vs_Observed_pct_new"] / 100) / (1 + ref / 100) - 1)}]
pd.DataFrame(rob).to_csv(f"{OUT}/Robustness_checks.csv", index=False)
# concentration analysis details
for yr, s in YEARS:
    p = f"{AU}/e4/country_table_step{s}.csv"
    if os.path.exists(p): pd.read_csv(p).to_csv(f"{OUT}/Robustness_country_contributions_{yr}.csv", index=False)

# ---------- Forecast accuracy and inventory cost (own costing) ----------
own = []
for yr, s in YEARS:
    own.append(pd.read_csv(f"{TR}/forecast_value_own_costing_20261116/outputs/own_costing_step{s}_CONSOLIDATED.csv").assign(Year=yr))
own = pd.concat(own)[["Year", "forecaster", "cv_mult", "cost_own", "pct_vs_ANN"]]
own.columns = ["Year", "Forecaster", "Error CV relative to ANN", "Modelled cost (USD)", "Cost vs ANN (%)"]
own.to_csv(f"{OUT}/Forecast_to_cost.csv", index=False)

# ---------- Order book ----------
OB = f"{TR}/orderbook_avla_20261113/outputs"
og = f"{TR}/dm_main_comparators_20261117/audit/orderbook_gain_by_period.json"
if os.path.exists(og): json.dump(json.load(open(og)), open(f"{OUT}/Order_book_gain_by_period.json", "w"), indent=1)
pd.read_csv(f"{OB}/series_and_order_book.csv").to_csv(f"{OUT}/Order_book_series.csv", index=False)

# ---------- Figure 4 data ----------
ef = pd.read_csv(f"{OB}/ensemble_forecasts.csv", parse_dates=["month"])
fin = ef[ef.ob & (ef.config == "tuned") & (ef.seed == 42) & (ef.month >= "2013-09-01")].sort_values("month")
base = ef[(~ef.ob) & (ef.config == "manuscript") & (ef.seed == 42) & (ef.month >= "2013-09-01")].sort_values("month")
pd.DataFrame({"month": fin.month.dt.strftime("%Y-%m"), "delivered_quantity": fin.actual.values,
              "AVLA-ANN + order book (proposed)": fin["AVLA-ANN"].values,
              "AVLA-ANN, base members, no order book": base["AVLA-ANN"].values}).to_csv(f"{OUT}/Figure4a_test_forecasts.csv", index=False)
pd.read_csv(f"{OB}/forward_projection_2015_2016.csv").to_csv(f"{OUT}/Figure4b_projection.csv", index=False)
# ---------- Supplementary Table S3: INCOTERM comparison ----------
inc = json.load(open(f"{TR}/incoterm_feasibility_20261116/outputs/incoterm_feasibility.json"))
json.dump(inc, open(f"{OUT}/TableS3_incoterm.json", "w"), indent=1)
print("written to", OUT)
