"""E1 (audit follow-up, user-approved 2026-11-16 15:52 IST): plan with PSO as the solver instead of the exact grid solver.
Everything else (data, cost model, partition DP, bounded realisation v2, B1/B2, base parameters) is the frozen v2 model.
The partition still uses the exact DP over bundle costs; each bundle's (option, T) is now chosen by PSO (frozen settings).
EOQ_DOMINANT (single fixed option) keeps the exact 1-D solver. Usage: python3 e1_pso_planning.py STEP SEED"""
import os as _os_root
_HA_ROOT = _os_root.environ.get("HYBRID_ANN_ROOT") or _os_root.path.abspath(_os_root.path.join(_os_root.path.dirname(_os_root.path.abspath(__file__)), "..", "..", ".."))  # portable root (build_repo.py)
import sys, json, time, hashlib
sys.path.insert(0, f"{_HA_ROOT}/technical_revision/experiments_v2_20261108T0543Z")
import xlib as X
E, SD, V2 = X.E, X.SD, X.V2
step, seed = int(sys.argv[1]), int(sys.argv[2]); T_END = {2: "2013-08-31", 3: "2014-08-31"}[step]
OUT = f"{_HA_ROOT}/technical_revision/audit_followups_20261116/outputs/e1"
import os; os.makedirs(OUT, exist_ok=True)

class PSOPlanner(V2.EngineV2):
    def solve_exact(self, S, D, opts=None, grid=2000):
        if opts is not None:                       # EOQ_DOMINANT: fixed option, exact 1-D (unchanged)
            return super().solve_exact(S, D, opts=opts, grid=grid)
        self.n_pso = getattr(self, "n_pso", 0) + 1
        return self.solve_pso(S, D, seed=seed)     # frozen PSO settings: 20 particles, 50 iterations

t0 = time.time(); B = SD.build(T_END); p = dict(X.frozen_cases()[0][2])
e = PSOPlanner(B, p); plans = {pol: e.plan(pol) for pol in E.POLICIES}; res, _ = e.run_all(plans)
fails = []
for pol in E.POLICIES:
    s, f = X.check_policy(e, B, plans[pol], res[pol], e.ledger, pol); fails += f
t = {k: float(v.total.sum()) for k, v in res.items()}
dec = [{"policy": pol, "q": q, "bundle": "/".join(map(str, b)), "opt": o, "T_years": T} for pol in E.POLICIES for q, u in enumerate(plans[pol]) for b, o, T in u]
import pandas as pd
pd.DataFrame(dec).to_csv(f"{OUT}/decisions_step{step}_seed{seed}.csv", index=False)
pd.concat([v.assign(policy=k) for k, v in res.items()]).to_csv(f"{OUT}/lanes_step{step}_seed{seed}.csv", index=False)
out = {"step": step, "seed": seed, "n_pso_problems": e.n_pso, "feasibility_failures": len(fails), "totals": t,
       "delta_vs_B1_pct": {k: 100 * (t[k] / t["B1"] - 1) for k in t}, "runtime_s": time.time() - t0,
       "script_sha256": hashlib.sha256(open(__file__, "rb").read()).hexdigest()}
json.dump(out, open(f"{OUT}/result_step{step}_seed{seed}.json", "w"), indent=1)
print(step, seed, round(out["delta_vs_B1_pct"]["CONSOLIDATED"], 4), "fails", len(fails), "problems", e.n_pso, "s", round(out["runtime_s"]))
