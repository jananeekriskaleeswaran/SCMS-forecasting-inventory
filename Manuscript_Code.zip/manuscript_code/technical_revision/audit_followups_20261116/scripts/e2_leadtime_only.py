"""AUDIT DIAGNOSTIC (not part of the frozen model): CONSOLIDATED/INDEPENDENT vs B1 when the safety-stock
review-period term (365*T) is removed, i.e. the accounting of the earlier lane-by-lane quarterly experiment."""
import os as _os_root
_HA_ROOT = _os_root.environ.get("HYBRID_ANN_ROOT") or _os_root.path.abspath(_os_root.path.join(_os_root.path.dirname(_os_root.path.abspath(__file__)), "..", "..", ".."))  # portable root (build_repo.py)
import sys, json
sys.path.insert(0, f"{_HA_ROOT}/technical_revision/experiments_v2_20261108T0543Z")
import xlib as X
E, SD, V2 = X.E, X.SD, X.V2
mode = sys.argv[2]; step = int(sys.argv[1]); T_END = {2: "2013-08-31", 3: "2014-08-31"}[step]
if mode == "leadtime_only":
    orig = E.Engine.sig; E.Engine.sig = lambda self, D, T, Lm, sL: orig(self, D, 0.0 * T, Lm, sL)
B = SD.build(T_END); p = dict(X.frozen_cases()[0][2]); e = V2.EngineV2(B, p)
plans = {pol: e.plan(pol) for pol in E.POLICIES}; res, _ = e.run_all(plans)
t = {k: float(v.total.sum()) for k, v in res.items()}
comp = {k: {c: float(v[c].sum()) for c in E.PARTS} for k, v in res.items()}
out = {"step": step, "mode": mode, "case0": X.frozen_cases()[0][:2], "totals": t, "components": comp, "delta_vs_B1_pct": {k: 100 * (t[k] / t["B1"] - 1) for k in t}, "delta_vs_B2_pct": {k: 100 * (t[k] / t["B2"] - 1) for k in t}}
json.dump(out, open(f"diag_step{step}_{mode}.json", "w"), indent=1, default=str)
import pandas as pd; pd.concat([v.assign(policy=k) for k, v in res.items()]).to_csv(f"diag_lanes_step{step}_{mode}.csv", index=False)
print(json.dumps({k: out[k] for k in ("step", "mode", "case0", "delta_vs_B1_pct")}, default=str))
