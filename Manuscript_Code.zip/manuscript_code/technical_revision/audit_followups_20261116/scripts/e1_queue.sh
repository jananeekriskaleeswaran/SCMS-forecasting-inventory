#!/bin/sh
# Resumable E1 runner: works through the approved matrix (e1_run_matrix.json), skipping pairs that already have a result file
# or are claimed by another worker (lock file). Every attempt is logged with start/end time and exit status in logs/e1_attempts.tsv.
# A lock left without a result after its worker died is an interrupted attempt; it is renamed *.interrupted (kept) before retrying.
# Optional env: ONLY_STEP=2|3 restricts to one period; MAX=n stops after n attempts (keeps each worker under the 2 h job limit).
n=0
H=$(cd "$(dirname "$0")/.." && pwd); cd "$H/scripts"
for pair in "3 42" "2 1" "3 1" "2 2" "3 2" "2 3" "3 3" "2 4" "3 4" "2 5" "3 5" "2 6" "3 6" "2 7" "3 7" "2 8" "3 8" "2 9" "3 9" "2 10" "3 10" "2 42"; do
  set -- $pair; st=$1; sd=$2; res="$H/outputs/e1/result_step${st}_seed${sd}.json"; lock="$H/logs/locks/step${st}_seed${sd}.lock"
  [ -f "$res" ] && continue
  [ -n "$ONLY_STEP" ] && [ "$st" != "$ONLY_STEP" ] && continue
  [ -n "$MAX" ] && [ "$n" -ge "$MAX" ] && break
  mkdir -p "$H/logs/locks"
  if ! mkdir "$lock" 2>/dev/null; then continue; fi
  t0=$(date -u +%FT%TZ); python3 e1_pso_planning.py $st $sd > "$H/logs/e1_step${st}_seed${sd}_$(date -u +%H%M%S).log" 2>&1; rc=$?
  printf "%s\t%s\t%s\t%s\t%s\t%s\n" "$st" "$sd" "$t0" "$(date -u +%FT%TZ)" "$rc" "$WORKER" >> "$H/logs/e1_attempts.tsv"
  rmdir "$lock"; n=$((n+1))
done
