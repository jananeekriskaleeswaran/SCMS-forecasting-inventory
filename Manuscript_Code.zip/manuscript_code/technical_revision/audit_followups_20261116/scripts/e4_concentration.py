"""E4 (audit follow-up): per-country contribution and leave-one-country-out (LOCO) delta for CONSOLIDATED vs B1,
from the frozen R1 lane-level base costs (no model rerun)."""
import os as _os_root
_HA_ROOT = _os_root.environ.get("HYBRID_ANN_ROOT") or _os_root.path.abspath(_os_root.path.join(_os_root.path.dirname(_os_root.path.abspath(__file__)), "..", "..", ".."))  # portable root (build_repo.py)
import json, pandas as pd, numpy as np
R1 = f"{_HA_ROOT}/technical_revision/experiments_v2_20261108T0543Z/results/R1"; OUT = f"{_HA_ROOT}/technical_revision/audit_followups_20261116/outputs/e4"; S = {}
for step, yr in ((2, "2013-14"), (3, "2014-15")):
    L = pd.read_csv(f"{R1}/step{step}/lane_costs_base.csv"); W = L.pivot(index="lane", columns="policy", values="total")
    W["country"] = L[L.policy == "B1"].set_index("lane").country.loc[W.index]
    g = W.groupby("country")[["B1", "CONSOLIDATED", "INDEPENDENT"]].sum(); g["lanes"] = W.groupby("country").size()
    g["saving_usd"] = g.B1 - g.CONSOLIDATED; g["delta_pct"] = 100 * (g.CONSOLIDATED / g.B1 - 1)
    g["share_of_total_saving"] = g.saving_usd / g.saving_usd.sum(); g["share_of_B1_cost"] = g.B1 / g.B1.sum()
    tot = g[["B1", "CONSOLIDATED"]].sum()
    g["LOCO_delta_pct"] = [100 * ((tot.CONSOLIDATED - g.loc[c, "CONSOLIDATED"]) / (tot.B1 - g.loc[c, "B1"]) - 1) for c in g.index]
    g = g.sort_values("saving_usd", ascending=False); g.to_csv(f"{OUT}/country_table_step{step}.csv")
    top3 = g.index[:3].tolist(); t3 = tot - g.loc[top3, ["B1", "CONSOLIDATED"]].sum()
    S[yr] = {"countries": int(len(g)), "countries_cheaper": int((g.saving_usd > 0).sum()), "overall_delta_pct": float(100 * (tot.CONSOLIDATED / tot.B1 - 1)),
             "LOCO_range_pct": [float(g.LOCO_delta_pct.min()), float(g.LOCO_delta_pct.max())], "LOCO_least_favourable_country": g.LOCO_delta_pct.idxmax(),
             "top3": top3, "top3_share_of_saving": float(g.share_of_total_saving.iloc[:3].sum()), "top3_share_of_B1_cost": float(g.share_of_B1_cost.iloc[:3].sum()),
             "delta_without_top3_pct": float(100 * (t3.CONSOLIDATED / t3.B1 - 1))}
json.dump(S, open(f"{OUT}/e4_summary.json", "w"), indent=1); print(json.dumps(S, indent=1))
