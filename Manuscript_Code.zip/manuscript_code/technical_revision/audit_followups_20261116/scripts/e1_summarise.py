"""Build the E1 run-level table from verified outputs only (result_*.json from e1_pso_planning.py and check_*.json from e1_check.py).
Runs in the matrix without both files are reported as NOT COMPLETE with whatever log evidence exists."""
import os as _os_root
_HA_ROOT = _os_root.environ.get("HYBRID_ANN_ROOT") or _os_root.path.abspath(_os_root.path.join(_os_root.path.dirname(_os_root.path.abspath(__file__)), "..", "..", ".."))  # portable root (build_repo.py)
import json, os, hashlib, numpy as np, pandas as pd
H = f"{_HA_ROOT}/technical_revision/audit_followups_20261116"; M = json.load(open(f"{H}/scripts/e1_run_matrix.json"))
eng = f"{_HA_ROOT}/technical_revision/consolidation_v2/engine_v2.py"; eng1 = f"{_HA_ROOT}/technical_revision/consolidation/engine.py"
ver = {"engine_v2_sha256": hashlib.sha256(open(eng, "rb").read()).hexdigest()[:16], "engine_v1_sha256": hashlib.sha256(open(eng1, "rb").read()).hexdigest()[:16]}
rows = []
for st, per in M["periods"].items():
    for sd in M["seeds"]:
        rf, cf = f"{H}/outputs/e1/result_step{st}_seed{sd}.json", f"{H}/outputs/e1_check/check_step{st}_seed{sd}.json"
        r = json.load(open(rf)) if os.path.exists(rf) else None; c = json.load(open(cf)) if os.path.exists(cf) else None
        row = {"period": per.split(" ")[0], "seed": sd, "status": "complete+checked" if r and c else ("complete, not yet checked" if r else "NOT COMPLETE")}
        if r:
            row.update({"pso_problems": r["n_pso_problems"], "objective_evaluations": r["n_pso_problems"] * 1020, "termination": "fixed 50 iterations", "runtime_s": round(r["runtime_s"]),
                        "optimiser_side_feasibility_failures": r["feasibility_failures"], "CONSOLIDATED_vs_B1_pct": r["delta_vs_B1_pct"]["CONSOLIDATED"]})
        if c:
            po = c["plan_objective"]["CONSOLIDATED"]
            row.update({"independent_structure_violations": c["violations_plan_structure"], "independent_check_policy_failures": c["check_policy_failures"],
                        "realised_matches_saved_max_rel": c["realisation_matches_saved_max_rel"], "recon_max_rel_CONSOLIDATED": c["independent_reconstruction_max_rel"]["CONSOLIDATED"],
                        "plan_obj_PSO": po["pso_plan_objective"], "plan_obj_exact": po["exact_plan_objective"], "plan_abs_gap": po["pso_plan_objective"] - po["exact_plan_objective"], "plan_rel_gap": po["rel_gap"],
                        "unit_rel_gap_max": c["rel_gap_units"]["max"], "unit_rel_gap_median": c["rel_gap_units"]["median"], "units_checked": c["units_checked"],
                        "same_decisions_as_exact_CONS": c["share_decisions_identical_to_exact_plan(bundle,option)"]["CONSOLIDATED"],
                        "CONSOLIDATED_vs_B1_pct_recomputed": c["delta_vs_B1"]["CONSOLIDATED"]["delta_vs_B1_pct"], "CI95_low": c["delta_vs_B1"]["CONSOLIDATED"]["cluster_CI95"][0],
                        "CI95_high": c["delta_vs_B1"]["CONSOLIDATED"]["cluster_CI95"][1], "exact_frozen_vs_B1_pct": c["frozen_exact_delta_vs_B1_pct"]["CONSOLIDATED"],
                        "budget_sample_evals": f'{c["budget_sample"]["evaluations_min"]}-{c["budget_sample"]["evaluations_max"]}', "determinism_sample": f'{c["budget_sample"]["deterministic_resolve_matches"]}/{c["budget_sample"]["n"]}'})
        rows.append(row)
T = pd.DataFrame(rows); T.to_csv(f"{H}/outputs/E1_run_table.csv", index=False)
S = []
for per, g in T[T.status == "complete+checked"].groupby("period"):
    S.append({"period": per, "runs_checked": len(g), "feasible_runs": int(((g.independent_structure_violations == 0) & (g.independent_check_policy_failures == 0)).sum()),
              "plan_rel_gap_mean": g.plan_rel_gap.mean(), "plan_rel_gap_median": g.plan_rel_gap.median(), "plan_rel_gap_sd": g.plan_rel_gap.std(ddof=1) if len(g) > 1 else np.nan,
              "plan_rel_gap_worst": g.plan_rel_gap.max(), "unit_rel_gap_worst": g.unit_rel_gap_max.max(), "saving_pct_min": g.CONSOLIDATED_vs_B1_pct_recomputed.min(),
              "saving_pct_max": g.CONSOLIDATED_vs_B1_pct_recomputed.max(), "exact_frozen_pct": g.exact_frozen_vs_B1_pct.iloc[0], "runtime_s_median": g.runtime_s.median()})
pd.DataFrame(S).to_csv(f"{H}/outputs/E1_summary_by_period.csv", index=False)
json.dump({"versions": ver, "matrix": M}, open(f"{H}/outputs/E1_versions.json", "w"), indent=1)
print(T[["period", "seed", "status"]].groupby(["period", "status"]).size()); print(pd.DataFrame(S).T)
