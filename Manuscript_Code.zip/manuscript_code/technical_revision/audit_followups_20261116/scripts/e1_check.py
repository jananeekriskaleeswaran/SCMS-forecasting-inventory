"""E1 independent checker (audit follow-up). v2: EOQ_DOMINANT checked against its q = 0 planning demand (v1 of this checker wrongly used each quarter's demand; v1 output kept as check_step2_seed42_checker_v1.json). Usage: python3 e1_check.py STEP SEED
Works only from the saved outputs of e1_pso_planning.py (decisions_*.csv, lanes_*.csv, result_*.json). It does not call solve_pso
except in check (F) below, which re-calls it on a sample to verify the evaluation budget and determinism.

(A) Plan structure, recomputed with this file's own formulas (not Engine.t_bounds / Engine.options):
    partition covers every active lane (D_plan > 0) exactly once; inactive lanes only as carried-over singletons;
    each multi-lane unit is a permitted candidate (training-ASN bundles for CONSOLIDATED, observed sets for OBSERVED_SET);
    option is in the intersection of members' option sets (EOQ_DOMINANT: the dominant option);
    T within [max_i max(1, Qmin_i)/D_i, min_i min(Qmax_i, D_i*cap/12)/D_i], and for bundles T*sum(D_i w_i) <= WCAP(o, country).
(B) Planning objective of every active unit recomputed with this file's own cost formula (freight from the model's frozen
    freight evaluator, which is a model input), and compared with Engine.bundle_cost.
(C) Reference: Engine.solve_exact (2,000-point log grid + bounded refinement per option; grid-certified, not proven global)
    for the same unit and planning demand -> per-unit absolute and relative gap.
(D) Plan-level planning objective (sum over quarters and active units) vs the frozen exact-solver plan (R1 base decisions),
    each costed with the same formula in (B); share of identical decisions.
(E) Realisation: the saved decisions are re-realised with the frozen v2 engine; totals must equal the saved lane costs;
    xlib.check_policy runs the hard-constraint checks (H1-H4, conservation) and the independent cost reconstruction
    (consolidation_v2/independent.py, no engine functions); delta vs B1 with the frozen country-cluster bootstrap (E.boot).
(F) Budget and determinism on a sample of 25 CONSOLIDATED problems: counts objective calls inside solve_pso and checks
    that the re-solved (option, T) equals the saved decision."""
import os as _os_root
_HA_ROOT = _os_root.environ.get("HYBRID_ANN_ROOT") or _os_root.path.abspath(_os_root.path.join(_os_root.path.dirname(_os_root.path.abspath(__file__)), "..", "..", ".."))  # portable root (build_repo.py)
import sys, json, time, hashlib, math, numpy as np, pandas as pd
sys.path.insert(0, f"{_HA_ROOT}/technical_revision/experiments_v2_20261108T0543Z")
import xlib as X
E, SD, V2 = X.E, X.SD, X.V2
step, seed = int(sys.argv[1]), int(sys.argv[2]); T_END = {2: "2013-08-31", 3: "2014-08-31"}[step]
D_ = f"{_HA_ROOT}/technical_revision/audit_followups_20261116/outputs/e1"; OUT = f"{_HA_ROOT}/technical_revision/audit_followups_20261116/outputs/e1_check"
import os; os.makedirs(OUT, exist_ok=True)
TOL_BOUND = 1e-9; TOL_OBJ = 1e-9; TOL_TOTAL = 1e-9
t0 = time.time(); B = SD.build(T_END); p = dict(X.frozen_cases()[0][2]); e = V2.EngineV2(B, p)
h, K, z, cap = e.h, e.K, e.z, e.cap

def parse(df):
    P = {pol: [[] for _ in range(4)] for pol in E.POLICIES}
    for r in df.itertuples():
        P[r.policy][int(r.q)].append((tuple(int(x) for x in str(r.bundle).split("/")), r.opt, float(r.T_years)))
    return P

def bounds(S, D, o):
    lo = max(max(1.0, B.lanes[i]["qmin_obs"]) / D[i] for i in S)
    hi = min(min(B.lanes[i]["qmax_obs"], D[i] * cap / 12.0) / D[i] for i in S)
    if len(S) > 1:
        wc = B.WCAP.get((o, B.lanes[S[0]]["country"]), B.WCAP_OPT.get(o, np.inf)); hi = min(hi, wc / sum(D[i] * B.lanes[i]["w"] for i in S))
    elif lo > hi: lo = hi                                  # single-lane rule: T fixed at hi when the interval is empty
    return lo, hi

def cost(S, o, T, D):
    W = T * sum(D[i] * B.lanes[i]["w"] for i in S); F = float(e.frt(np.array([W]), o, B.lanes[S[0]]["country"])[0]); Lm, sL = B.LT[o]; c = 0.0
    for i in S:
        sm = e.cv * D[i] / 12.0; sig = math.sqrt(((365.0 * T + Lm) / 30.0) * sm ** 2 + (D[i] / 12.0) ** 2 * (sL / 30.0) ** 2)
        c += h * B.lanes[i]["c"] * (D[i] * T / 2.0 + z * sig + D[i] * Lm / 365.0)
    return (K + F) / T + c

dec = pd.read_csv(f"{D_}/decisions_step{step}_seed{seed}.csv"); P = parse(dec)
ref_dec = pd.read_csv(f"{_HA_ROOT}/technical_revision/experiments_v2_20261108T0543Z/results/R1/step{step}/decisions_base_.csv.gz"); RP = parse(ref_dec)
allowed = {"CONSOLIDATED": set(map(tuple, B.bundles)), "OBSERVED_SET": set(map(tuple, B.obs_sets)), "INDEPENDENT": set(), "EOQ_DOMINANT": set()}
viol = []; unit_rows = []; plan_obj = {}; same = {}
for pol in E.POLICIES:
    tot_p = tot_r = 0.0; n_same = n_all = 0; prev = {}
    for q in range(4):
        qd = 0 if pol == "EOQ_DOMINANT" else q          # EOQ_DOMINANT is planned once at q = 0 and kept all year (Engine.plan)
        D = {i: B.DPLAN[i][qd] for i in range(len(B.lanes))}; act = {i for i in D if D[i] > 0}
        units = P[pol][q]; members = [i for b, o, T in units for i in b]
        if len(members) != len(set(members)): viol.append((pol, q, "lane in two units"))
        cov = {i for b, o, T in units if all(D[j] > 0 for j in b) for i in b}
        if cov != act: viol.append((pol, q, "active lanes not covered exactly", len(act ^ cov)))
        for b, o, T in units:
            if not all(D[i] > 0 for i in b):                   # carried-over plan for a lane with no trailing demand
                if len(b) != 1 or prev.get(b[0]) != (o, T) and pol != "EOQ_DOMINANT": viol.append((pol, q, "bad carry-over", b))
                continue
            if len(b) > 1 and b not in allowed[pol]: viol.append((pol, q, "bundle not permitted", b))
            elig = {B.lanes[b[0]]["dom_opt"]} if pol == "EOQ_DOMINANT" else set.intersection(*[set(B.lanes[i]["opts"]) for i in b])
            if o not in elig: viol.append((pol, q, "option not eligible", b, o))
            lo, hi = bounds(b, D, o)
            if T < lo * (1 - TOL_BOUND) or T > hi * (1 + TOL_BOUND): viol.append((pol, q, "T out of bounds", b, o, T, lo, hi))
            c_ind = cost(b, o, T, D); c_eng = float(e.bundle_cost(b, o, T, D)[0])
            if abs(c_ind / c_eng - 1) > TOL_OBJ: viol.append((pol, q, "objective mismatch", b, c_ind, c_eng))
            if pol == "EOQ_DOMINANT": r = e.solve_exact(b, D, opts=[B.lanes[b[0]]["dom_opt"]])
            else: r = e.solve_exact(b, D)
            unit_rows.append({"policy": pol, "q": q, "bundle": "/".join(map(str, b)), "size": len(b), "opt": o, "T": T, "obj_pso": c_ind, "obj_ref": r[0],
                              "abs_gap": c_ind - r[0], "rel_gap": c_ind / r[0] - 1, "ref_opt": r[1], "ref_T": r[2], "same_option_as_ref": o == r[1]})
            tot_p += c_ind
        for b, o, T in units:
            for i in b: prev[i] = (o, T)
        for b, o, T in RP[pol][q]:
            if all(D[i] > 0 for i in b): tot_r += cost(b, o, T, D)
        ks = {(b, o) for b, o, T in units}; kr = {(b, o) for b, o, T in RP[pol][q]}; n_same += len(ks & kr); n_all += len(kr)
    plan_obj[pol] = {"pso_plan_objective": tot_p, "exact_plan_objective": tot_r, "rel_gap": tot_p / tot_r - 1}; same[pol] = n_same / n_all
U = pd.DataFrame(unit_rows); U.to_csv(f"{OUT}/units_step{step}_seed{seed}.csv", index=False)
# (E) realisation
e2 = V2.EngineV2(B, p); res, _ = e2.run_all({pol: P[pol] for pol in E.POLICIES}); saved = pd.read_csv(f"{D_}/lanes_step{step}_seed{seed}.csv")
fails = []; recon = {}
for pol in E.POLICIES:
    s, f = X.check_policy(e2, B, P[pol], res[pol], e2.ledger, pol); fails += f; recon[pol] = s["recon_max_rel"]
mx = 0.0
for pol in list(E.POLICIES) + ["B1", "B2"]:
    a = res[pol].set_index("lane").total; b = saved[saved.policy == pol].set_index("lane").total.loc[a.index]; mx = max(mx, float((abs(a - b) / b.abs().clip(lower=1)).max()))
W = pd.concat([v.assign(policy=k) for k, v in res.items()]).pivot(index="lane", columns="policy", values="total")
cty = res["B1"].set_index("lane").country.loc[W.index].values; t = W.sum()
delta = {pol: {"delta_vs_B1_pct": float(100 * (t[pol] / t.B1 - 1)), "cluster_CI95": [float(x) for x in E.boot(W[pol], W["B1"], cty)]} for pol in E.POLICIES}
fz = json.load(open(f"{_HA_ROOT}/technical_revision/experiments_v2_20261108T0543Z/logs/R1_step{step}_log.json"))["base"]
# (F) budget + determinism sample
calls = {"n": 0}; orig = e.bundle_cost
def counted(*a, **k): calls["n"] += 1; return orig(*a, **k)
rng = np.random.default_rng(0); cons = [(q, b, o, T) for q in range(4) for b, o, T in P["CONSOLIDATED"][q] if all(B.DPLAN[i][q] > 0 for i in b)]
samp = [cons[j] for j in rng.choice(len(cons), min(25, len(cons)), replace=False)]; budget = []; det = 0
e.bundle_cost = counted
for q, b, o, T in samp:
    D = {i: B.DPLAN[i][q] for i in range(len(B.lanes))}; calls["n"] = 0
    opts = [x for x in e.options(b) if e.t_bounds(b, D, x) is not None]
    r = e.solve_pso(b, D, seed=seed); budget.append(calls["n"] - 2 * len(opts) * 0)   # t_bounds does not call bundle_cost
    det += int(r[1] == o and abs(r[2] / T - 1) < 1e-12)
e.bundle_cost = orig
R = {"step": step, "seed": seed, "violations_plan_structure": len(viol), "violations_examples": [list(map(str, v)) for v in viol[:10]],
     "units_checked": int(len(U)), "rel_gap_units": {"mean": float(U.rel_gap.mean()), "median": float(U.rel_gap.median()), "max": float(U.rel_gap.max()), "min": float(U.rel_gap.min()),
     "share_le_1e-6": float((U.rel_gap <= 1e-6).mean()), "share_le_1e-3": float((U.rel_gap <= 1e-3).mean())}, "share_same_option_as_reference": float(U.same_option_as_ref.mean()),
     "plan_objective": plan_obj, "share_decisions_identical_to_exact_plan(bundle,option)": same,
     "realisation_matches_saved_max_rel": mx, "check_policy_failures": len(fails), "independent_reconstruction_max_rel": recon,
     "delta_vs_B1": delta, "frozen_exact_delta_vs_B1_pct": {pol: fz["delta_vs_B1_pct"][pol] for pol in E.POLICIES},
     "budget_sample": {"n": len(budget), "evaluations_min": int(min(budget)), "evaluations_max": int(max(budget)), "deterministic_resolve_matches": det},
     "tolerances": {"bounds_rel": TOL_BOUND, "objective_rel": TOL_OBJ, "check_policy_REL": X.REL if hasattr(X, "REL") else "see xlib"},
     "inputs_sha256": {f: hashlib.sha256(open(f"{D_}/{f}", "rb").read()).hexdigest() for f in (f"decisions_step{step}_seed{seed}.csv", f"lanes_step{step}_seed{seed}.csv", f"result_step{step}_seed{seed}.json")},
     "checker_sha256": hashlib.sha256(open(__file__, "rb").read()).hexdigest(), "runtime_s": time.time() - t0}
json.dump(R, open(f"{OUT}/check_step{step}_seed{seed}.json", "w"), indent=1, default=str)
print(json.dumps({k: R[k] for k in ("step", "seed", "violations_plan_structure", "units_checked", "rel_gap_units", "share_same_option_as_reference", "realisation_matches_saved_max_rel", "check_policy_failures", "budget_sample")}, default=str))
print({p: (round(v["delta_vs_B1_pct"], 4), [round(x, 2) for x in v["cluster_CI95"]], round(R["frozen_exact_delta_vs_B1_pct"][p], 4)) for p, v in delta.items()})
print({p: round(v["rel_gap"] * 100, 5) for p, v in plan_obj.items()}, same)
