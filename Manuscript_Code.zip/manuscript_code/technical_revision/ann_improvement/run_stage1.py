"""Stage 1 forecasts for a set of origins ('val', 'test', or 'warm'). Singles via checkpointed curves / ES; combos via generic config."""
import os, sys, json, time, numpy as np, pandas as pd
from joblib import Parallel, delayed
import ann
HERE = os.path.dirname(os.path.abspath(__file__)); O = os.path.join(HERE, "outputs"); SEEDS = [42, 1, 2, 3, 4, 5]
PERIODS = {"warm": ("2010-09-01", "2011-08-01"), "val": ("2011-09-01", "2013-08-01"), "test": ("2013-09-01", "2015-08-01")}
CURVES = {"lr1e-4": {"lr": 1e-4}, "lr3e-4": {"lr": 3e-4}, "lr1e-3": {}, "lr3e-3": {"lr": 3e-3}, "F1curve": {"scale_y": True}}
FROM_CURVE = {"B0": ("lr1e-3", 800), "A1": ("lr1e-3", 1500), "A2": ("lr1e-3", 3000), "B1": ("lr1e-4", 800), "B2": ("lr3e-4", 800),
              "B3": ("lr3e-3", 800), "F1": ("F1curve", 800)}

def origins(L, per):
    a, b = map(pd.Timestamp, PERIODS[per]); return [i for i, m in enumerate(L.index) if a <= m <= b]

def job_curve(L, t, s, name):
    t0 = time.time(); r = ann.run_ckpts(L, t, s, ann.cfg_of(CURVES[name]), ann.CKPTS); return ("curve", name, s, t, r, time.time() - t0)
def job_single(L, t, s, cid):
    t0 = time.time(); return ("single", cid, s, t, ann.forecast(L, t, s, ann.cfg_of(ann.SINGLES[cid])), time.time() - t0)
def job_es(L, t, s):
    t0 = time.time(); r = ann.run_es(L, t, s, ann.cfg_of({})); r.pop("holdout_curve"); return ("es", "ES", s, t, r, time.time() - t0)
def job_cfg(L, t, s, cid, changes):
    t0 = time.time(); return ("single", cid, s, t, ann.forecast(L, t, s, ann.cfg_of(changes)), time.time() - t0)

if __name__ == "__main__":
    per, what = sys.argv[1], sys.argv[2]          # what: singles | combos | selected
    L = ann.fe.monthly_series(); T = origins(L, per); jobs = []
    if what == "singles":
        jobs += [delayed(job_curve)(L, t, s, n) for n in CURVES for s in SEEDS for t in T]
        jobs += [delayed(job_single)(L, t, s, c) for c in ("C1", "C2", "D1", "D2", "D3", "D4") for s in SEEDS for t in T]
        jobs += [delayed(job_es)(L, t, s) for s in SEEDS for t in T]
    else:
        spec = json.load(open(os.path.join(HERE, "logs", "combos.json" if what == "combos" else "selection_stage1.json")))
        cands = spec["combos"] if what == "combos" else {spec["selected"]: spec["selected_changes"]}
        jobs += [delayed(job_cfg)(L, t, s, cid, ch) for cid, ch in cands.items() for s in SEEDS for t in T]
    res = Parallel(n_jobs=2, batch_size=2)(jobs); rows, curves, es = [], [], []
    for kind, name, s, t, r, secs in res:
        base = {"seed": s, "t": t, "month": L.index[t], "actual": L.iloc[t], "naive": L.iloc[t - 1], "period": per}
        if kind == "curve":
            for e, (p, loss) in r.items(): curves.append({**base, "curve": name, "epoch": e, "pred": p, "train_loss": loss, "secs_total": secs})
            for cid, (cn, ep) in FROM_CURVE.items():
                if cn == name: rows.append({**base, "candidate": cid, "pred": r[ep][0], "train_loss_final": r[ep][1], "secs": secs * ep / 3000})
        elif kind == "es":
            rows.append({**base, "candidate": "A3", "pred": r["restore"], "best_epoch": r["best_epoch"], "stopped_at": r["stopped_at"], "secs": secs})
            rows.append({**base, "candidate": "A4", "pred": r["refit"], "best_epoch": r["best_epoch"], "stopped_at": r["stopped_at"], "secs": secs})
        else: rows.append({**base, "candidate": name, "pred": r, "secs": secs})
    tag = f"{per}_{what}"; pd.DataFrame(rows).to_csv(f"{O}/forecasts_{tag}.csv", index=False)
    if curves: pd.DataFrame(curves).to_csv(f"{O}/curves_{tag}.csv", index=False)
    print("done", tag, len(rows))
