"""ANN training variants for Stage 1 (SPEC_FROZEN.md). Features and X-scaling identical to Option A (fe.py)."""
import os as _os_root
_HA_ROOT = _os_root.environ.get("HYBRID_ANN_ROOT") or _os_root.path.abspath(_os_root.path.join(_os_root.path.dirname(_os_root.path.abspath(__file__)), "..", ".."))  # portable root (build_repo.py)
import sys, copy, warnings, numpy as np, pandas as pd
sys.path.insert(0, f"{_HA_ROOT}/technical_revision/feature_residual_experiments"); import fe
from sklearn.neural_network import MLPRegressor
from sklearn.preprocessing import MinMaxScaler
BASE = dict(hidden=(128, 64), lr=1e-3, alpha=1e-4, epochs=800, es=None, scale_y=False)
CKPTS = (50, 100, 200, 400, 600, 800, 1000, 1500, 2000, 2500, 3000)
SINGLES = {"B0": {}, "A1": {"epochs": 1500}, "A2": {"epochs": 3000}, "A3": {"es": "restore"}, "A4": {"es": "refit"},
           "B1": {"lr": 1e-4}, "B2": {"lr": 3e-4}, "B3": {"lr": 3e-3}, "C1": {"hidden": (64, 32)}, "C2": {"hidden": (32, 16)},
           "D1": {"alpha": 1e-3}, "D2": {"alpha": 1e-2}, "D3": {"alpha": 1e-1}, "D4": {"alpha": 1.0}, "F1": {"scale_y": True}}
FACTOR = {"B0": None, "A1": "budget", "A2": "budget", "A3": "budget", "A4": "budget", "B1": "lr", "B2": "lr", "B3": "lr",
          "C1": "arch", "C2": "arch", "D1": "alpha", "D2": "alpha", "D3": "alpha", "D4": "alpha", "F1": "target"}
def cfg_of(changes): c = dict(BASE); c.update(changes); return c

def prep(L, t, scale_y):
    cols, r0 = fe.SETS["F0"]; Lp = L.iloc[:t + 1].copy(); Lp.iloc[-1] = np.nan
    F = fe.features(Lp)[cols]; X, y = F.iloc[r0:t].values, Lp.iloc[r0:t].values; xt = F.iloc[[t]].values
    sx = MinMaxScaler().fit(X); X, xt = sx.transform(X), sx.transform(xt)
    sy = MinMaxScaler().fit(y.reshape(-1, 1)) if scale_y else None
    ys = sy.transform(y.reshape(-1, 1)).ravel() if scale_y else y
    inv = (lambda p: float(sy.inverse_transform([[p]])[0, 0])) if scale_y else float
    return X, ys, xt, inv, sx

def _mlp(c, seed): return MLPRegressor(hidden_layer_sizes=c["hidden"], learning_rate_init=c["lr"], alpha=c["alpha"], random_state=seed)

def run_ckpts(L, t, seed, c, ckpts):
    """Train epoch by epoch (== fit(max_iter=k)); return forecast and training loss at each checkpoint."""
    X, y, xt, inv, _ = prep(L, t, c["scale_y"]); m = _mlp(c, seed); out = {}
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        for e in range(1, max(ckpts) + 1):
            m.partial_fit(X, y)
            if e in ckpts: out[e] = (inv(m.predict(xt)[0]), float(m.loss_curve_[-1]))
    return out

def run_es(L, t, seed, c, holdout=12, max_epochs=3000, patience=200):
    """Early stopping on the last `holdout` months of the training window (chronological). Returns restore and refit forecasts."""
    X, y, xt, inv, _ = prep(L, t, c["scale_y"]); Xa, ya, Xh, yh = X[:-holdout], y[:-holdout], X[-holdout:], y[-holdout:]
    m = _mlp(c, seed); best, best_e, state, hist = np.inf, 0, None, []
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        for e in range(1, max_epochs + 1):
            m.partial_fit(Xa, ya); h = float(np.mean((yh - m.predict(Xh)) ** 2)); hist.append(h)
            if h < best: best, best_e, state = h, e, (copy.deepcopy(m.coefs_), copy.deepcopy(m.intercepts_))
            elif e - best_e >= patience: break
        m.coefs_, m.intercepts_ = state; p_restore = inv(m.predict(xt)[0])
        r = _mlp(c, seed)
        for _ in range(best_e): r.partial_fit(X, y)
        p_refit = inv(r.predict(xt)[0])
    return {"restore": p_restore, "refit": p_refit, "best_epoch": best_e, "stopped_at": len(hist), "holdout_curve": hist}

def forecast(L, t, seed, c):
    if c["es"] is None: return run_ckpts(L, t, seed, c, (c["epochs"],))[c["epochs"]][0]
    return run_es(L, t, seed, c)[c["es"]]
