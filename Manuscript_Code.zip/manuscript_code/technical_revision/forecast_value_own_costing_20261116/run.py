"""Value of forecast accuracy through safety stock (user approval 2026-11-16 13:13 IST).
(A) Own costing: each forecaster's own out-of-sample forecast-error CV (24 months before the planning date) sets safety stock in planning AND
    evaluation (existing r2.job 'own' mode). Adds the frozen forecaster (AVLA-ANN + order book) and re-runs ANN as a reproduction check.
    The 10 earlier forecasters are read from the saved R2 results (not re-run).
(B) Service-level calibration (no fitting): does each forecaster's own error estimate deliver the model's 95% target (z = 1.645)?
    Month t of the planning year is covered if actual_t <= forecast_t + 1.645 * RMSE of that forecaster over the 24 months before the
    planning date (the same window that sets its CV). Aggregate monthly series only; the cost model applies the buffer at lane level."""
import os as _os_root
_HA_ROOT = _os_root.environ.get("HYBRID_ANN_ROOT") or _os_root.path.abspath(_os_root.path.join(_os_root.path.dirname(_os_root.path.abspath(__file__)), "..", ".."))  # portable root (build_repo.py)
import os, sys, json, time, hashlib, warnings, numpy as np, pandas as pd
from scipy import stats
warnings.filterwarnings("ignore")
HERE = os.path.dirname(os.path.abspath(__file__)); OUT = f"{HERE}/outputs"; os.makedirs(OUT, exist_ok=True)
TR = f"{_HA_ROOT}/technical_revision"; sys.path.insert(0, f"{TR}/experiments_v2_20261108T0543Z")
import xlib as X
import r2 as R2
E, SD = X.E, X.SD
FC = pd.read_csv(f"{TR}/reviewer_tests/forecast_benchmark/outputs/forecasts_all.csv", parse_dates=["month"])
OB = pd.read_csv(f"{TR}/orderbook_avla_20261113/outputs/ensemble_forecasts.csv", parse_dates=["month"]); OB = OB[OB.ob & (OB.config == "tuned") & (OB.seed == 42)]
SERIES = {k: FC[(FC.model == m) & (FC.seed == 42)].set_index("month").sort_index()[["actual", "pred"]] for k, m in R2.FORECASTERS.items()}
SERIES["AVLA-ANN + order book"] = OB.set_index("month").sort_index().rename(columns={"AVLA-ANN": "pred"})[["actual", "pred"]]
REF = {2: pd.read_csv(f"{TR}/experiments_v2_20261108T0543Z/results/R2/step2_forecaster_costs.csv"), 3: pd.read_csv(f"{TR}/experiments_v2_20261108T0543Z/results/R2/step3_forecaster_costs.csv")}
YEARS = {2: ("2013-08-31", "2013-09-01", "2014-08-01"), 3: ("2014-08-31", "2014-09-01", "2015-08-01")}

def prior(s, T_END):
    T = pd.Timestamp(T_END); f = s[(s.index > T - pd.DateOffset(months=24)) & (s.index <= T)]; assert len(f) == 24
    e = f.actual - f.pred; rm = float(np.sqrt(np.mean(e ** 2))); return rm, rm / float(f.actual.mean())

RES = {"A_own_costing": {}, "B_service_level": {}}; T0 = time.time()
# ---------- (B) calibration first (cheap) ----------
rows = []
for step, (T_END, a, b) in YEARS.items():
    for k, s in SERIES.items():
        rm, cv = prior(s, T_END); y = s.loc[a:b]; assert len(y) == 12
        cov = float((y.actual <= y.pred + 1.645 * rm).mean()); zc = float(np.mean((y.actual - y.pred) / rm))
        rows.append({"planning_year": f"{a[:7]}..{b[:7]}", "forecaster": k, "prior_RMSE": rm, "CV": cv, "coverage_95pct_target": cov, "months": 12,
                     "mean_standardised_error": zc, "max_standardised_error": float(np.max((y.actual - y.pred) / rm))})
SL = pd.DataFrame(rows); SL.to_csv(f"{OUT}/service_level_calibration.csv", index=False)
pool = SL.groupby("forecaster").apply(lambda g: pd.Series({"coverage_pooled_24m": float(np.average(g.coverage_95pct_target, weights=g.months)), "CV_mean": g.CV.mean()}))
pool["binomial_p_vs_0.95"] = [float(stats.binomtest(int(round(c * 24)), 24, 0.95).pvalue) for c in pool.coverage_pooled_24m]
pool.to_csv(f"{OUT}/service_level_pooled.csv"); RES["B_service_level"] = {"by_year": SL.round(4).to_dict("records"), "pooled": pool.round(4).reset_index().to_dict("records"),
    "spearman_CV_vs_coverage_pooled": float(stats.spearmanr(pool.CV_mean, pool.coverage_pooled_24m)[0])}
print("B done", round(time.time() - T0), flush=True)
# ---------- (A) own costing for the frozen forecaster ----------
for step, (T_END, a, b) in YEARS.items():
    B = SD.build(T_END); R2.B = B; cv_ann = prior(SERIES["ANN"], T_END)[1]; assert abs(cv_ann - B.CV) <= 1e-12 * B.CV
    cvn = prior(SERIES["AVLA-ANN + order book"], T_END)[1]
    RA = {lab: R2.job((lab, m, False)) for lab, m in (("ANN", 1.0), ("AVLA-ANN + order book", cvn / B.CV))}
    assert not any(RA[k]["fails"] for k in RA)
    ref = REF[step]; ref = ref[~ref.forecaster.str.contains("oracle")]; out = {}
    for p in R2.POLS:
        own = {lab: float(pd.Series(RA[lab]["own"][p]["total"]).sum()) for lab in RA}; b1own = {lab: float(pd.Series(RA[lab]["own"]["B1"]["total"]).sum()) for lab in RA}
        r = ref[ref.policy == p].set_index("forecaster"); ann_saved = float(r.loc["ANN", "cost_own"])
        tbl = [{"forecaster": f, "cv_mult": float(r.loc[f, "cv_mult"]), "cost_own": float(r.loc[f, "cost_own"]), "pct_vs_ANN": float(100 * (r.loc[f, "cost_own"] / ann_saved - 1))} for f in r.index]
        tbl.append({"forecaster": "AVLA-ANN + order book", "cv_mult": cvn / B.CV, "cost_own": own["AVLA-ANN + order book"], "pct_vs_ANN": float(100 * (own["AVLA-ANN + order book"] / own["ANN"] - 1))})
        Pn, Pa = pd.Series(RA["AVLA-ANN + order book"]["own"][p]["total"]).sort_index(), pd.Series(RA["ANN"]["own"][p]["total"]).sort_index()
        cty = pd.Series({i: l["country"] for i, l in enumerate(B.lanes)}).loc[Pn.index].values
        T = pd.DataFrame(tbl).sort_values("cv_mult")
        out[p] = {"ANN_own_cost_reproduces_saved_R2": bool(abs(own["ANN"] - ann_saved) <= 1e-6 * ann_saved), "table": T.round(5).to_dict("records"),
                  "frozen_vs_ANN_pct": float(100 * (own["AVLA-ANN + order book"] / own["ANN"] - 1)), "frozen_vs_ANN_CI95": E.boot(Pn, Pa, cty),
                  "frozen_delta_vs_Observed_pct_own": float(100 * (own["AVLA-ANN + order book"] / b1own["AVLA-ANN + order book"] - 1)),
                  "spearman_cv_mult_vs_cost_own_11": float(stats.spearmanr(T.cv_mult, T.cost_own)[0]),
                  "safety_component_frozen_vs_ANN_usd": float(pd.Series(RA["AVLA-ANN + order book"]["own"][p]["safety"]).sum() - pd.Series(RA["ANN"]["own"][p]["safety"]).sum())}
        T.to_csv(f"{OUT}/own_costing_step{step}_{p}.csv", index=False)
    RES["A_own_costing"][f"step{step}"] = out; print(step, "A done", round(time.time() - T0), flush=True)
RES["code_sha256"] = {f: hashlib.sha256(open(p, "rb").read()).hexdigest() for f, p in (("run.py", __file__), ("r2.py", f"{TR}/experiments_v2_20261108T0543Z/r2.py"))}
RES["runtime_s"] = time.time() - T0; json.dump(RES, open(f"{OUT}/results.json", "w"), indent=1, default=str)
