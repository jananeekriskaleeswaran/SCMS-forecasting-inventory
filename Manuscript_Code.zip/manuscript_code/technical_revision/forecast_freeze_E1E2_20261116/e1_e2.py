"""E1 (diagnostics) and E2 (corrected reporting table) for the demand-forecasting component. No model fitting; no selection.
Inputs: reviewer_tests/forecast_benchmark/outputs/forecasts_all.csv (Table F1 forecasts, 18 models) and
orderbook_avla_20261113/outputs/ensemble_forecasts.csv (pre-declared order-book extension). MA(k) computed from the series.
Diagnostic tests on the series use only data up to Aug-2013 (before the test window)."""
import os as _os_root
_HA_ROOT = _os_root.environ.get("HYBRID_ANN_ROOT") or _os_root.path.abspath(_os_root.path.join(_os_root.path.dirname(_os_root.path.abspath(__file__)), "..", ".."))  # portable root (build_repo.py)
import os, sys, json, hashlib, warnings, numpy as np, pandas as pd
from scipy import stats
from statsmodels.stats.diagnostic import acorr_ljungbox, het_breuschpagan
from statsmodels.tsa.stattools import adfuller, kpss
warnings.filterwarnings("ignore")
HERE = os.path.dirname(os.path.abspath(__file__)); OUT = f"{HERE}/outputs"; os.makedirs(OUT, exist_ok=True)
TR = f"{_HA_ROOT}/technical_revision"; sys.path.insert(0, f"{_HA_ROOT}/research_comparison/track_B_fair_benchmark")
from preprocessing import monthly_series
SRC_F1 = f"{TR}/reviewer_tests/forecast_benchmark/outputs/forecasts_all.csv"; SRC_OB = f"{TR}/orderbook_avla_20261113/outputs/ensemble_forecasts.csv"
F1T = f"{TR}/revision_evidence_package_20261108/05_tables/Table_F1_forecast_benchmark_test.csv"
y = monthly_series(); WIN = {"validation": ("2011-09-01", "2013-08-01"), "test": ("2013-09-01", "2015-08-01")}
scale = float(np.mean(np.abs(np.diff(y.loc[:"2013-08-01"].values))))          # MASE scale exactly as bench.py (in-sample naive MAE before Sep-2013)
naive, snaive, ma12 = y.shift(1), y.shift(12), y.shift(1).rolling(12).mean()
hm = {s: pd.Series({t: y[(y.index >= s) & (y.index < t)].mean() for t in y.index[24:]}) for s in ("2007-01-01", "2009-01-01")}

# ---------- assemble forecasts (seed 42 primary; all seeds kept) ----------
f = pd.read_csv(SRC_F1, parse_dates=["month"])
LAB = {"ANN": "ANN (fixed manuscript configuration, MLP 128-64)", "AVLA-ANN (paper ensemble)": "AVLA-ANN (corrected, paper members)"}
rows = [pd.DataFrame({"model": LAB.get(m, m), "group": "Benchmark (Table F1)", "seed": s, "month": x.month, "pred": x.pred.values}) for (m, s), x in f.groupby(["model", "seed"])]
ob = pd.read_csv(SRC_OB, parse_dates=["month"]); ob = ob[ob.ob & (ob.config == "tuned")]
for col, name in (("AVLA-ANN", "AVLA-ANN + order book (pre-declared extension)"), ("ANN", "ANN + order book (member of extension)"), ("Equal weights", "Equal weights + order book")):
    rows += [pd.DataFrame({"model": name, "group": "Order-book extension (selected on validation)", "seed": s, "month": x.month, "pred": x[col].values}) for s, x in ob.groupby("seed")]
for k in (9, 12):
    mm = y.shift(1).rolling(k).mean(); idx = y.loc["2011-09-01":"2015-08-01"].index
    rows.append(pd.DataFrame({"model": f"MA({k})", "group": "Simple baseline (window 9 chosen on validation; 12 conventional)", "seed": 42, "month": idx, "pred": mm.loc[idx].values}))
P = pd.concat(rows, ignore_index=True); P["actual"] = y.loc[P.month].values

def met(x):
    a, p, m = x.actual.values, x.pred.values, pd.DatetimeIndex(x.month); e = a - p; rm = float(np.sqrt(np.mean(e ** 2)))
    sk = lambda ref: 1 - rm / float(np.sqrt(np.mean((a - ref.loc[m].values) ** 2)))
    return {"n": len(e), "RMSE": rm, "MAE": float(np.mean(np.abs(e))), "MASE": float(np.mean(np.abs(e)) / scale), "MAPE %": float(100 * np.mean(np.abs(e / a))), "Bias (mean actual - forecast)": float(e.mean()),
            "R2 conventional (vs window mean)": float(1 - np.sum(e ** 2) / np.sum((a - a.mean()) ** 2)),
            "R2 vs historical mean from Jan-2009": float(1 - np.sum(e ** 2) / np.sum((a - hm["2009-01-01"].loc[m].values) ** 2)),
            "R2 vs historical mean from Jan-2007": float(1 - np.sum(e ** 2) / np.sum((a - hm["2007-01-01"].loc[m].values) ** 2)),
            "Skill vs naive": sk(naive), "Skill vs seasonal naive": sk(snaive), "Skill vs MA(12)": sk(ma12)}

# ---------- E2: corrected reporting tables ----------
E2 = {}
for w, (a0, b0) in WIN.items():
    W = P[(P.month >= a0) & (P.month <= b0)]; T = []
    for (m, g), x in W.groupby(["model", "group"]):
        r42 = met(x[x.seed == 42].sort_values("month")); seeds = sorted(x.seed.unique()); rms = [met(x[x.seed == s].sort_values("month"))["RMSE"] for s in seeds]
        T.append({"model": m, "group": g, **r42, "seeds": len(seeds), "RMSE mean (seeds)": float(np.mean(rms)), "RMSE SD (seeds)": float(np.std(rms, ddof=1)) if len(rms) > 1 else np.nan})
    T = pd.DataFrame(T).sort_values("RMSE").reset_index(drop=True); T.insert(0, "rank (RMSE)", range(1, len(T) + 1)); T.to_csv(f"{OUT}/E2_table_{w}.csv", index=False); E2[w] = T
d = [0.0]
if os.path.exists(F1T):  # optional cross-check against the earlier benchmark table
    f1 = pd.read_csv(F1T).set_index("Model"); chk = E2["test"].set_index("model")
    inv = {v: k for k, v in LAB.items()}; d = [abs(chk.loc[m, "RMSE"] - f1.loc[inv.get(m, m), "RMSE"]) for m in chk.index if inv.get(m, m) in f1.index]
    assert len(d) == 18 and max(d) < 1e-8, (len(d), max(d))
# ---------- E1: diagnostics ----------
FOCUS = ["ANN (fixed manuscript configuration, MLP 128-64)", "AVLA-ANN (corrected, paper members)", "AVLA-ANN + order book (pre-declared extension)", "ANN + order book (member of extension)", "Holt (damped)", "MA(12)"]
D = []
for w, (a0, b0) in WIN.items():
    for m in FOCUS:
        x = P[(P.model == m) & (P.seed == 42) & (P.month >= a0) & (P.month <= b0)].sort_values("month"); e = (x.actual - x.pred).values; fc = x.pred.values
        lb = acorr_ljungbox(e, lags=[1, 6, 12], return_df=True)["lb_pvalue"].values; t, pt = stats.ttest_1samp(e, 0.0)
        bp = het_breuschpagan(e, np.column_stack([np.ones_like(fc), fc]))[1]; rho, prho = stats.spearmanr(np.abs(e), fc); jb = stats.jarque_bera(e).pvalue
        sse = e ** 2; top = np.argsort(sse)[::-1][:3]
        D.append({"window": w, "model": m, "Ljung-Box p lag1": lb[0], "Ljung-Box p lag6": lb[1], "Ljung-Box p lag12": lb[2], "lag-1 autocorr of errors": float(pd.Series(e).autocorr(1)),
                  "bias": float(e.mean()), "bias t-test p": float(pt), "Breusch-Pagan p (error variance vs forecast level)": float(bp), "Spearman |e| vs forecast": float(rho), "Spearman p": float(prho),
                  "Jarque-Bera p (normality)": float(jb), "share of SSE from 3 largest months": float(sse[top].sum() / sse.sum()), "3 largest-error months": ", ".join(pd.DatetimeIndex(x.month.values[top]).strftime("%Y-%m"))})
E1 = pd.DataFrame(D); E1.to_csv(f"{OUT}/E1_residual_diagnostics.csv", index=False)
BM = []
for m in FOCUS[:4] + ["MA(12)"]:
    x = P[(P.model == m) & (P.seed == 42) & (P.month >= "2011-09-01")]; x = x.assign(cal=x.month.dt.month, ae=(x.actual - x.pred).abs(), e=x.actual - x.pred)
    for c, g in x.groupby("cal"): BM.append({"model": m, "calendar month": int(c), "n": len(g), "MAE": float(g.ae.mean()), "mean error (bias)": float(g.e.mean())})
pd.DataFrame(BM).to_csv(f"{OUT}/E1_errors_by_calendar_month.csv", index=False)
BO = P[(P.model.isin(FOCUS[:4] + ["MA(12)"])) & (P.seed == 42) & (P.month >= "2011-09-01")].assign(error=lambda z: z.actual - z.pred)[["model", "month", "actual", "pred", "error"]]
BO.to_csv(f"{OUT}/E1_errors_by_origin.csv", index=False)
# series diagnostics (data up to Aug-2013 only)
s = y.loc[:"2013-08-01"]; s9 = s.loc["2009-01-01":]
def supF(v):   # Quandt-Andrews sup-F for a single mean shift, 15% trimming
    n = len(v); best = (0, None)
    for k in range(int(0.15 * n), int(0.85 * n)):
        r0 = np.sum((v - v.mean()) ** 2); r1 = np.sum((v[:k] - v[:k].mean()) ** 2) + np.sum((v[k:] - v[k:].mean()) ** 2); F = (r0 - r1) / (r1 / (n - 2))
        if F > best[0]: best = (F, k)
    return best
F, k = supF(s.values); mm = s9.groupby(s9.index.month).mean()
SER = {"supF_mean_shift_2007_2013": {"F": float(F), "break_month": str(s.index[k].date()), "andrews_5pct_critical_value_15pct_trim_1param": 8.85, "significant_5pct": bool(F > 8.85),
                                      "mean_before": float(s.iloc[:k].mean()), "mean_after": float(s.iloc[k:].mean())},
       "ADF_p_2009_2013": float(adfuller(s9.values, autolag="AIC")[1]), "KPSS_p_2009_2013 (level)": float(kpss(s9.values, regression="c", nlags="auto")[1]),
       "ACF_levels_2009_2013": {"lag1": float(s9.autocorr(1)), "lag12": float(s9.autocorr(12))}, "ACF_first_differences_2009_2013_lag1": float(s9.diff().autocorr(1)),
       "share_of_variance_explained_by_month_of_year_2009_2013": float(1 - np.sum((s9 - s9.index.month.map(mm).values) ** 2) / np.sum((s9 - s9.mean()) ** 2)),
       "annual_means_kpacks": {int(k2): float(v) for k2, v in y.groupby(y.index.year).mean().items()}, "MASE_scale": scale}
json.dump(SER, open(f"{OUT}/E1_series_diagnostics.json", "w"), indent=1)
prov = {"inputs": {p: hashlib.sha256(open(p, "rb").read()).hexdigest() for p in (SRC_F1, SRC_OB, F1T) if os.path.exists(p)}, "script_sha256": hashlib.sha256(open(__file__, "rb").read()).hexdigest(),
        "F1_RMSE_reproduction_max_abs_diff": float(max(d)), "notes": ["No model fitted; no selection on the test window.", "Test window Sep-2013..Aug-2015 was examined in earlier versions; not an untouched hold-out.",
        "Order-book rows: pre-declared extension selected on validation (orderbook_avla_20261113); order book counts only eventually-delivered orders.",
        "R2 conventional uses the mean of the evaluation window (hindsight benchmark); historical-mean R2 shown with its start month stated."]}
json.dump(prov, open(f"{OUT}/provenance.json", "w"), indent=1)
pd.set_option("display.width", 260)
print(E2["test"][["rank (RMSE)", "model", "RMSE", "MAE", "MASE", "Bias (mean actual - forecast)", "R2 conventional (vs window mean)", "R2 vs historical mean from Jan-2009", "Skill vs naive", "Skill vs seasonal naive", "Skill vs MA(12)", "RMSE mean (seeds)", "RMSE SD (seeds)"]].round(3).to_string(index=False))
print(E1.round(3).to_string(index=False)); print(json.dumps(SER, indent=1))
