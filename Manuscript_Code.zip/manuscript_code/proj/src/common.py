"""Shared data loading, configuration and metric functions (Version B)."""
import json, hashlib, os, numpy as np, pandas as pd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CFG = json.load(open(os.path.join(ROOT, "configs", "protocol.json")))
OUT = os.path.join(ROOT, "out")


def path(*p):
    return os.path.join(ROOT, *p)


def sha256(fn):
    h = hashlib.sha256()
    with open(fn, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def load_raw():
    r = pd.read_csv(path(CFG["data"]["raw_file"]), encoding=CFG["data"]["encoding"])
    r["date"] = pd.to_datetime(r["Delivered to Client Date"], format="%d-%b-%y")
    r["po_date"] = pd.to_datetime(r["PO Sent to Vendor Date"], format="mixed", errors="coerce")
    r["W_num"] = pd.to_numeric(r["Weight (Kilograms)"], errors="coerce")
    r["F_num"] = pd.to_numeric(r["Freight Cost (USD)"], errors="coerce")
    r["Ins_num"] = pd.to_numeric(r["Line Item Insurance (USD)"], errors="coerce")
    assert len(r) == 10324 and r["date"].notna().all(), "raw file changed"
    return r


def monthly_aggregate(r):
    m = r.assign(m=r["date"].dt.to_period("M")).groupby("m")["Line Item Quantity"].sum()
    p0, p1 = CFG["data"]["aggregate_period"]
    s = m.reindex(pd.period_range(p0, p1, freq="M"), fill_value=0).astype(float)
    s.index = s.index.to_timestamp()
    return s / 1000.0


# ---------------- metrics ----------------
def metrics(a, p):
    a, p = np.asarray(a, float), np.asarray(p, float)
    assert a.shape == p.shape and np.isfinite(p).all(), "invalid predictions"
    e = a - p
    out = {"RMSE": np.sqrt(np.mean(e ** 2)), "MSE": np.mean(e ** 2), "MAE": np.mean(np.abs(e)),
           "MAD": np.median(np.abs(e - np.median(e))),
           "MAPE (%)": 100 * np.mean(np.abs(e / a)) if (a != 0).all() else np.nan,
           "sMAPE (%)": 100 * np.mean(2 * np.abs(e) / (np.abs(a) + np.abs(p))),
           "R2 (vs test mean)": 1 - np.sum(e ** 2) / np.sum((a - a.mean()) ** 2),
           "Bias (mean error)": np.mean(e)}
    return out


def dm_test(a, p1, p2):
    """Diebold-Mariano, squared loss, h=1, HLN small-sample correction. Negative stat => p1 more accurate."""
    from scipy import stats
    d = (np.asarray(a) - p1) ** 2 - (np.asarray(a) - p2) ** 2
    T = len(d)
    stat = d.mean() / np.sqrt(d.var(ddof=0) / T) * np.sqrt((T - 1) / T)
    return float(stat), float(2 * stats.t.sf(abs(stat), df=T - 1))


def holm(pvals):
    p = np.asarray(pvals, float); n = len(p); order = np.argsort(p)
    adj = np.empty(n); run = 0.0
    for k, i in enumerate(order):
        run = max(run, (n - k) * p[i]); adj[i] = min(1.0, run)
    return adj
