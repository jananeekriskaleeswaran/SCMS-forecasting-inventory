"""Shipment-level reconstruction of SCMS line items.

Findings encoded here (verified in audit_shipments()):
- ASN/DN # identifies a physical shipment: no ASN spans >1 mode, >1 country or >1 delivery date.
- In a multi-line shipment, exactly one 'anchor' line carries numeric Weight and Freight; the
  other lines say 'See ASN-x (ID#:n)' pointing to the anchor in the same ASN. The anchor's
  weight and freight are SHIPMENT totals, not the anchor item's own values.
- 'Freight Included in Commodity Cost' / 'Invoiced Separately' -> freight not observable.
- 'Weight Captured Separately' -> weight not observable.
"""
import numpy as np, pandas as pd


def audit_shipments(r):
    g = r.groupby("ASN/DN #")
    agg = g.agg(n=("ID", "size"), nmode=("Shipment Mode", "nunique"), nctry=("Country", "nunique"),
                ndate=("date", "nunique"), nW=("W_num", "count"), nF=("F_num", "count"))
    fc = r["Freight Cost (USD)"].astype(str)
    refs = r[fc.str.startswith("See")].copy()
    refs["ref"] = refs["Freight Cost (USD)"].str.extract(r"ID#:(\d+)")[0].astype(int)
    m = refs.merge(r[["ID", "ASN/DN #"]], left_on="ref", right_on="ID", suffixes=("", "_ref"))
    multi = agg[agg.n > 1]
    rep = {
        "line_items": int(len(r)), "shipments_ASN_DN": int(len(agg)),
        "multi_line_shipments": int(len(multi)), "lines_in_multi_line_shipments": int(multi.n.sum()),
        "max_lines_per_shipment": int(agg.n.max()),
        "multi_line_with_more_than_one_mode": int((multi.nmode > 1).sum()),
        "multi_line_with_more_than_one_country": int((multi.nctry > 1).sum()),
        "multi_line_with_more_than_one_delivery_date": int((multi.ndate > 1).sum()),
        "freight_See_references": int(len(refs)),
        "See_references_pointing_into_same_shipment": float((m["ASN/DN #"] == m["ASN/DN #_ref"]).mean()),
        "multi_line_shipments_with_exactly_one_numeric_freight_line": int((multi.nF == 1).sum()),
        "multi_line_shipments_with_no_numeric_freight": int((multi.nF == 0).sum()),
        "multi_line_shipments_with_more_than_one_numeric_freight_line": int((multi.nF > 1).sum()),
        "freight_status_counts": fc.where(~fc.str.startswith("See"), "See <ref>").where(
            pd.to_numeric(fc, errors="coerce").isna(), "numeric").value_counts().to_dict(),
        "same_item_repeated_within_shipment": int((r.groupby(["ASN/DN #", "Item Description"]).size() > 1).sum()),
    }
    assert rep["multi_line_with_more_than_one_mode"] == 0 and rep["multi_line_with_more_than_one_country"] == 0
    assert rep["See_references_pointing_into_same_shipment"] == 1.0
    return rep


def build_shipments(r):
    """One row per ASN/DN: mode, country, date, total weight / freight when observable, packs."""
    s = r.groupby("ASN/DN #").agg(
        country=("Country", "first"), mode=("Shipment Mode", "first"), date=("date", "first"),
        po_date=("po_date", "min"), fulfill=("Fulfill Via", "first"), vendor=("Vendor", "first"),
        n_lines=("ID", "size"), n_items=("Item Description", "nunique"),
        W=("W_num", "sum"), nW=("W_num", "count"), F=("F_num", "sum"), nF=("F_num", "count"),
        value=("Line Item Value", "sum"), packs=("Line Item Quantity", "sum"))
    s.loc[s.nW == 0, "W"] = np.nan
    s.loc[s.nF == 0, "F"] = np.nan
    s["lead_time_days"] = (s.date - s.po_date).dt.days
    return s.reset_index()


def lane_shipment_lines(r):
    """Item-level quantity per shipment (sums repeated lines of the same item in one ASN)."""
    return (r.groupby(["ASN/DN #", "Country", "Item Description"])
             .agg(packs=("Line Item Quantity", "sum"), date=("date", "first"),
                  mode=("Shipment Mode", "first"), pack_price=("Pack Price", "median"),
                  value=("Line Item Value", "sum"))
             .reset_index())


def weight_per_pack(r, ship):
    """kg per pack from single-item shipments only (shipment weight then belongs to one item)."""
    single = ship[(ship.n_items == 1) & (ship.W > 0)][["ASN/DN #", "W", "packs"]]
    li = r.merge(single, on="ASN/DN #")
    li = li.groupby(["ASN/DN #", "Country", "Item Description"]).agg(W=("W", "first"), packs=("packs", "first"),
                                                                    date=("date", "first")).reset_index()
    li["wpp"] = li.W / li.packs
    return li
