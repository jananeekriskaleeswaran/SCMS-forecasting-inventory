"""Track B model definitions: ML factories (tuned and manuscript configurations), grids, classical models,
and complexity (parameter) counts."""
import numpy as np
from sklearn.neural_network import MLPRegressor
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.svm import SVR
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from xgboost import XGBRegressor
from statsmodels.tsa.holtwinters import ExponentialSmoothing, SimpleExpSmoothing
from statsmodels.tsa.statespace.sarimax import SARIMAX

GRIDS = {
    "Ridge": [{"alpha": a} for a in (0.1, 1, 10, 100)],
    "SVR": [{"C": c, "eps": e} for c in (0.3, 1, 3) for e in (0.05, 0.2)],
    "RF": [{"leaf": l, "mf": m} for l in (2, 5, 10) for m in (1.0, 0.5)],
    "GB": [{"n": k, "d": d} for k in (50, 150) for d in (1, 2)],
    "XGB": [{"n": k, "d": d} for k in (50, 150) for d in (1, 2)],
    "ANN": [{"h": h, "alpha": a} for h in ((4,), (8,), (16, 8)) for a in (0.1, 1.0, 10.0)],
}
# configurations used by the original code (Market analysis cells 18/21), applied to the monthly series
MANUSCRIPT = {"ANN": {"h": (128, 64), "alpha": 1e-4, "max_iter": 800},
              "RF": {"leaf": 1, "mf": 1.0, "n": 200}, "GB": {"n": 200, "d": 3, "lr": 0.1, "sub": 1.0}}


def make(name, cfg, seed):
    if name == "Ridge": return make_pipeline(StandardScaler(), Ridge(alpha=cfg["alpha"]))
    if name == "SVR": return make_pipeline(StandardScaler(), SVR(C=cfg["C"], epsilon=cfg["eps"]))
    if name == "RF": return RandomForestRegressor(n_estimators=cfg.get("n", 300), min_samples_leaf=cfg["leaf"],
                                                  max_features=cfg["mf"], random_state=seed, n_jobs=1)
    if name == "GB": return GradientBoostingRegressor(n_estimators=cfg["n"], learning_rate=cfg.get("lr", 0.05), max_depth=cfg["d"],
                                                      subsample=cfg.get("sub", 0.8), random_state=seed)
    if name == "XGB": return XGBRegressor(n_estimators=cfg["n"], learning_rate=0.05, max_depth=cfg["d"], subsample=0.8,
                                          random_state=seed, n_jobs=1, verbosity=0)
    if name == "ANN": return make_pipeline(StandardScaler(), MLPRegressor(hidden_layer_sizes=cfg["h"], alpha=cfg["alpha"],
                                           max_iter=cfg.get("max_iter", 3000), random_state=seed))
    raise ValueError(name)


def n_params(model):
    """Complexity: trainable parameters (linear/MLP), support vectors (SVR) or total tree nodes (ensembles)."""
    m = model.steps[-1][1] if hasattr(model, "steps") else model
    if isinstance(m, MLPRegressor): return int(sum(w.size for w in m.coefs_) + sum(b.size for b in m.intercepts_))
    if isinstance(m, Ridge): return int(m.coef_.size + 1)
    if isinstance(m, SVR): return int(m.support_.size)
    if isinstance(m, RandomForestRegressor): return int(sum(e.tree_.node_count for e in m.estimators_))
    if isinstance(m, GradientBoostingRegressor): return int(sum(e[0].tree_.node_count for e in m.estimators_))
    if isinstance(m, XGBRegressor): return int(m.get_booster().trees_to_dataframe().shape[0])
    return -1


def classical(name, tr, order=None):
    """One-step forecast (log scale) and parameter count for classical models fitted on log series tr."""
    if name == "SES":
        r = SimpleExpSmoothing(tr, initialization_method="estimated").fit(); return r.forecast(1).iloc[0], 2
    if name == "Holt (linear)":
        r = ExponentialSmoothing(tr, trend="add", initialization_method="estimated").fit(); return r.forecast(1).iloc[0], 4
    if name == "Holt (damped)":
        r = ExponentialSmoothing(tr, trend="add", damped_trend=True, initialization_method="estimated").fit(); return r.forecast(1).iloc[0], 5
    if name == "Holt-Winters (damped, additive)":
        r = ExponentialSmoothing(tr, trend="add", damped_trend=True, seasonal="add", seasonal_periods=12,
                                 initialization_method="estimated").fit(); return r.forecast(1).iloc[0], 5 + 12
    if name in ("ARIMA", "SARIMA"):
        o, so = order
        r = SARIMAX(tr, order=o, seasonal_order=so, enforce_stationarity=False, enforce_invertibility=False).fit(disp=False)
        return r.forecast(1).iloc[0], int(len(r.params))
    raise ValueError(name)


def select_order(train, seasonal):
    """AIC selection on the first training window only (no test information)."""
    best = None
    for p in (0, 1, 2):
        for q in (0, 1, 2):
            for P in ((0, 1) if seasonal else (0,)):
                try:
                    so = (P, 0, 0, 12) if seasonal else (0, 0, 0, 0)
                    r = SARIMAX(train, order=(p, 1, q), seasonal_order=so, enforce_stationarity=False,
                                enforce_invertibility=False).fit(disp=False)
                    if best is None or r.aic < best[0]: best = (r.aic, (p, 1, q), so)
                except Exception:
                    pass
    return best[1], best[2]
