"""Track B preprocessing: monthly series and strictly past-only features (with a leakage self-test)."""
import json, os, numpy as np, pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__)); CFG = json.load(open(os.path.join(HERE, "configuration.json")))


def load_raw():
    r = pd.read_csv(os.path.join(os.environ.get("HYBRID_ANN_ROOT") or os.path.abspath(os.path.join(HERE, "..", "..")), CFG["data_file"]), encoding=CFG["encoding"])
    r["date"] = pd.to_datetime(r["Delivered to Client Date"], format="%d-%b-%y")
    return r


def monthly_series(r=None):
    r = load_raw() if r is None else r
    s = r.groupby(r.date.dt.to_period("M"))["Line Item Quantity"].sum()
    p0, p1 = CFG["series_period"]
    s = s.reindex(pd.period_range(p0, p1, freq="M"), fill_value=0).astype(float)
    s.index = s.index.to_timestamp()
    return s / 1000.0


def features(L):
    """Features for month t use only L[:t] (t excluded)."""
    f = pd.DataFrame(index=L.index)
    for k in (1, 2, 3, 12):
        f[f"lag{k}"] = L.shift(k)
    f["rm3"] = L.shift(1).rolling(3).mean(); f["rm12"] = L.shift(1).rolling(12).mean()
    f["sin"] = np.sin(2 * np.pi * L.index.month / 12); f["cos"] = np.cos(2 * np.pi * L.index.month / 12)
    return f


def leakage_selftest(L):
    F = features(L)
    for t in range(13, len(L)):
        pert = pd.concat([L.iloc[:t], pd.Series([1e9], index=[L.index[t]])])
        if not np.allclose(F.iloc[t].values, features(pert).iloc[-1].values, equal_nan=True):
            raise AssertionError(f"feature at {L.index[t]} depends on y_t or later")
    return True
