"""Track B: expanding-window rolling-origin evaluation (h=1). Writes per-origin predictions for the
12 tuning months and the 24 test months, runtimes, selected configurations and complexity."""
import os, sys, json, time, warnings
import numpy as np, pandas as pd
from preprocessing import CFG, HERE, monthly_series, features, leakage_selftest
from forecasting_models import GRIDS, MANUSCRIPT, make, n_params, classical, select_order
warn_log = []
def _w(message, category, filename, lineno, file=None, line=None): warn_log.append(f"{category.__name__}: {str(message)[:100]}")
warnings.showwarning = _w; warnings.simplefilter("always")

y = monthly_series(); L = np.log1p(y); n = len(y); F = features(L)
assert leakage_selftest(L)
test0 = list(y.index).index(pd.Timestamp(CFG["test_origins"][0] + "-01")); WARM = 12
assert n - test0 == CFG["n_test"] == 24
origins = list(range(test0 - WARM, n))
ANN_SEEDS = CFG["seeds"]["ANN"]; SEED = CFG["seeds"]["trees_xgb"]


def ml(name, cfg, t, seeds):
    Ftr = F.iloc[:t].dropna(); ytr = L.loc[Ftr.index]; xt = F.iloc[[t]]
    assert Ftr.index.max() < y.index[t]                      # training strictly before forecast month
    out, npar = [], None
    for s in seeds:
        m = make(name, cfg, s).fit(Ftr, ytr); out.append(float(np.expm1(m.predict(xt)[0]))); npar = n_params(m)
    return out, npar

log = {"tuning": {}, "runtime_s": {}, "n_params": {}}
BEST = {}
for name in GRIDS:                                           # tuning on the 12 pre-test months only
    t0 = time.time(); sc = []
    for cfg in GRIDS[name]:
        seeds = ANN_SEEDS if name == "ANN" else [SEED]
        e = [np.mean(ml(name, cfg, t, seeds)[0]) - y.iloc[t] for t in origins[:WARM]]
        sc.append(float(np.sqrt(np.mean(np.square(e)))))
    BEST[name] = GRIDS[name][int(np.argmin(sc))]
    log["tuning"][name] = {"grid": [str(g) for g in GRIDS[name]], "tuning_RMSE": sc, "selected": str(BEST[name])}
    log["runtime_s"][f"tuning {name}"] = round(time.time() - t0, 2); print("tuned", name, BEST[name], flush=True)
ar = select_order(L.iloc[:origins[0]], False); sar = select_order(L.iloc[:origins[0]], True)
log["ARIMA_order"] = str(ar); log["SARIMA_order"] = str(sar)

MODELS = {  # name -> callable(t) returning (prediction, n_params)
    "Naive": lambda t: (y.iloc[t - 1], 0), "Seasonal naive": lambda t: (y.iloc[t - 12], 0),
    "Moving average (3)": lambda t: (y.iloc[t - 3:t].mean(), 0),
}
for cname in ("SES", "Holt (linear)", "Holt (damped)", "Holt-Winters (damped, additive)"):
    MODELS[cname] = (lambda c: lambda t: (lambda f, k: (float(np.expm1(f)), k))(*classical(c, L.iloc[:t])))(cname)
MODELS[f"ARIMA{ar[0]}"] = lambda t: (lambda f, k: (float(np.expm1(f)), k))(*classical("ARIMA", L.iloc[:t], ar))
MODELS[f"SARIMA{sar[0]}{sar[1][:3]}12"] = lambda t: (lambda f, k: (float(np.expm1(f)), k))(*classical("SARIMA", L.iloc[:t], sar))
ML_SPECS = {"Ridge regression": ("Ridge", "tuned"), "SVR": ("SVR", "tuned"), "XGBoost": ("XGB", "tuned"),
            "Random Forest (tuned)": ("RF", "tuned"), "Gradient Boosting (tuned)": ("GB", "tuned"), "ANN (tuned, 5-seed mean)": ("ANN", "tuned"),
            "Random Forest (manuscript cfg)": ("RF", "ms"), "Gradient Boosting (manuscript cfg)": ("GB", "ms"),
            "ANN (manuscript cfg, 5-seed mean)": ("ANN", "ms")}
preds, seedpreds = {k: [] for k in list(MODELS) + list(ML_SPECS)}, {}
for t in origins:
    for k, f in MODELS.items():
        t0 = time.time(); p, k_ = f(t); preds[k].append(float(p))
        log["runtime_s"][k] = log["runtime_s"].get(k, 0) + time.time() - t0; log["n_params"][k] = k_
    for k, (nm, which) in ML_SPECS.items():
        cfg = BEST[nm] if which == "tuned" else MANUSCRIPT[nm]; seeds = ANN_SEEDS if nm == "ANN" else [SEED]
        t0 = time.time(); ps, k_ = ml(nm, cfg, t, seeds); preds[k].append(float(np.mean(ps)))
        log["runtime_s"][k] = log["runtime_s"].get(k, 0) + time.time() - t0; log["n_params"][k] = k_
        if nm == "ANN": seedpreds.setdefault(k, []).append(ps)
    print("origin", y.index[t].strftime("%Y-%m"), flush=True)

P = pd.DataFrame(preds, index=y.index[origins]); P.insert(0, "Actual", y.iloc[origins].values)
P.insert(1, "window", ["tuning"] * WARM + ["test"] * (len(origins) - WARM))
os.makedirs(os.path.join(HERE, "predictions"), exist_ok=True)
P.to_csv(os.path.join(HERE, "predictions", "per_origin_predictions_all.csv"))
rows = []
for k, arr in seedpreds.items():
    for j, (t, ps) in enumerate(zip(y.index[origins], arr)):
        for s, v in zip(ANN_SEEDS, ps): rows.append({"model": k, "month": t, "seed": s, "prediction": v, "actual": y.iloc[origins[j]]})
pd.DataFrame(rows).to_csv(os.path.join(HERE, "predictions", "ann_per_seed_predictions.csv"), index=False)
log["runtime_s"] = {k: round(v, 3) for k, v in log["runtime_s"].items()}
log["warnings"] = pd.Series(warn_log).value_counts().to_dict() if warn_log else {}
log["selected_configs"] = {k: str(v) for k, v in BEST.items()}; log["manuscript_configs"] = {k: str(v) for k, v in MANUSCRIPT.items()}
json.dump(log, open(os.path.join(HERE, "logs", "rolling_origin_log.json"), "w"), indent=1, default=str)
print("ROLLING ORIGIN DONE")
